sap.ui.define([
	"sap/ui/test/Opa5",
	"Trial_Formulation/trial_formulation/test/integration/pages/Common"
], function (Opa5, Common) {
	"use strict";

	Opa5.createPageObjects({
		onTheListReportPage: {
			baseClass: Common,
			actions: {
			},

			assertions: {
			}
		}
	});
});