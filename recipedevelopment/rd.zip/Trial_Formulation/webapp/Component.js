sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("Trial_Formulation.trial_formulation.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});