package com.managelayout.services;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.managelayout.constants.LayoutConstants;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryBuilder;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.EntityDataBuilder;
import com.sap.cloud.sdk.service.prov.api.EntityMetadata;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.CreateRequest;
import com.sap.cloud.sdk.service.prov.api.request.DeleteRequest;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.request.UpdateRequest;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponseAccessor;

/**
 * Junit test case class for LayoutHooksHandler class.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ DataSourceHandlerFactory.class, EntityData.class, 
	ODataQueryBuilder.class, CDSDataSourceHandlerFactory.class })
public class LayoutHooksHandlerTest {

	
	JSONObject jsonObj;
	JSONArray jsonArr;
	List<EntityData> layoutDataList;
	List<EntityData> cDSSelectQueryResultList;
	String layoutID = "0eb8a795-a966-4d41-b900-e7843455f798";
	String userSpecificLayout = "User Specific Layout";
	String globalLayout = "Global Layout";
	String draftUUID = "0eb8a125-a966-3e41-b900-e7843455f798";
	List<EntityData> draftList;
	
	private QueryRequest queryRequest;
	private ExtensionHelper extensionHelper;
	private EntityMetadata entityMetadata;
	private EntityData entityData;	
	private QueryResponseAccessor queryResponse;
	private CDSDataSourceHandler cDSDataSourceHandler;
	private DataSourceHandler handler;
	private CDSSelectQueryResult cDSSelectQueryResult;
	private EntityDataBuilder entityDataBuilder;
	private DeleteRequest deleteRequest;
	private CreateRequest createRequest;
	private UpdateRequest updateRequest;
	LayoutHooksHandler layoutHooksHandler;
	ReadResponseAccessor readResponseAccessor;
	CreateResponseAccessor createResponseAccessor;	

	/**
	 * This method is initializing the mock objects, having the common objects and
	 * when().thenReturn() for all the test cases.
	 * 
	 * @throws CDSException
	 */

	@Before
	public void setUp() throws CDSException {

		queryResponse = Mockito.mock(QueryResponseAccessor.class);
		jsonObj = Mockito.mock(JSONObject.class);
		jsonArr = Mockito.mock(JSONArray.class);
		extensionHelper = Mockito.mock(ExtensionHelper.class);
		readResponseAccessor = Mockito.mock(ReadResponseAccessor.class);
		createResponseAccessor = Mockito.mock(CreateResponseAccessor.class);
		queryRequest = Mockito.mock(QueryRequest.class);
		entityMetadata = Mockito.mock(EntityMetadata.class);
		entityData = Mockito.mock(EntityData.class);
		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);		
		cDSDataSourceHandler = Mockito.mock(CDSDataSourceHandler.class);
		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
		entityDataBuilder = Mockito.mock(EntityDataBuilder.class);
		deleteRequest = Mockito.mock(DeleteRequest.class);
		createRequest = Mockito.mock(CreateRequest.class);
		handler = Mockito.mock(DataSourceHandler.class);
		layoutHooksHandler = new LayoutHooksHandler();
		createRequest = Mockito.mock(CreateRequest.class);
		updateRequest = Mockito.mock(UpdateRequest.class);
		handler = Mockito.mock(DataSourceHandler.class);

		layoutDataList = new ArrayList<>();
		layoutDataList.add(entityData);
		draftList = new ArrayList<>();         
		draftList.add(entityData);
		cDSSelectQueryResultList = new ArrayList<>();
		cDSSelectQueryResultList.add(entityData);

		PowerMockito.mockStatic(ODataQueryBuilder.class);
		PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
		PowerMockito.mockStatic(EntityData.class);
		PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cDSDataSourceHandler);		
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
		
		Mockito.when(queryResponse.getEntityDataList()).thenReturn(layoutDataList);
		Mockito.when(queryRequest.getEntityMetadata()).thenReturn(entityMetadata);
		Mockito.when(entityMetadata.getNamespace()).thenReturn(LayoutConstants.DATA_MODEL);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn(layoutID);			
		Mockito.when(entityDataBuilder.addElement(Mockito.anyString(), Mockito.anyObject())).thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_LAYOUTINFORMATION)).thenReturn(entityData);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);

	}

	@Test
	public void updateLayoutInformationListTest() throws CDSException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_LAYOUTINFORMATION))
				.thenReturn(entityData);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(draftList);
		Mockito.when(entityData.getElementValue(LayoutConstants.DRAFTUUID)).thenReturn(draftUUID);
		Assert.assertNotNull(layoutHooksHandler.getLayoutInformationList(queryRequest, queryResponse, extensionHelper));

	}

	@Test
	public void deleteLayoutForUserSpecificTest() throws CDSException {

		Mockito.when(deleteRequest.getEntityMetadata()).thenReturn(entityMetadata);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_LAYOUTINFORMATION)).thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_TYPE)).thenReturn(userSpecificLayout);
		Assert.assertNotNull(layoutHooksHandler.beforeDeleteLayout(deleteRequest, extensionHelper));
	}

	/*
	 * This method is testing the negative scenario of beforeDeleteLayout method.
	 * Success Scenario - the method is fetching whether the layout is User Specific
	 * or Global. If it is Global Layout, Error response is sent
	 */
	@Test
	public void deleteLayoutForGlobalTest() throws CDSException {

		Mockito.when(deleteRequest.getEntityMetadata()).thenReturn(entityMetadata);		
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_LAYOUTINFORMATION)).thenReturn(entityData);		
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_TYPE)).thenReturn(globalLayout);
		Assert.assertNotNull(layoutHooksHandler.beforeDeleteLayout(deleteRequest, extensionHelper));
	}

	/*
	 * This method is testing the scenario of afterQueryDraft method. Success
	 * Scenario - the method is to remove Formula Item on read in
	 * ColumnsSelectedInLayout entity.
	 */
	@Test
	public void removeFormulaItemTest() {
		
		Mockito.when(entityData.getElementValue(LayoutConstants.SUB_CATEGORY_NAME)).thenReturn(LayoutConstants.FORMULA_ITEM);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT)).thenReturn(entityData);
		Assert.assertNotNull(layoutHooksHandler.removeFormulaItem(queryRequest, queryResponse, extensionHelper));
	}

	/*
	 * This method is testing the negative scenario of afterQueryDraft method.
	 */
	@Test
	public void removeFormulaItemNegativeTest() {
		
		Mockito.when(entityData.getElementValue(LayoutConstants.SUB_CATEGORY_NAME)).thenReturn(LayoutConstants.UOM);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT)).thenReturn(entityData);
		Assert.assertNotNull(layoutHooksHandler.removeFormulaItem(queryRequest, queryResponse, extensionHelper));
	}

	/*
	 * This method is testing afterCreateLayout method.
	 */
	@Test
	public void afterCreateLayoutTest() throws DatasourceException,	ClassCastException {
		
		Mockito.when(createResponseAccessor.getEntityData()).thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn(LayoutConstants.LAYOUT_ID);
		Mockito.when(entityData.getElementValue(LayoutConstants.DRAFT_ADMINISTRATIVEDATA_DRAFTUUID)).thenReturn(LayoutConstants.DRAFTUUID);
		Mockito.when(extensionHelper.getHandler()).thenReturn(handler);
		Assert.assertNotNull(layoutHooksHandler.afterCreateLayout(createRequest, createResponseAccessor, extensionHelper));

	}

	@Test
	public void beforeCreateLayoutInformationTest() throws DatasourceException {
		
		Mockito.when(createRequest.getData()).thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.DEFAULT_FLAG)).thenReturn("true");
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(extensionHelper.getHandler()).thenReturn(handler);
		Assert.assertNotNull(layoutHooksHandler.beforecreateLayoutInformation(createRequest, extensionHelper));
	}

	@Test
	public void beforeUpdateLayoutInformationTest() throws DatasourceException {
		
		Mockito.when(updateRequest.getData()).thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.DEFAULT_FLAG)).thenReturn("true");
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(extensionHelper.getHandler()).thenReturn(handler);
		Assert.assertNotNull(layoutHooksHandler.beforeUpdateLayoutInformation(updateRequest, extensionHelper));
	}

	@Test
	public void beforeCreateLayoutTest() throws DatasourceException {
		
		Mockito.when(createRequest.getData()).thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_NAME)).thenReturn(null);
		Mockito.when(createRequest.getData()).thenReturn(entityData);
		Assert.assertNotNull(layoutHooksHandler.beforeCreateLayout(createRequest, extensionHelper));
	}
}
