package com.managelayout.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import com.managelayout.constants.LayoutConstants;
import com.managelayout.services.LayoutCustomService;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.EntityDataBuilder;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.OperationRequest;
import com.trialformulation.constants.FormulaOptimiserContants;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponseBuilder;

import java.sql.Connection;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ DataSourceHandlerFactory.class, EntityData.class, CDSDataSourceHandlerFactory.class, ErrorResponse.class })
public class LayoutCustomServiceTest {

	private ExtensionHelper extensionHelper;
	private OperationRequest functionRequest;
	private EntityData entityData;
	private EntityData entityDataObj1;
	private EntityData entityDataObj2;
	private EntityData swapEntityData;
	private DataSourceHandler handler;
	private DatasourceException datasourceException;
	private Connection con;
	private CDSDataSourceHandler cDSDataSourceHandler;
	private CDSException cdsException;

	private ErrorResponse errorResponseObject;
	private ErrorResponseBuilder errorResponseBuilderObject;
	private CDSSelectQueryResult cDSSelectQueryResult;
	private DataSourceHandlerFactory dataSourceHandlerFactory;
	private EntityDataBuilder entityDataBuilder;
	List<EntityData> cDSSelectQueryResultList;
	List<EntityData> cDSSelectQueryResultList1;
	List<EntityData> cDSSelectQueryResultList2;
	LayoutCustomService layoutCustomService;
	String ID = "db9cc4eb-e7de-47d5-afb6-69fc8c071252";
	String draftUUID = "0eb8a795-a966-4d41-b900-e7843455f798";
	Integer currentColumnOrder = 1;
	Map<String, Object> parameters;
	String specificationID = "db9cc4eb-e7de-47d5-afb6-69fc8c341253";

	@Before
	public void setUp() throws CDSException {

		extensionHelper = Mockito.mock(ExtensionHelper.class);
		entityData = Mockito.mock(EntityData.class);
		entityDataObj1 = Mockito.mock(EntityData.class);
		entityDataObj2 = Mockito.mock(EntityData.class);
		swapEntityData = Mockito.mock(EntityData.class);
		con = Mockito.mock(Connection.class);
		handler = Mockito.mock(DataSourceHandler.class);
		functionRequest = Mockito.mock(OperationRequest.class);
		layoutCustomService = new LayoutCustomService();
		cDSDataSourceHandler = Mockito.mock(CDSDataSourceHandler.class);
		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
		dataSourceHandlerFactory = Mockito.mock(DataSourceHandlerFactory.class);
		entityDataBuilder = Mockito.mock(EntityDataBuilder.class);
		cdsException = Mockito.mock(CDSException.class);

		datasourceException = Mockito.mock(DatasourceException.class);
		cDSSelectQueryResultList = new ArrayList<>();
		cDSSelectQueryResultList.add(0, entityData);

		cDSSelectQueryResultList1 = new ArrayList<>();
		cDSSelectQueryResultList1.add(0, entityDataObj1);

		cDSSelectQueryResultList2 = new ArrayList<>();
		cDSSelectQueryResultList2.add(0, entityDataObj2);

		Mockito.when(extensionHelper.getHandler()).thenReturn(handler);
		Mockito.when(entityData.getElementValue("ID")).thenReturn("ID");
		errorResponseBuilderObject = Mockito.mock(ErrorResponseBuilder.class);
		errorResponseObject = Mockito.mock(ErrorResponse.class);
		PowerMockito.mockStatic(DataSourceHandlerFactory.class);
		PowerMockito.when(DataSourceHandlerFactory.getInstance()).thenReturn(dataSourceHandlerFactory);
		Mockito.when(dataSourceHandlerFactory.getCDSHandler(Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(cDSDataSourceHandler);
		PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
		PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cDSDataSourceHandler);
		PowerMockito.mockStatic(EntityData.class);
		Mockito.when(entityData.getElementValue(LayoutConstants.SUB_CATEGORY_NAME)).thenReturn("sss");
		Mockito.when(entityData.getElementValue(Mockito.anyString())).thenReturn(entityData);
		Mockito.when(entityDataObj1.getElementValue(Mockito.anyString())).thenReturn(draftUUID);
		Mockito.when(entityDataObj2.getElementValue(Mockito.anyString())).thenReturn(draftUUID);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn("layoutItemId");
		Mockito.when(entityDataObj1.getElementValue(LayoutConstants.COLUMN_ORDER)).thenReturn(1);
		Mockito.when(swapEntityData.getElementValue(Mockito.anyString())).thenReturn(swapEntityData);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.buildEntityData(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS))
				.thenReturn(entityData);
		Mockito.when(entityData.getElementValue("ID")).thenReturn(ID);
		EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataBuilderObj.buildEntityData(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS))
				.thenReturn(swapEntityData);
		Mockito.when(entityDataBuilderObj.buildEntityData(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT))
				.thenReturn(swapEntityData);
		Mockito.when(swapEntityData.getElementValue("ID")).thenReturn(1);
		PowerMockito.mockStatic(ErrorResponse.class);
		PowerMockito.when(ErrorResponse.getBuilder()).thenReturn(errorResponseBuilderObject);

		// Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(swapEntityData.getElementValue(LayoutConstants.COLUMN_ORDER)).thenReturn(2);
		cDSSelectQueryResultList.add(0, swapEntityData);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		parameters = new HashMap<String, Object>();

	}

	/*
	 * Below method is testing the scenarios of reorderSelectedColumns.
	 * Scenario- Passing the REORDER_ACTION as "up" and "down" .
	 */

	@Test
	public void reorderSelectedColumnsTest_forActionUpDown() throws DatasourceException, ClassCastException {

		Mockito.when(handler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.COLUMN_ORDER)).thenReturn(1);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(swapEntityData.getElementValue(LayoutConstants.FIXED_COLUMN)).thenReturn(2);
		ArrayList<Integer> fixedColumnList = new ArrayList<>();
		ArrayList<String> reorderActionList = new ArrayList<>();
		fixedColumnList.add(1);
		fixedColumnList.add(2);
		reorderActionList.add(LayoutConstants.BUTTON_UP);
		reorderActionList.add(LayoutConstants.BUTTON_DOWN);

		for (String reorderAction : reorderActionList) {
			for (Integer fixedColumn : fixedColumnList) {
				Mockito.when(entityData.getElementValue(LayoutConstants.FIXED_COLUMN)).thenReturn(fixedColumn);
				Map<String, Object> columnParameters = new HashMap<>();
				columnParameters.put(LayoutConstants.REORDER_ACTION, reorderAction);
				Map<String, Object> keys = new HashMap<>();
				keys.put("ID", swapEntityData.getElementValue("ID"));
				Mockito.when(functionRequest.getParameters()).thenReturn(columnParameters);
				Assert.assertNotNull(layoutCustomService.reorderSelectedColumn(functionRequest, extensionHelper));
			}

		}

	}

	/*
	 * Below method is testing the scenarios of reorderSelectedColumns. Scenario
	 * - Passing the REORDER_ACTION as "directDown" and "directUp" .
	 */

	@Test

	public void reorderSelectedColumnsTest_forActionDirectUpDown() throws DatasourceException, ClassCastException {

		Mockito.when(handler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityData);
		Mockito.when(entityData.getElementValue(LayoutConstants.COLUMN_ORDER)).thenReturn(1);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		ArrayList<String> reorderActionList = new ArrayList<>();
		reorderActionList.add(LayoutConstants.BUTTON_DIRECT_UP);
		reorderActionList.add(LayoutConstants.BUTTON_DIRECT_DOWN);
		for (String reorderAction : reorderActionList) {
			Map<String, Object> columnParameters = new HashMap<>();
			columnParameters.put(LayoutConstants.REORDER_ACTION, reorderAction);
			Mockito.when(functionRequest.getParameters()).thenReturn(columnParameters);
			Assert.assertNotNull(layoutCustomService.reorderSelectedColumn(functionRequest, extensionHelper));
		}
	}

	@Test
	public void layoutFixedColumnSaveTest_True() throws DatasourceException, ClassCastException {
		parameters.put(LayoutConstants.LAYOUT_ID, ID);
		parameters.put("fixed", "true");
		Mockito.when(functionRequest.getParameters()).thenReturn(parameters);
		Mockito.when(handler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityData);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn(specificationID);
		Assert.assertNotNull(layoutCustomService.layoutFixedColumnSave(functionRequest, extensionHelper));
	}

	@Test
	public void layoutFixedColumnSaveTest_False() throws DatasourceException, ClassCastException {
		parameters.put(LayoutConstants.LAYOUT_ID, ID);
		parameters.put("fixed", "false");
		Mockito.when(functionRequest.getParameters()).thenReturn(parameters);
		Mockito.when(handler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityData);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn(specificationID);
		Assert.assertNotNull(layoutCustomService.layoutFixedColumnSave(functionRequest, extensionHelper));
	}

	@Test
	public void addBasicColumnTest() throws Exception {

		parameters.put(LayoutConstants.DEFAULT_FLAG, "false");
		parameters.put(LayoutConstants.LAYOUT_ITEM_ID, ID);
		parameters.put(LayoutConstants.LAYOUT_ID, ID);
		parameters.put(LayoutConstants.SUBCATEGORY, "subCategory");
		Mockito.when(functionRequest.getParameters()).thenReturn(parameters);
		Mockito.when(entityData.getElementValue(LayoutConstants.SUBCATEGORY)).thenReturn("sss");
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList1);
		Assert.assertNotNull(layoutCustomService.addBasicColumn(functionRequest, extensionHelper));

	}

	/*
	 * Below method is testing the scenarios of saveDefaultLayout. Scenario -
	 * Passing the layoutlist as empty.
	 */

	@Test
	public void saveDefaultLayout() throws Exception {
		parameters.put(LayoutConstants.LAYOUT_ID, ID);
		Mockito.when(functionRequest.getParameters()).thenReturn(parameters);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn(ID);
		Assert.assertNotNull(layoutCustomService.saveUserDefaultLayout(functionRequest, extensionHelper));
	}

	/*
	 * Below method is testing the scenarios of saveDefaultLayout. Scenario -
	 * Passing the layoutlist as non-empty list.
	 */
	@Test
	public void saveDefaultLayout_emptyList() throws Exception {
		parameters.put(LayoutConstants.LAYOUT_ID, ID);
		Mockito.when(functionRequest.getParameters()).thenReturn(parameters);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(entityData.getElementValue(LayoutConstants.LAYOUT_ID)).thenReturn(ID);
		Assert.assertNotNull(layoutCustomService.saveUserDefaultLayout(functionRequest, extensionHelper));
	}

	/* Below test is testing catch block of function saveUserDefaultLayout */
	/*
	@Test
	public void saveUserDefaultLayoutExceptionTest() throws Exception {

		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenThrow(cdsException);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.setCause(cdsException)).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);

		Assert.assertNotNull(layoutCustomService.saveUserDefaultLayout(functionRequest, extensionHelper));
	}*/
}
