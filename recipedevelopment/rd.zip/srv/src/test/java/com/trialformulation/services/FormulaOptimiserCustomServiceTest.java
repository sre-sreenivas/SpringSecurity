package com.trialformulation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.EntityDataBuilder;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.OperationRequest;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponseBuilder;
import com.trialformulation.constants.FormulaOptimiserContants;

/**
 * Junit test case class for formulaOptimiserCustomService class.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ DataSourceHandlerFactory.class, EntityData.class, ErrorResponse.class,
		CDSDataSourceHandlerFactory.class })

public class FormulaOptimiserCustomServiceTest {

	private static final Logger LOGGER = Logger.getLogger(FormulaOptimiserCustomServiceTest.class.getName());
	private ExtensionHelper extensionHelper;
	private EntityData entityDataObj;
	private EntityData entityDataObjBlank;
	private DataSourceHandler dataSourceHandler;
	private DatasourceException datasourceException;
	private ErrorResponseBuilder errorResponseBuilderObject;
	private ErrorResponse errorResponseObject;
	private OperationRequest operationRequest;
	private EntityDataBuilder entityDataBuilder;
	private CDSDataSourceHandler cdsDataSourceHandler;
	private List<EntityData> entityDataList;

	FormulaOptimiserCustomService formulaOptimiserCustomService;
	String ID = "0eb8a795-a966-4d41-b900-e7843455f798";
	Map<String, Object> parameters;
	EntityDataBuilder entityDataBuilderObj;
	EntityDataBuilder entityDataForAdjacentRowBuilderObj;
	String SPECIFICATION_ID = "0eb8a795-a966-4d41-b900-e7843455f798";
	String recipeID = "0eb8a795-a966-4d41-b900-e7843455f798";
	String specID = "0eb8a795-a966-4d41-b900-e7843455f792";
	String UOM = "KG";
	Double density = 2.344;
	String description = "Test description";
	Double quantity = 0.5;
	String componentType = "Product";
	private CDSDataSourceHandler cDSDataSourceHandler;

	private CDSSelectQueryResult cDSSelectQueryResult;
	private CDSSelectQueryResult cDSSelectQueryResultForDraftEntity;

	List<EntityData> cDSSelectQueryResultList;
	List<EntityData> cDSSelectQueryResultListForDraft;

	/**
	 * This method is initializing the mock objects, having the common objects
	 * and when().thenReturn() for all the test cases.
	 * 
	 * @throws DatasourceException
	 */
	@Before
	public void setUp() throws DatasourceException {
		extensionHelper = Mockito.mock(ExtensionHelper.class);
		entityDataObj = Mockito.mock(EntityData.class);

		dataSourceHandler = Mockito.mock(DataSourceHandler.class);
		datasourceException = Mockito.mock(DatasourceException.class);
		errorResponseBuilderObject = Mockito.mock(ErrorResponseBuilder.class);
		errorResponseObject = Mockito.mock(ErrorResponse.class);
		formulaOptimiserCustomService = new FormulaOptimiserCustomService();
		operationRequest = Mockito.mock(OperationRequest.class);
		entityDataBuilder = Mockito.mock(EntityDataBuilder.class);
		cdsDataSourceHandler = Mockito.mock(CDSDataSourceHandler.class);
		entityDataList = new ArrayList<>();
		entityDataList.add(entityDataObj);
		Mockito.when(extensionHelper.getHandler()).thenReturn(dataSourceHandler);
		cDSDataSourceHandler = Mockito.mock(CDSDataSourceHandler.class);

		PowerMockito.mockStatic(DataSourceHandlerFactory.class);
		PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
		PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cdsDataSourceHandler);
		PowerMockito.mockStatic(EntityData.class);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);

		PowerMockito.mockStatic(EntityData.class);
		PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
		PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cDSDataSourceHandler);
		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
		cDSSelectQueryResultList = new ArrayList<>();

		// new

		cDSSelectQueryResultForDraftEntity = Mockito.mock(CDSSelectQueryResult.class);
		cDSSelectQueryResultListForDraft = new ArrayList<>();

		Mockito.when(entityDataObj.getElementValue(Mockito.anyString())).thenReturn(entityDataObj);
		entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
		PowerMockito.mockStatic(ErrorResponse.class);
		PowerMockito.when(ErrorResponse.getBuilder()).thenReturn(errorResponseBuilderObject);
		parameters = new HashMap<String, Object>();
		parameters.put(FormulaOptimiserContants.RECIPE_ID, ID);
		parameters.put(FormulaOptimiserContants.SPECIFICATION_ID, ID);
		parameters.put(FormulaOptimiserContants.VALIDATE_UOM, UOM);
		parameters.put(FormulaOptimiserContants.RECIPE_ID, recipeID);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.QUANTITY)).thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.DENSITY)).thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.PIECE_TO_MASS))
				.thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.KG);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.G);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.TO);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.L);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.ML);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.PC);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM))
				.thenReturn(FormulaOptimiserContants.EA);
		Mockito.when(entityDataObj.getElementValue("ID")).thenReturn(ID);
		Mockito.when(entityDataObj.getElementValue("specificationID")).thenReturn(recipeID);

	}

	/*
	 * Below method is testing the scenarios of adding the specifications
	 * (formula Item) to recipe. Scenario - Passing the specificationID with
	 * different itemNumber and nextItemNumber.
	 */

	@Test
	public void addSpecificationWithMultipleItemNum() throws Exception {
		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObj);

		HashMap<Integer, Integer> itemNumberHashmap = new HashMap<Integer, Integer>();
		itemNumberHashmap.put(1, null);
		itemNumberHashmap.put(0, null);
		itemNumberHashmap.put(100, null);
		itemNumberHashmap.put(100, 100);
		itemNumberHashmap.put(100000, 100000);
		itemNumberHashmap.put(1000, null);
		itemNumberHashmap.put(10, 11);
		itemNumberHashmap.put(991, null);
		itemNumberHashmap.put(null, null);

		parameters.put(FormulaOptimiserContants.RECIPE_ID, ID);
		parameters.put(FormulaOptimiserContants.SPECIFICATION_ID, ID);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilderObj);

		for (Integer entry : itemNumberHashmap.keySet()) {
			parameters.put(FormulaOptimiserContants.ITEM_NUMBER, entry == null ? null : Integer.toString(entry));
			parameters.put(FormulaOptimiserContants.NEXT_ITEM_NUMBER,
					itemNumberHashmap.get(entry) == null ? null : itemNumberHashmap.get(entry));
			Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
			Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString()))
					.thenReturn(errorResponseBuilderObject);
			Mockito.when(errorResponseBuilderObject.addErrorDetail(FormulaOptimiserContants.ITEMNUM_GR_999,
					FormulaOptimiserContants.ITEM_NUM_VALUE)).thenReturn(errorResponseBuilderObject);
			Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);

			Assert.assertNotNull(formulaOptimiserCustomService.addSpecification(operationRequest, extensionHelper));
		}
	}

	/*
	 * Below method is testing the negative scenario of adding the
	 * specifications (formula Item) to recipe. Scenario - Passing the
	 * specificationID null
	 */

	@Test
	public void addingBlankSpecificationID() throws Exception {
		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObj);
		parameters = new HashMap<String, Object>();
		parameters.put(FormulaOptimiserContants.RECIPE_ID, ID);
		parameters.put(FormulaOptimiserContants.SPECIFICATION_ID, "");
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilderObj);
		Assert.assertNotNull(formulaOptimiserCustomService.addSpecification(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing updateDraftSpecificationValues method it is used
	 * for changing the values of recipespecifications entity
	 */

	@Test
	public void updateDraftSpecificationValuesTest() throws Exception {

		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObj);

		parameters.put(FormulaOptimiserContants.UOM, UOM);
		parameters.put(FormulaOptimiserContants.QUANTITY, quantity);
		parameters.put(FormulaOptimiserContants.COMPONENT_TYPE, componentType);
		parameters.put(FormulaOptimiserContants.SPECIFICATION_DESCRIPTION, description);
		parameters.put(FormulaOptimiserContants.SPECIFICATION_ID, ID);
		parameters.put(FormulaOptimiserContants.DENSITY, density);
		parameters.put(FormulaOptimiserContants.FORMULA_ITEM_DESCRIPTION, description);

		Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilderObj);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Assert.assertNotNull(
				formulaOptimiserCustomService.updateDraftSpecificationValues(operationRequest, extensionHelper));
	}

	@Test
	public void updateDraftSpecificationValuesExceptionTest() throws Exception {

		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenThrow(datasourceException);
		parameters.put(FormulaOptimiserContants.QUANTITY, quantity);

		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.setCause(datasourceException)).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);

		Assert.assertNotNull(
				formulaOptimiserCustomService.updateDraftSpecificationValues(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing a valid specificationId in specification table if
	 * it is there then it will throw a success message
	 */

	@Test
	public void validateValidSpecificationIdTest() throws Exception {

		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObj);

		parameters.put(FormulaOptimiserContants.SPECIFICATION_ID, ID);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);

		Assert.assertNotNull(formulaOptimiserCustomService.validateSpecificationId(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing a valid specificationId in specification table if
	 * it is not there then it will throw a error message
	 */

	@Test
	public void validateInValidSpecificationIdTest() throws Exception {

		entityDataObjBlank = null;
		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObjBlank);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);
		Assert.assertNotNull(formulaOptimiserCustomService.validateSpecificationId(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing a valid specificationId in specification table if
	 * it is not there then it will throw a error message
	 */

	@Test
	public void validateExceptionSpecificationIdTest() throws Exception {

		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenThrow(datasourceException);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.setCause(datasourceException)).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);

		Assert.assertNotNull(formulaOptimiserCustomService.validateSpecificationId(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing function deleteFormulaItem which is deleting
	 * formula item by item number from recipeSpecificationDraft table
	 */

	@Test
	public void deleteFormulaItemTest() throws Exception {

		parameters.put(FormulaOptimiserContants.ITEM_NUMBER, ID);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(dataSourceHandler.executeDelete(Mockito.anyString(), Mockito.anyObject())).thenReturn(false);

		Assert.assertNotNull(formulaOptimiserCustomService.deleteFormulaItem(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing catch block of function deleteFormulaItem
	 */
	@Test
	public void deleteFormulaItemExceptionTest() throws Exception {

		parameters.put(FormulaOptimiserContants.ITEM_NUMBER, ID);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(dataSourceHandler.executeDelete(Mockito.anyString(), Mockito.anyObject()))
				.thenThrow(datasourceException);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.setCause(datasourceException)).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);

		Assert.assertNotNull(formulaOptimiserCustomService.deleteFormulaItem(operationRequest, extensionHelper));
	}

	/*
	 * Below test is testing the getLayoutList function. Success scenario -
	 * sending the Layout List of User Specific Layout created by the logged in
	 * user to the UI. If there is no layout created by the logged in user then
	 * we are sending the Global Default layout to the UI.
	 */

	@Test
	public void getLayoutListTest() throws Exception {

		entityDataObjBlank = Mockito.mock(EntityData.class);
		Mockito.when(entityDataObjBlank.getElementValue(FormulaOptimiserContants.ID))
				.thenReturn(FormulaOptimiserContants.ID);
		cDSSelectQueryResultList.add(entityDataObjBlank);
		Mockito.when(entityDataObj.getElementValue(Mockito.anyString())).thenReturn(entityDataObj);
		cDSSelectQueryResultListForDraft.add(entityDataObj);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult,
				cDSSelectQueryResultForDraftEntity);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(cDSSelectQueryResultForDraftEntity.getResult()).thenReturn(cDSSelectQueryResultListForDraft);
		Mockito.when(entityDataBuilderObj.buildEntityData(FormulaOptimiserContants.LAYOUT_INFORMATION_ENTITY))
				.thenReturn(entityDataObj);
		Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilderObj);
		Assert.assertNotNull(formulaOptimiserCustomService.getLayoutList(operationRequest, extensionHelper));
	}

	/**
	 * Below method is testing the condition when fetchlayoutListFromDB return
	 * null. Success scenario :If there is no layout created by the logged in
	 * user. Here we are passing not passing the cDSSelectQueryResultList.
	 */

	@Test
	public void layoutResultListIsEmptyTest() throws Exception {

		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Assert.assertNotNull(formulaOptimiserCustomService.getLayoutList(operationRequest, extensionHelper));

	}

	/**
	 * Below method is testing the condition fetchlayoutListFromDB is empty for
	 * the logged In user. Here we are using spy object to mock the private
	 * method 'fetchlayoutListFromDB' and 'layoutResultListEmpty'
	 */

	@Test
	public void fetchlayoutListFromDBTest() {

		try {
			Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
			Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
			FormulaOptimiserCustomService formulaOptimiserCustomServiceSpy = PowerMockito
					.spy(formulaOptimiserCustomService);
			PowerMockito
					.when(formulaOptimiserCustomServiceSpy, "fetchlayoutListFromDB",
							FormulaOptimiserContants.LAYOUT_TYPE, FormulaOptimiserContants.DEFAULT)
					.thenReturn(cDSSelectQueryResultList);
			cDSSelectQueryResultList.add(entityDataObj);
			Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
					.thenReturn(entityDataBuilderObj);
			Mockito.when(entityDataObj.getElementValue(Mockito.anyString())).thenReturn(entityDataObj);
			List<EntityData> layoutList = new ArrayList<>();
			PowerMockito.when(formulaOptimiserCustomServiceSpy, "layoutResultListEmpty", extensionHelper, layoutList)
					.thenReturn(null);
			Assert.assertTrue(true);
		} catch (Exception e) {

			LOGGER.error(e.getMessage(), e);
			Assert.assertFalse(false);
		}

	}

	/**
	 * Below method is testing the reorderSpecificationID function. Success
	 * scenario : reordering the selected specification when we select up/down
	 * arrow from UI.Here we are mocking to reOrderAction as up/down for
	 * swapping there Item numbers in the code.
	 */

	@Test
	public void reorderSpecificationIDTest() throws CDSException {

		List<String> reOrderAction = new ArrayList<>();
		reOrderAction.add(FormulaOptimiserContants.BUTTON_UP);
		reOrderAction.add(FormulaOptimiserContants.BUTTON_DOWN);
		for (String orderActions : reOrderAction) {

			System.out.println("reOrderAction" + reOrderAction);
			parameters.put(FormulaOptimiserContants.REORDER_ACTION, orderActions);
			Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
			cDSSelectQueryResultList.add(entityDataObj);
			Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
			Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
			Mockito.when(entityDataObj.getElementValue(Mockito.anyString())).thenReturn(entityDataObj);
			Mockito.when(
					entityDataBuilderObj.buildEntityData(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY))
					.thenReturn(entityDataObj);
			Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
					.thenReturn(entityDataBuilderObj);
			Assert.assertNotNull(
					formulaOptimiserCustomService.reorderSpecificationID(operationRequest, extensionHelper));
		}
	}

	/**
	 * Below method is testing the Private method swapItemNumber. Here we are
	 * mocking to entityData objects for swapping there Item numbers in the
	 * code.
	 */

	@Test
	public void swapItemNumberTest() {

		EntityData entityDataForAdjacentRow = Mockito.mock(EntityData.class);
		Mockito.when(entityDataForAdjacentRow.getElementValue(FormulaOptimiserContants.ITEM_NUMBER)).thenReturn(1);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.ITEM_NUMBER)).thenReturn(2);
		entityDataForAdjacentRowBuilderObj = Mockito.mock(EntityDataBuilder.class);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataForAdjacentRowBuilderObj);
		Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilderObj);
		Mockito.when(entityDataForAdjacentRowBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataForAdjacentRowBuilderObj);
		Mockito.when(entityDataForAdjacentRowBuilderObj.removeElement(FormulaOptimiserContants.ITEM_NUMBER))
				.thenReturn(entityDataForAdjacentRowBuilderObj);
		Mockito.when(entityDataForAdjacentRowBuilderObj.addElement(FormulaOptimiserContants.ITEM_NUMBER,
				entityDataObj.getElementValue(FormulaOptimiserContants.ITEM_NUMBER)))
				.thenReturn(entityDataForAdjacentRowBuilderObj);
		Mockito.when(entityDataForAdjacentRowBuilderObj
				.buildEntityData(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY))
				.thenReturn(entityDataForAdjacentRow);
		Mockito.when(entityDataBuilderObj.buildEntityData(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY))
				.thenReturn(entityDataObj);
		FormulaOptimiserCustomService formulaOptimiserCustomServiceSpy = PowerMockito
				.spy(formulaOptimiserCustomService);
		try {
			PowerMockito.when(formulaOptimiserCustomServiceSpy, "swapItemNumber", entityDataObj,
					entityDataForAdjacentRow, extensionHelper).thenReturn(null);
			Assert.assertTrue(true);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			Assert.assertFalse(false);

		}
	}

	/* Below is the test case for formulaQuantityCalculation function import */

	@Test
	public void formulaQuantityCalculationTest() throws Exception {

		parameters.put(FormulaOptimiserContants.RECIPE_ID, recipeID);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		entityDataList.add(entityDataObj);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(entityDataList);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.SPEC_QUANTITY))
				.thenReturn(new BigDecimal("2.344"));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.UOM)).thenReturn("C");
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.FORMULA_DENSITY))
				.thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.FORMULA_PIECE_TO_MASS))
				.thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.FORMULA_SPEC_ID)).thenReturn(recipeID);
		Mockito.when(entityDataBuilder.buildEntityData(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY))
				.thenReturn(entityDataObj);

		Assert.assertNotNull(
				formulaOptimiserCustomService.formulaQuantityCalculation(operationRequest, extensionHelper));

	}

	/*
	 * Below test case is testing the private method getSumOfQuantity() using
	 * PowerMockito.spy
	 */

	@Test
	public void getSumOfQuantityTest() throws Exception {
		FormulaOptimiserCustomService formulaOptimiserCustomServiceSpy = PowerMockito
				.spy(formulaOptimiserCustomService);

		entityDataList.add(entityDataObj);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(entityDataList);

		Double sumOfQuantity = 12.3;
		Double piecetoMass = 1.1;
		List<String> uomList = new ArrayList<>();
		uomList.add(FormulaOptimiserContants.KG);
		uomList.add(FormulaOptimiserContants.CM3);
		uomList.add(FormulaOptimiserContants.DEPENDENCY);
		uomList.add("other");

		for (String uom : uomList) {
			Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.KG)).thenReturn(null);
			Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.CM3)).thenReturn(null);
			Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.DEPENDENCY)).thenReturn(null);
			Mockito.when(entityDataList.get(0).getElementValue(uom)).thenReturn(1.1);
			PowerMockito.when(formulaOptimiserCustomServiceSpy, "getSumOfQuantity", sumOfQuantity, quantity, uom,
					density, piecetoMass).thenReturn(sumOfQuantity);

		}
	}

	/*
	 * Below is the test case for exception scenario in formulaQuantityException
	 * function import
	 */

	@Test
	public void formulaQuantityCalculationExceptionTest() throws Exception {
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(entityDataList);
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.SPEC_QUANTITY))
				.thenReturn(new BigDecimal("2.344"));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.FORMULA_DENSITY))
				.thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.FORMULA_PIECE_TO_MASS))
				.thenReturn(new Double(2.344));
		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.FORMULA_SPEC_ID)).thenReturn(recipeID);
		Mockito.when(dataSourceHandler.executeUpdate(Mockito.anyObject(), Mockito.anyObject(), Mockito.anyBoolean()))
				.thenThrow(datasourceException);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.setCause(datasourceException)).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);

		Assert.assertNotNull(
				formulaOptimiserCustomService.formulaQuantityCalculation(operationRequest, extensionHelper));
	}

	/* Below test case is for the scenario where user enters invalid UOM */

	@Test
	public void invalidUomTest() throws Exception {
		entityDataObjBlank = null;
		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObjBlank);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);
		Assert.assertNotNull(
				formulaOptimiserCustomService.validateManuallyEnteredUOM(operationRequest, extensionHelper));

	}

	/* Below test case is for the scenario where user enters valid UOM */
	@Test
	public void validUomTest() throws Exception {
		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenReturn(entityDataObj);

		parameters.put(FormulaOptimiserContants.VALIDATE_UOM, UOM);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);

		Assert.assertNotNull(
				formulaOptimiserCustomService.validateManuallyEnteredUOM(operationRequest, extensionHelper));

	}
	/*
	 * Below test case is for the exception scenario in case of validating UOM
	 */

	@Test
	public void validateUomExceptionTest() throws Exception {

		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
				.thenThrow(datasourceException);
		Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
		Mockito.when(errorResponseBuilderObject.setMessage(Mockito.anyString())).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.setCause(datasourceException)).thenReturn(errorResponseBuilderObject);
		Mockito.when(errorResponseBuilderObject.response()).thenReturn(errorResponseObject);
		Assert.assertNotNull(
				formulaOptimiserCustomService.validateManuallyEnteredUOM(operationRequest, extensionHelper));
	}
}
