package com.trialformulation.services;

import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner; 
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryBuilder;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.EntityDataBuilder;
import com.sap.cloud.sdk.service.prov.api.EntityMetadata;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.request.CreateRequest;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.request.ReadRequest;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponseAccessor;
import com.trialformulation.constants.FormulaOptimiserContants;

 /**
  * Junit test case class for EvaluationHooksHandler class.
  */

 @RunWith(PowerMockRunner.class)
 @PrepareForTest({  DataSourceHandlerFactory.class, EntityData.class,
 		ODataQueryBuilder.class, CDSDataSourceHandlerFactory.class })
 public class FormulaOptimiserHooksHandlerTest {

 	private QueryRequest queryRequest;  	
 	private ReadRequest readRequest;
 	private CreateRequest createRequest;
 	private ExtensionHelper extensionHelper;
 	private EntityMetadata entityMetadata;
 	private EntityData entityDataObj;
 	private DataSourceHandlerFactory dataSourceHandlerFactory;
 	private QueryResponseAccessor queryResponse;
 	private CDSDataSourceHandler cDSDataSourceHandler;
 	private CDSSelectQueryResult cDSSelectQueryResult;
 	private EntityDataBuilder entityDataBuilder;
	private DataSourceHandler dataSourceHandler;
 	FormulaOptimiserHooksHandler formulaOptimiserHooksHandler;
 	ReadResponseAccessor readResponseAccessor;
 	CreateResponseAccessor createResponseAccessor;
 	List<EntityData> recipeEntityData;
 	List<EntityData> cDSSelectQueryResultList;
 	String recipeID = "0eb8a795-a966-4d41-b900-e7843455f798";
 	String recipeStatus = "New";
        String evalId = "b2aed717-8d45-47d8-b99f-30ffff8a07de";
        String evalName = "abc";
        String nextRecipeStatus = "InProgress";
        String nextStatus = "sss";
        String recipeStatus_null = null;
        String evalId_null = null;
        String evalName_null = null;
    
 	/**
 	 * This method is initializing the mock objects, having the common objects and
 	 * when().thenReturn() for all the test cases.
 	 * @throws CDSException 
 	 */
 	@Before
 	public void setUp() throws CDSException {

 		queryResponse = Mockito.mock(QueryResponseAccessor.class); 	
 		readRequest = Mockito.mock(ReadRequest.class);
 		createRequest = Mockito.mock(CreateRequest.class);
 		extensionHelper = Mockito.mock(ExtensionHelper.class);
 		readResponseAccessor = Mockito.mock(ReadResponseAccessor.class);
 		createResponseAccessor = Mockito.mock(CreateResponseAccessor.class);
 		queryRequest = Mockito.mock(QueryRequest.class);
 		entityMetadata = Mockito.mock(EntityMetadata.class);
 		entityDataObj = Mockito.mock(EntityData.class);
 		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
 		dataSourceHandlerFactory = Mockito.mock(DataSourceHandlerFactory.class);
 		cDSDataSourceHandler = Mockito.mock(CDSDataSourceHandler.class);
 		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
 		entityDataBuilder = Mockito.mock(EntityDataBuilder.class);
		dataSourceHandler = Mockito.mock(DataSourceHandler.class);
 		formulaOptimiserHooksHandler = new FormulaOptimiserHooksHandler();
 		recipeEntityData = new ArrayList<>();
 		recipeEntityData.add(entityDataObj);
 		cDSSelectQueryResultList = new ArrayList<>();
 		cDSSelectQueryResultList.add(entityDataObj); 		
 		PowerMockito.mockStatic(ODataQueryBuilder.class); 		
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.RECIPE_ID)).thenReturn(recipeID);
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.EVALUATION_ID)).thenReturn(evalId);
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.EVALUATION_NAME)).thenReturn(evalName);
 		Mockito.when(queryResponse.getEntityDataList()).thenReturn(recipeEntityData);
 		Mockito.when(queryRequest.getEntityMetadata()).thenReturn(entityMetadata);
 		Mockito.when(entityMetadata.getNamespace()).thenReturn(FormulaOptimiserContants.DATA_MODEL); 		
 		PowerMockito.mockStatic(DataSourceHandlerFactory.class);
 		PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
 		PowerMockito.when(DataSourceHandlerFactory.getInstance()).thenReturn(dataSourceHandlerFactory);
 		PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cDSDataSourceHandler);
 		Mockito.when(dataSourceHandlerFactory.getCDSHandler(Mockito.anyObject(), Mockito.anyObject()))
 				.thenReturn(cDSDataSourceHandler);
 		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
 		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);

 		PowerMockito.mockStatic(EntityData.class);
 		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
 		Mockito.when(entityDataBuilder.addElement(Mockito.anyString(), Mockito.anyObject()))
 				.thenReturn(entityDataBuilder);
 		Mockito.when(entityDataBuilder.buildEntityData(FormulaOptimiserContants.RECIPE)).thenReturn(entityDataObj);
		Mockito.when(extensionHelper.getHandler()).thenReturn(dataSourceHandler);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
			
 	}
	
 	/*
 	 * This method is testing the positive scenario of afterReadDraft method.
 	 * Success Scenario - This method is modifying response to add Evaluation ID and name in concatenated string ,
	 * recipe next status and criticality to recipe entity.*/
 	@Test
 	public void afterReadRecipe_mockAllElement_addToResponse() throws CDSException { 	
 		Mockito.when(readRequest.getEntityMetadata()).thenReturn(entityMetadata);
 		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
 		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
 		Mockito.when(readResponseAccessor.getEntityData()).thenReturn(entityDataObj);
 		formulaOptimiserHooksHandler.afterReadRecipe(readRequest, readResponseAccessor, extensionHelper);
 		Assert.assertNotNull(
 				formulaOptimiserHooksHandler.afterReadRecipe(readRequest, readResponseAccessor, extensionHelper));
 	}

	
	@Test
 	public void afterReadRecipe_nullCheck() throws CDSException { 	
 		Mockito.when(readRequest.getEntityMetadata()).thenReturn(entityMetadata);
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.EVALUATION_ID)).thenReturn(evalId_null);
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.EVALUATION_NAME)).thenReturn(evalName_null);
 		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
 		Mockito.when(readResponseAccessor.getEntityData()).thenReturn(entityDataObj);
 		formulaOptimiserHooksHandler.afterReadRecipe(readRequest, readResponseAccessor, extensionHelper);
 		Assert.assertNotNull(
 				formulaOptimiserHooksHandler.afterReadRecipe(readRequest, readResponseAccessor, extensionHelper));
 	}
 	/**
 	 * Below method is testing the success scenario of beforeCreateEvaluation
 	 * method. Success Scenario - For a particular recipe entity, This method is checking the mandatory fields if those are empty and setting the default status to New.
 	 *  
 	 */
 	 
 	@Test
 	public void setDefaultValueAndMandortyFieldValidationTest() { 		
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.RECIPE_DESCRIPTION)).thenReturn(FormulaOptimiserContants.RECIPE_DESCRIPTION);
 		Mockito.when(createRequest.getData()).thenReturn(entityDataObj); 	
 		formulaOptimiserHooksHandler.setDefaultValueAndMandatoryFieldValidation(createRequest, extensionHelper);
 		Assert.assertNotNull(entityDataObj.getElementValue(FormulaOptimiserContants.RECIPE_ID));

 	}
	
	/**
 	 * Below Test is testing the addRecipeSpecificationDraftDefaultValues method which is used to insert by default value in 
 	 * draft table of recipeSpecification while creating the recipe.
 	*/
 	@Test
 	public void addRecipeSpecificationDraftDefaultValuesTest() throws CDSException { 
 		
 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.RECIPE_ID)).thenReturn(recipeID);
 		Mockito.when(createResponseAccessor.getEntityData()).thenReturn(entityDataObj);
 		Assert.assertNotNull(
 				formulaOptimiserHooksHandler.addRecipeSpecificationDraftDefaultValues(createRequest, createResponseAccessor, extensionHelper));

 	} 
 	
 	@Test
 	public void addRecipeSpecificationDraftDefaultValuesWhenNotNull() throws Exception{
 		Mockito.when(createResponseAccessor.getEntityData()).thenReturn(entityDataObj);

 		Mockito.when(entityDataObj.getElementValue(FormulaOptimiserContants.RECIPE_ID)).thenReturn(recipeID);
 		
 		Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
		.thenReturn(entityDataObj);
 		Assert.assertNotNull(
 				formulaOptimiserHooksHandler.addRecipeSpecificationDraftDefaultValues(createRequest, createResponseAccessor, extensionHelper));

 		
 	}
	
 }
