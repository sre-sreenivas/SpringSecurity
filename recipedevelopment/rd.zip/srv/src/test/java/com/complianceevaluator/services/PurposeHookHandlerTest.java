package com.complianceevaluator.services;

import com.complianceevaluator.services.PurposeHookHandler;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.odatav2.connectivity.ODataException;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQuery;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryBuilder;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryResult;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;



@RunWith(PowerMockRunner.class)
@PrepareForTest({ DataSourceHandlerFactory.class, EntityData.class, ODataQueryBuilder.class })
public class PurposeHookHandlerTest {
     
    @Mock
    private ODataQueryResult odataQueryResult;
    private QueryResponseAccessor queryResponseAccessor;
    private ODataQuery odataQuery;
    private ODataQueryBuilder oDataQueryBuilder;
    private QueryRequest queryRequest;
    private ExtensionHelper extensionHelper; 
    JSONObject jsonObj;
    JSONArray jsonArr;
    private PurposeHookHandler purposeHookHandler;
 
    @Before
    public void setUp() {

        odataQueryResult = Mockito.mock(ODataQueryResult.class);
        oDataQueryBuilder = Mockito.mock(ODataQueryBuilder.class);
        purposeHookHandler = new PurposeHookHandler();
        odataQuery = Mockito.mock(ODataQuery.class);
        queryResponseAccessor = Mockito.mock(QueryResponseAccessor.class);
        jsonObj = Mockito.mock(JSONObject.class);
        jsonArr = Mockito.mock(JSONArray.class);     
        PowerMockito.mockStatic(ODataQueryBuilder.class);
        PowerMockito.when(ODataQueryBuilder.withEntity(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(oDataQueryBuilder);    
    }
 
    @Test
    public void afterReadEvaluationPurposeTest() throws CDSException, ODataException , JSONException{
     
        String jsonString = "{\r\n" + "value: [\r\n" + "{\"CmplncPrpsUUID\":\"0894ef45-8661-1ed9-b2cc-92f4c10e352d\",\"CmplncPrps\":\"Z0006\",\"CreationDateTime\":\"2019-08-29T13:55:01Z\",\"CreatedByUser\":\"VANOV\",\"CmplncPrpsActivationStatus\":\"A\",\"CmplncPrpsName\":\"testData\"},"
                        + "{\"CmplncPrpsUUID\":\"0894ef45-8661-1eda-8fa6-6609e68fb12c\",\"CmplncPrps\":\"P00412\",\"CreationDateTime\":\"2020-01-22T16:21:05.486152Z\",\"CreatedByUser\":\"GEISSLERF\",\"CmplncPrpsActivationStatus\":\"A\",\"CmplncPrpsName\":\"FG Purpose 1\"}\r\n" + "]\r\n" + "}";
     
        Mockito.when(oDataQueryBuilder.withHeader("sap-client", "001", true)).thenReturn(oDataQueryBuilder);
        Mockito.when(oDataQueryBuilder.withHeader("sap-language", "en", true)).thenReturn(oDataQueryBuilder);
        Mockito.when(oDataQueryBuilder.select("CmplncPrpsName", "CmplncPrpsUUID", "CreatedByUser", "CreationDateTime", "CmplncPrpsActivationStatus"))
                .thenReturn(oDataQueryBuilder);
        Mockito.when(oDataQueryBuilder.select(Mockito.anyString())).thenReturn(oDataQueryBuilder);
        Mockito.when(oDataQueryBuilder.withoutMetadata()).thenReturn(oDataQueryBuilder);
        Mockito.when(oDataQueryBuilder.build()).thenReturn(odataQuery);
        Mockito.when(odataQuery.execute("ER1CLNT")).thenReturn(odataQueryResult);
        Mockito.when(odataQueryResult.getStreamData()).thenReturn(jsonString);
        Mockito.when(jsonObj.get("value")).thenReturn(jsonArr);   
     
        Assert.assertNotNull(purposeHookHandler.getPurpose(queryRequest, queryResponseAccessor, extensionHelper));
    }



}
