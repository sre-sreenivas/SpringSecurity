package com.complianceevaluator.services;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import com.complianceevaluator.constants.EvaluationConstants;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSQuery;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.EntityDataBuilder;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.OperationRequest;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponseBuilder;

/**
// * Junit test case class for EvaluationCustomService class.
// *
// */
@RunWith(PowerMockRunner.class)
@PrepareForTest({  DataSourceHandlerFactory.class, EntityData.class, ErrorResponse.class, CDSDataSourceHandlerFactory.class})
public class EvaluationCustomServiceTest {
			CDSQuery cdsQuery;
			 CDSDataSourceHandler cdsDataSourceHandler;
			 CDSSelectQueryResult cdsSelectQueryResult;
			java.util.List<EntityData> entityDataList;
              private ExtensionHelper extensionHelper;
              private EntityData entityData;
              private DataSourceHandler dataSourceHandler;
              private OperationRequest operationRequest;
              EvaluationCustomService evaluationCustomService;
              String evaluationID = "0eb8a795-a966-4d41-b900-e7843455f798";
              String recipeID = "0eb8a795-a966-4d41-b900-e7843455f792";
              String evalStatus = "New";
              DatasourceException datasourceException;
              ErrorResponseBuilder errorResponseBuilderObject;
              ErrorResponse errorResponseObject;
              /**
              * This method is initializing the mock objects, having the common objects and
              * when().thenReturn() for all the test cases.
              * 
               * @throws DatasourceException
              */
              @Before
              public void setUp() throws DatasourceException {
            	  cdsQuery=Mockito.mock(CDSQuery.class);
            	  entityDataList=new ArrayList<>();
            	  cdsSelectQueryResult=Mockito.mock(CDSSelectQueryResult.class);
            	  		cdsDataSourceHandler= Mockito.mock(CDSDataSourceHandler.class);
                             extensionHelper = Mockito.mock(ExtensionHelper.class);
                             entityData = Mockito.mock(EntityData.class);
                             dataSourceHandler = Mockito.mock(DataSourceHandler.class);
                             evaluationCustomService = new EvaluationCustomService();
                             operationRequest = Mockito.mock(OperationRequest.class);
                             datasourceException = Mockito.mock(DatasourceException.class);
                             errorResponseBuilderObject = Mockito.mock(ErrorResponseBuilder.class);
                             errorResponseObject =  Mockito.mock(ErrorResponse.class);
              Mockito.when(entityData.getElementValue(EvaluationConstants.EVALUATION_ID)).thenReturn(evaluationID);
                 Mockito.when(extensionHelper.getHandler()).thenReturn(dataSourceHandler);
                            PowerMockito.mockStatic(DataSourceHandlerFactory.class);
                             PowerMockito.mockStatic(EntityData.class);
                             PowerMockito.mockStatic(ErrorResponse.class);
                             PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
                             PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cdsDataSourceHandler);
              }
              

              @Test
              public void evaluationStatusSaveTest() throws DatasourceException {
                             EntityData entityDataObj = Mockito.mock(EntityData.class);
                         Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
                             .thenReturn(entityDataObj);
                             List<String> statusList=new ArrayList<>();
                             statusList.add(EvaluationConstants.STATUS_NEW);
                             statusList.add(EvaluationConstants.STATUS_IN_PROGRESS);
                             statusList.add(EvaluationConstants.CLOSED);
                             statusList.add("other");
              Mockito.when(entityDataObj.getElementValue(Mockito.anyString())).thenReturn(entityDataObj);
                             EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
                             PowerMockito.mockStatic(EntityData.class);
                             Map<String, Object> parameters = new HashMap<>();
                             parameters.put(EvaluationConstants.ID, EvaluationConstants.ONE);
                             for(String status: statusList) {
                             parameters.put(EvaluationConstants.EVAL_STATUS,status);
                             
              Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
              PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
              Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
           //   Mockito.when(getStatusCriticality("New"))
                       Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject())).thenReturn(entityDataBuilderObj);
              Assert.assertNotNull(evaluationCustomService.evaluationStatusSave(operationRequest, extensionHelper));
                             }
              }
             
              
              
              
              
              

              /**
              * Below method is testing the success scenario of updateSellignMarket function.
              * Success Scenario - Updating the multiple Selling Market in concatenated
              * string for evaluation ID in Evaluation entity..
              */

              @Test
              public void updateSellingMarketTest() throws DatasourceException {
                             EntityData entityDataObj = Mockito.mock(EntityData.class);
              PowerMockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject()))
                                                          .thenReturn(entityDataObj);
                             EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
                             PowerMockito.mockStatic(EntityData.class);
              PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
              Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
                       Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject()))
                                                          .thenReturn(entityDataBuilderObj);
                            evaluationCustomService.updateSellignMarket(operationRequest, extensionHelper);
              Assert.assertNotNull(evaluationCustomService.updateSellignMarket(operationRequest, extensionHelper));
              }

              /**
              * Below method is testing the success scenario of removeDuplicateRecipe
              * function Success Scenario - Duplicate Recipe Validation for evaluation ID. If
              * the Recipe is existing in Recipe_Drafts table removeDuplicateRecipe function
              * is sending the Recipe ID in response to the UI.
              */

   

    @Test
    public void addRecipeTest() throws DatasourceException {
      
        EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
     
        PowerMockito.mockStatic(EntityData.class);
        PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
     
        Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
        Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject())).thenReturn(entityDataBuilderObj);
     
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("recipeId",recipeID);
        parameters.put(EvaluationConstants.EVALUATION_ID,evaluationID);
        Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
        Mockito.when(cdsDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cdsSelectQueryResult);
       
       entityDataList.add(entityData);
       
        Mockito.when(entityData.getElementValue(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID)).thenReturn(UUID.randomUUID());
        Mockito.when(cdsSelectQueryResult.getResult()).thenReturn(entityDataList);
       
        Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject())).thenReturn(entityData);
        evaluationCustomService.addRecipe(operationRequest, extensionHelper);
        Assert.assertNotNull(evaluationCustomService.addRecipe(operationRequest, extensionHelper));
    }

   
   
    @Test
    public void addPurposeTest() throws DatasourceException {
        
        EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
       
        PowerMockito.mockStatic(EntityData.class);
        PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
       
        Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
        Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject())).thenReturn(entityDataBuilderObj);
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("purposeId", EvaluationConstants.PURPOSE_ID);
       
        Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
        Mockito.when(dataSourceHandler.executeRead(Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject())).thenReturn(entityData);
       
        evaluationCustomService.addPurpose(operationRequest, extensionHelper);
        Assert.assertNotNull(evaluationCustomService.addPurpose(operationRequest, extensionHelper));
       
    }
   
 
   @Test
   public void copyRecipe_Test() throws DatasourceException{
                 
       EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
      
       PowerMockito.mockStatic(EntityData.class);
       PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
      
       Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
       Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject())).thenReturn(entityDataBuilderObj);
      
       Map<String, Object> parameters = new HashMap<String, Object>();
       parameters.put("recipeId",recipeID);
       parameters.put(EvaluationConstants.EVALUATION_ID,evaluationID);       
       Mockito.when(cdsDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cdsSelectQueryResult);
       entityDataList.add(entityData);
       
       Mockito.when(entityData.getElementValue(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID)).thenReturn(UUID.randomUUID());
       Mockito.when(cdsSelectQueryResult.getResult()).thenReturn(entityDataList);
      
       Mockito.when(dataSourceHandler.executeInsert(entityData, false)).thenReturn(entityData);
                 Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
                 Assert.assertNotNull(evaluationCustomService.copyRecipe(operationRequest, extensionHelper));
   }
  
  
   @Test
   public void saveRecipe_Test() throws DatasourceException{
                 
       EntityDataBuilder entityDataBuilderObj = Mockito.mock(EntityDataBuilder.class);
      
       PowerMockito.mockStatic(EntityData.class);
       PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilderObj);
      
       Mockito.when(entityDataBuilderObj.removeElement(Mockito.anyString())).thenReturn(entityDataBuilderObj);
       Mockito.when(entityDataBuilderObj.addElement(Mockito.anyString(), Mockito.anyObject())).thenReturn(entityDataBuilderObj);
      
       Map<String, Object> parameters = new HashMap<String, Object>();
       parameters.put("recipeId", EvaluationConstants.RECIPE_ID);
       Mockito.when(dataSourceHandler.executeInsert(entityData, false)).thenReturn(entityData);
                 Mockito.when(operationRequest.getParameters()).thenReturn(parameters);
                 Assert.assertNotNull(evaluationCustomService.saveRecipe(operationRequest, extensionHelper));
   }
  
}
