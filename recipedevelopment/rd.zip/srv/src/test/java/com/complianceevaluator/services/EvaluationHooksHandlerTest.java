package com.complianceevaluator.services;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import com.complianceevaluator.constants.EvaluationConstants;
import com.sap.cloud.sdk.cloudplatform.security.AuthTokenAccessor;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.hana.connectivity.handler.DataSourceHandlerFactory;
import com.sap.cloud.sdk.odatav2.connectivity.ODataException;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQuery;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryBuilder;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryResult;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.EntityDataBuilder;
import com.sap.cloud.sdk.service.prov.api.EntityMetadata;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.request.CreateRequest;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.request.ReadRequest;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponseAccessor;

/**
 * Junit test case class for EvaluationHooksHandler class.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ DataSourceHandlerFactory.class, EntityData.class, ODataQueryBuilder.class,
		CDSDataSourceHandlerFactory.class, AuthTokenAccessor.class })
public class EvaluationHooksHandlerTest {

	private QueryRequest queryRequest;
	private ODataQueryResult odataQueryResult;
	private ODataQuery odataQuery;
	private ODataQueryBuilder oDataQueryBuilder;
	private ReadRequest readRequest;
	private CreateRequest createRequest;
	private ExtensionHelper extensionHelper;
	private EntityMetadata entityMetadata;
	private EntityData entityData;
	private QueryResponseAccessor queryResponse;
	private CDSDataSourceHandler cDSDataSourceHandler;
	private CDSSelectQueryResult cDSSelectQueryResult;
	private EntityDataBuilder entityDataBuilder;
	EvaluationHooksHandler evaluationHooksHandler;
	ReadResponseAccessor readResponseAccessor;
	CreateResponseAccessor createResponseAccessor;
	JSONObject jsonObj;
	JSONArray jsonArr;
	List<EntityData> evaluationDataList;
	List<EntityData> cDSSelectQueryResultList;
	String sellingMarket = null;

	String evaluationID = "0eb8a795-a966-4d41-b900-e7843455f798";
	String evalStatus = "New";
	String nextStatus = "In Progress";
	String BACKEND_DESTINATION_NAME = "ER9CLNT";

	/**
	 * This method is initializing the mock objects, having the common objects
	 * and when().thenReturn() for all the test cases.
	 */
	@Before
	public void setUp() {

		queryResponse = Mockito.mock(QueryResponseAccessor.class);
		odataQueryResult = Mockito.mock(ODataQueryResult.class);
		oDataQueryBuilder = Mockito.mock(ODataQueryBuilder.class);
		odataQuery = Mockito.mock(ODataQuery.class);
		jsonObj = Mockito.mock(JSONObject.class);
		jsonArr = Mockito.mock(JSONArray.class);

		readRequest = Mockito.mock(ReadRequest.class);
		createRequest = Mockito.mock(CreateRequest.class);
		extensionHelper = Mockito.mock(ExtensionHelper.class);
		readResponseAccessor = Mockito.mock(ReadResponseAccessor.class);
		createResponseAccessor = Mockito.mock(CreateResponseAccessor.class);
		queryRequest = Mockito.mock(QueryRequest.class);
		entityMetadata = Mockito.mock(EntityMetadata.class);
		entityData = Mockito.mock(EntityData.class);
		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
	
		cDSDataSourceHandler = Mockito.mock(CDSDataSourceHandler.class);
		cDSSelectQueryResult = Mockito.mock(CDSSelectQueryResult.class);
		entityDataBuilder = Mockito.mock(EntityDataBuilder.class);
		evaluationHooksHandler = new EvaluationHooksHandler();

		evaluationDataList = new ArrayList<>();
		evaluationDataList.add(entityData);
		cDSSelectQueryResultList = new ArrayList<>();
		cDSSelectQueryResultList.add(entityData);

		PowerMockito.mockStatic(ODataQueryBuilder.class);
		PowerMockito.when(ODataQueryBuilder.withEntity("/sap/opu/odata/SAP/API_RECIPE/", "A_Recipe"))
				.thenReturn(oDataQueryBuilder);

		Mockito.when(queryRequest.getEntityMetadata()).thenReturn(entityMetadata);
		Mockito.when(entityMetadata.getNamespace()).thenReturn(EvaluationConstants.DATA_MODEL);
		Mockito.when(entityData.getElementValue(EvaluationConstants.EVALUATION_ID)).thenReturn(evaluationID);
		Mockito.when(entityData.getElementValue(EvaluationConstants.EVAL_STATUS)).thenReturn("New");
		Mockito.when(entityData.getElementValue(EvaluationConstants.EVAL_STATUS)).thenReturn("In Progress");
		Mockito.when(entityData.getElementValue(EvaluationConstants.NEXT_STATUS)).thenReturn(nextStatus);
		Mockito.when(entityData.getElementValue(EvaluationConstants.SELLING_MARKET))
				.thenReturn(EvaluationConstants.SELLING_MARKET_VALUE);
		Mockito.when(entityData.getElementValue("NAME")).thenReturn("countryName");		
		PowerMockito.mockStatic(AuthTokenAccessor.class);
		PowerMockito.mockStatic(CDSDataSourceHandlerFactory.class);
		PowerMockito.when(CDSDataSourceHandlerFactory.getHandler()).thenReturn(cDSDataSourceHandler);
				
		
	
		PowerMockito.mockStatic(EntityData.class);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.addElement(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.buildEntityData(EvaluationConstants.ENTITY_EVALUATION)).thenReturn(entityData);

	}

	/*
	 * This method is testing the positive scenario of afterQueryEvaluation
	 * method. Success Scenario - For all evaluation entities the method is
	 * fetching selling Market and setting values for Pie chart and adding it to
	 * the response
	 */
	@Test
	public void afterQueryEvaluationTest_forAllEvaluationEntities_setPieChartValues_and_addToResponse()
			throws CDSException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Mockito.when(queryResponse.getEntityDataList()).thenReturn(evaluationDataList);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		Mockito.when(entityData.getElementValue(EvaluationConstants.COMPLIANT_STATUS)).thenReturn("COMPLIANT_STATUS");
		Mockito.when(entityDataBuilder.buildEntityData(EvaluationConstants.ENTITY_EVALUATION)).thenReturn(entityData);
		Assert.assertNotNull(evaluationHooksHandler.getEvaluationList(queryRequest, queryResponse, extensionHelper));

	}

	/**
	 * Below method is testing the success scenario of afterReadEvaluation
	 * method. Success Scenario - For a particular evaluation entity, This
	 * method is modifying response to add selling market , recipe count ,
	 * recipe compliant status and pie chart info to Evaluation entity. This
	 * method is using line no. 112 in Set Up method for mocking selling market
	 * ,recipe count , recipe compliant status and pie chart and adding to the
	 * response Evaluation entity.
	 *
	 * @throws CDSException
	 * @throws ODataException
	 */
	@Test
	public void afterReadEvaluationTestRecipe() throws CDSException, ODataException , JSONException{

		String jsonString = "{\r\n" + "d: {\r\n" + "results: [\r\n" + "{\r\n" + "\r\n"
				+ "RecipeUUID: \"005056ac-156f-1ed5-9885-d4f3486ef31e\",\r\n" + "RecipeUUID_Text: \"asdf\",\r\n"
				+ "Plant: \"\",\r\n" + "RecipeValidityEndDate: \"/Date(253402214400000)/\",\r\n"
				+ "RecipeType: \"\",\r\n" + "RecipeStatus: \"\",\r\n" + "\r\n" + "},\r\n" + "{\r\n" + "\r\n"
				+ "RecipeUUID: \"005056ac-156f-1ed5-9885-d4f3486ef31e\",\r\n" + "RecipeUUID_Text: \"asdf\",\r\n"
				+ "Plant: \"\",\r\n" + "RecipeValidityEndDate: null,\r\n" + "\r\n" + "}\r\n" + "]\r\n" + "}\r\n" + "}";
		;

		EntityData entityDataObj = Mockito.mock(EntityData.class);
		Mockito.when(readResponseAccessor.getEntityData()).thenReturn(entityDataObj);
		Mockito.when(oDataQueryBuilder.withHeader("sap-client", "001", true)).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.withHeader("sap-language", "EN", true)).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.select("RecipeUUID", "RecipeUUID_Text", "Plant", "RecipeValidityEndDate",
				"RecipeType", "RecipeStatus")).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.top(10)).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.build()).thenReturn(odataQuery);
		Mockito.when(odataQuery.execute("ER9CLNT")).thenReturn(odataQueryResult);
		Mockito.when(odataQueryResult.getStreamData()).thenReturn(jsonString);
		Mockito.when(jsonObj.get("d")).thenReturn(jsonObj);
		Mockito.when(jsonObj.get("results")).thenReturn(jsonArr);
		Mockito.when(jsonObj.get("RecipeValidityEndDate")).thenReturn(jsonArr);
		Mockito.when(odataQueryResult.getStreamData()).thenReturn(jsonString);

		Assert.assertNotNull(
				evaluationHooksHandler.afterQueryMasterRecipe(queryRequest, queryResponse, extensionHelper));
	}

	@Test
	public void afterReadEvaluationTestRecipe_tryblock() throws CDSException, ODataException ,JSONException {

		String jsonString = "{\r\n" + "d: {\r\n" + "results: [\r\n" + "{\r\n" + "\r\n"
				+ "RecipeUUID: \"005056ac-156f-1ed5-9885-d4f3486ef31e\",\r\n" + "RecipeUUID_Text: \"asdf\",\r\n"
				+ "Plant: \"\",\r\n" + "RecipeValidityEndDate: \"/Date(253402214400000)/\",\r\n"
				+ "RecipeType: \"\",\r\n" + "RecipeStatus: \"\",\r\n" + "\r\n" + "},\r\n" + "{\r\n" + "\r\n"
				+ "RecipeUUID: \"005056ac-156f-1ed5-9885-d4f3486ef31e\",\r\n" + "RecipeUUID_Text: \"asdf\",\r\n"
				+ "Plant: \"\",\r\n" + "RecipeValidityEndDate: null,\r\n" + "\r\n" + "}\r\n" + "]\r\n" + "}\r\n" + "}";
		;

		EntityData entityDataObj = Mockito.mock(EntityData.class);
		Mockito.when(readResponseAccessor.getEntityData()).thenReturn(entityDataObj);
		Mockito.when(oDataQueryBuilder.withHeader("sap-client", "001", true)).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.withHeader("sap-language", "EN", true)).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.withHeader(EvaluationConstants.AUTHORIZATION, "abc"))
				.thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.select("RecipeUUID", "RecipeUUID_Text", "Plant", "RecipeValidityEndDate",
				"RecipeType", "RecipeStatus")).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.top(10)).thenReturn(oDataQueryBuilder);
		Mockito.when(oDataQueryBuilder.build()).thenReturn(odataQuery);
		Mockito.when(odataQuery.execute("ER9CLNT")).thenReturn(odataQueryResult);
		Mockito.when(odataQueryResult.getStreamData()).thenReturn(jsonString);
		Mockito.when(jsonObj.get("d")).thenReturn(jsonObj);
		Mockito.when(jsonObj.get("results")).thenReturn(jsonArr);
		Mockito.when(jsonObj.get("RecipeValidityEndDate")).thenReturn(jsonArr);
		Mockito.when(odataQueryResult.getStreamData()).thenReturn(jsonString);

		Assert.assertNotNull(
				evaluationHooksHandler.afterQueryMasterRecipe(queryRequest, queryResponse, extensionHelper));
	}

	/**
	 * Below method is testing the success scenario of afterReadEvaluation
	 * method. Success Scenario - For a particular evaluation entity, This
	 * method is modifying response to add selling market , recipe count ,
	 * recipe compliant status and pie chart info to Evaluation entity. This
	 * method is using line no. 112 in Set Up method for mocking selling market
	 * ,recipe count , recipe compliant status and pie chart and adding to the
	 * response Evaluation entity.
	 *
	 * @throws CDSException
	 */
	@Test
	public void afterReadEvaluationTest_mockAllElement_addToResponse() throws CDSException {
		EntityData entityDataObj = Mockito.mock(EntityData.class);
		Mockito.when(readRequest.getEntityMetadata()).thenReturn(entityMetadata);
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(readResponseAccessor.getEntityData()).thenReturn(entityDataObj);
		Mockito.when(entityDataObj.getElementValue(EvaluationConstants.EVALUATION_ID)).thenReturn(evaluationID);
		Mockito.when(entityDataObj.getElementValue(EvaluationConstants.EVAL_STATUS)).thenReturn(evalStatus);
		Mockito.when(entityDataObj.getElementValue(EvaluationConstants.NEXT_STATUS)).thenReturn(nextStatus);
		Assert.assertNotNull(
				evaluationHooksHandler.displayEvaluationSheet(readRequest, readResponseAccessor, extensionHelper));
	}

	/**
	 * Below method is testing the success scenario of beforeCreateEvaluation
	 * method. Success Scenario - For a particular evaluation entity, This
	 * method is adding the evaluationName info to Evaluation entity. This
	 * method is using line no. 112 in Set Up method for mocking the evaluation
	 * Name and adding to the response Evaluation entity.
	 */
	@Test
	public void beforeCreateEvaluationTest_mockAllElement_addToResponse() {
		EntityData entityDataObj = Mockito.mock(EntityData.class);
		Mockito.when(entityDataObj.getElementValue(EvaluationConstants.EVALUATION_ID)).thenReturn(evaluationID);
		Mockito.when(createRequest.getData()).thenReturn(entityDataObj);
		evaluationHooksHandler.beforeCreateEvaluation(createRequest, extensionHelper);
		Assert.assertNotNull(entityDataObj.getElementValue(EvaluationConstants.EVALUATION_ID));

	}

	@Test
	public void afterQueryEvaluationStatus_Test() throws CDSException {	
		Mockito.when(cDSDataSourceHandler.executeQuery(Mockito.anyObject())).thenReturn(cDSSelectQueryResult);
		Mockito.when(cDSSelectQueryResult.getResult()).thenReturn(cDSSelectQueryResultList);
		PowerMockito.when(EntityData.getBuilder(Mockito.anyObject())).thenReturn(entityDataBuilder);
		Mockito.when(entityDataBuilder.buildEntityData("CountryForValueHelp")).thenReturn(entityData);
		Assert.assertNotNull(
				evaluationHooksHandler.getCountryForValueHelp(queryRequest, queryResponse, extensionHelper));
	}
}
