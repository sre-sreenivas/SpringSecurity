package com.trialformulation.constants;

public class FormulaOptimiserContants {

	private FormulaOptimiserContants() {
		// Private constructor to avoid implicit Object creation
	}
	public static final String ITEM_NUM_VALUE = "itemNumber";
    public static final String ITEMNUM_BTW_1AND2 = "Renumber the items before you insert the items at this position";
    public static final String ITEMNUM_GR_999 = "Input Item cannot be inserted as the limit 999 has been crossed";
	public static final String EVALUATION_NAME = "evaluationName";
	public static final String RECIPE_DESCRIPTION = "recipeDESCRIPTION";
	public static final String NEW_RECIPE = "New Recipe";
	public static final String RECIPE = "Recipe";
	public static final String STATUS = "status";
	public static final String SERVICENAME = "RecipeService";
	public static final String RECIPE_STATUS_ENTITY = "RecipeService.RecipeStatus";
	public static final String EVALUATION_ID = "evaluationID";
	public static final String EVALUATION_SHEEET_DEFAULT_NAME = "New Evaluation Sheet";
	public static final String EVALUATION_SHEEET_ID = "5f39ac9c-5b99-4375-a76a-22c2fd3e9a0f";
	public static final String USE_LIMITS_OF_EVALUATION_SHEET = "UseLimitsOfevaluationSheet";
	public static final String ADD_SPECIFICATION = "addSpecification";
	public static final String STATUS_CRITICALITY = "criticality";
	public static final String REMOVE_DUPLICATE_RECIPE = "removeDuplicateRecipe";
	public static final String RECIPE_ID = "recipeID";
	public static final String ID = "ID";
	public static final String IS_ACTIVE_ENTITY = "IsActiveEntity";
	public static final String HAS_ACTIVE_ENTITY = "HasActiveEntity";
	public static final String HAS_DRAFT_ENTITY = "HasDraftEntity";
	public static final String RECIPE_TYPE = "recipeType";
	public static final String RECIPE_I = "recipeId";
	public static final String RECIPE_ENTITY = "RecipeService.RECIPE";
	public static final String DATA_MODEL = "formulation.datamodel";
	public static final String MANDATORY_FIELD_MESSAGE = "Please provide the mandatory field correctly.";
	public static final String RECIPE_SPECIFICATION = "RecipeSpecification";
	public static final String SPECIFICATION_ID = "specificationID";
	public static final String COMPONENT_TYPE = "componentType";
	public static final String UOM = "UOM";
	public static final String QUANTITY = "quantity";
	public static final String ITEM_NUMBER = "itemNumber";
	public static final String PRODUCT = "Product";
	public static final String KG = "KG";
	public static final String RECIPE_SPECIFICATION_DRAFTS_ENTITY = "RecipeService.RecipeSpecification_Drafts";
	public static final String RECIPESPECIFICATION_DRAFTS = "RecipeSpecification_Drafts";
	public static final String UPDATE_DRAFT_SPECIFICATION_VALUES = "updateDraftSpecificationValues";
	public static final String SPECIFICATION_DESCRIPTION = "specificationDescription";
	public static final String PACKAGE = "Package";
	public static final String MANAGE_LAYOUT_SERVICE = "ManageLayoutService";
	public static final String GET_LAYOUT_LIST = "getLayoutList";
	public static final String LAYOUT_NAME = "layoutName";
	public static final String DESCRIPTION = "description";
	public static final String DEFAULT_FLAG = "defaultFlag";
	public static final String LAYOUT_TYPE = "layoutType";
	public static final String REFERENCE_QUANTITY = "referenceQuantity";
	public static final String DEFAULT_FLAG_CRITICALITY = "defaultFlagCriticality";
	public static final String CREATED_AT = "createdAt";
	public static final String CREATED_BY = "createdBy";
	public static final String MODIFIED_AT = "modifiedAt";
	public static final String MODIFIED_BY = "modifiedBy";
	public static final String DRAFT_UUID = "DraftUUID";
	public static final String LAYOUT_INFORMATION_ENTITY ="ManageLayoutService.LayoutInformation" ;
	public static final String LAYOUT_INFORMATION_ENTITY_DRAFT ="ManageLayoutService.LayoutInformation_Drafts" ;
	public static final String DEFAULT = "Default";

	public static final String FORMULA_SPEC_ID ="SPECIFICATIONID";
	public static final String SPEC_QUANTITY= "QUANTITY";
	public static final String UOM_ID = "Id";
	public static final String STANDARDUOM="formulation.datamodel.STANDARDUOM";
	public static final String VALIDATE_UOM = "uom";
	public static final String UOM_DESCRIPTION = "DESCRIPTION";


	public static final String FORMULA_ITEM_DESCRIPTION = "formulaItemDescription";
	public static final String NEXT_ITEM_NUMBER = "nextItemNumber";
	public static final String FORMULA_QUANTITY_CALCULATION = "formulaQuantityCalculation";
	public static final String INGREDIENT = "Ingredient";
	public static final String DRAFTADMINISTRATIVEDATA_DRAFTUUID = "DRAFTADMINISTRATIVEDATA_DRAFTUUID";


	public static final Integer THOUSAND = 1000;
	public static final String G = "G";
	public static final String TO = "TO";
	public static final String L = "L";
	public static final String ML = "ML";
	public static final String PC = "PC";
	public static final String EA = "EA";
	public static final String DENSITY = "density";
	public static final String PIECE_TO_MASS = "piecetoMass";
	public static final String FORMULA_DENSITY="DENSITY";
	public static final String FORMULA_PIECE_TO_MASS="PIECETOMASS";
	public static final String FORMULA_COMPONENT_TYPE="COMPONENTTYPE";
	public static final String CM3 = "CM3";
	public static final String DEPENDENCY = "DEPENDENCY";
	
	public static final String VALIDATE_SPECIFICATION_ID = "validateSpecificationId";
	public static final String SPECIFICATION = "SPECIFICATION";
	public static final String DELETE_FORMULA_ITEM = "deleteFormulaItem";
	public static final String REORDER_SELECTED_COLUMN = "reorderSelectedColumn";
	public static final String BUTTON_UP = "up";
	public static final String BUTTON_DOWN = "down";
	public static final String BUTTON_DIRECT_UP = "directUp";
	public static final String BUTTON_DIRECT_DOWN = "directDown";
	public static final String MODE_OFF = "off";
	public static final String DISPLAY_MODE = "displayMode";
	public static final String REORDER_ACTION = "reorderAction";
	public static final String REORDER_SPECIFICATION_ID = "reorderSpecificationID";
	public static final String REORDER_SPECIFICATION_ID_SELECT_COLUMNS = "ID,recipeID,specificationID,specificationDescription,formulaItemDescription,density,piecetoMass,quantity,UOM,componentType,itemNumber,nextItemNumber";
}
