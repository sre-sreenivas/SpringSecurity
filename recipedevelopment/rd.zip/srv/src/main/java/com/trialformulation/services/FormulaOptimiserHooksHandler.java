package com.trialformulation.services;

import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterCreateDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterReadDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.BeforeCreate;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.exits.BeforeCreateResponse;
import com.sap.cloud.sdk.service.prov.api.request.CreateRequest;
import com.sap.cloud.sdk.service.prov.api.request.ReadRequest;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponse;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponse;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponseAccessor;
import com.trialformulation.constants.FormulaOptimiserContants;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.log4j.Logger;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;

/*
* This class is implementing TransactionHooks for  Recipe entity
* @AfterRead, @AfterQuery transaction hooks are implemented to modify the response on read and query operations.
* @BeforeCreate needs to be implemented to add validation from backend.
*/

public class FormulaOptimiserHooksHandler {

	private static final Logger LOGGER = Logger.getLogger(FormulaOptimiserHooksHandler.class.getName());

	/*
	 * Implementation of @BeforeCreate operation for Recipe entity. 
	 */

	@BeforeCreate(entity = FormulaOptimiserContants.RECIPE, serviceName = FormulaOptimiserContants.SERVICENAME)
	public BeforeCreateResponse setDefaultValueAndMandatoryFieldValidation(CreateRequest createRequest,
			ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing @BeforeCreate");
		EntityData entityData = createRequest.getData();
			return BeforeCreateResponse.setSuccess().setEntityData(entityData).response();
	}

	
	/*
	 * Implementation of @AfterReadDraft operation for Recipe entity. This method is
	 * modifying response to add Evaluation ID and name in concatenated string 
	 * to recipe entity.
	*/
		@AfterReadDraft(entity = FormulaOptimiserContants.RECIPE, serviceName = FormulaOptimiserContants.SERVICENAME)
    public ReadResponse afterReadRecipe(ReadRequest request, ReadResponseAccessor response,
            ExtensionHelper extensionHelper) {
        LOGGER.info("Started executing @AfterReadDraft");
        EntityData recipeEntityData = response.getEntityData();
        EntityData modifiedRecipeEntityData = null;
      
   
        String evalId = null;
           String evalName = null;
        evalId  =  recipeEntityData.getElementValue(FormulaOptimiserContants.EVALUATION_ID) == null?
         "":recipeEntityData.getElementValue(FormulaOptimiserContants.EVALUATION_ID).toString();
        evalName =  recipeEntityData.getElementValue(FormulaOptimiserContants.EVALUATION_NAME) == null?
        "":recipeEntityData.getElementValue(FormulaOptimiserContants.EVALUATION_NAME).toString();
       
       
        try{
            StringBuilder sb = new StringBuilder();
            if(null != recipeEntityData.getElementValue(FormulaOptimiserContants.EVALUATION_ID)){
            sb.append(evalId).append(" (").append(evalName).append(")").toString();
            }
            modifiedRecipeEntityData = EntityData.getBuilder(recipeEntityData)
                      .addElement(FormulaOptimiserContants.USE_LIMITS_OF_EVALUATION_SHEET, sb)
                    .buildEntityData(FormulaOptimiserContants.RECIPE);
        } catch (Exception exception){
          LOGGER.error(exception.getMessage(), exception);
        }
         return ReadResponse.setSuccess().setData(modifiedRecipeEntityData).response();
    }

	/*
	 * Implementation of @AfterCreateDraft operation for RecipeSpecification entity. This
	 * method is inserting data into RecipeSpecification_Drafts table with some
	 * default values if there is no data already available of that particular recepiId.
	 */
	@AfterCreateDraft(entity = FormulaOptimiserContants.RECIPE, serviceName = FormulaOptimiserContants.SERVICENAME)
	public CreateResponse addRecipeSpecificationDraftDefaultValues(CreateRequest createRequest,
			CreateResponseAccessor productResponse, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function addRecipeSpecificationDraftDefaultValues");
		EntityData ed = productResponse.getEntityData();
		DataSourceHandler dsHandler = extensionHelper.getHandler();
		String recipeIdFromParameter = ed.getElementValue(FormulaOptimiserContants.RECIPE_ID).toString();
		List<String> keys = new ArrayList<>();
		keys.add("ID");
		Map<String, Object> entMap = new HashMap<>();
		Map<String, Object> recipeEntitykeys = new HashMap<>();
		recipeEntitykeys.put(FormulaOptimiserContants.RECIPE_ID,
				ed.getElementValue(FormulaOptimiserContants.RECIPE_ID));

		List<String> recipeEntityproperties = new ArrayList<>();
		recipeEntityproperties.add(FormulaOptimiserContants.RECIPE_ID);
		recipeEntityproperties.add(FormulaOptimiserContants.ID);
		recipeEntityproperties.add(FormulaOptimiserContants.IS_ACTIVE_ENTITY);
		recipeEntityproperties.add(FormulaOptimiserContants.HAS_ACTIVE_ENTITY);
		recipeEntityproperties.add(FormulaOptimiserContants.HAS_DRAFT_ENTITY);

		List<String> specEntityproperties = new ArrayList<>();
		specEntityproperties.add(FormulaOptimiserContants.RECIPE_ID);
		try {
			EntityData entityDataDrafts = dsHandler.executeRead(
					FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY, recipeEntitykeys,
					recipeEntityproperties);
			EntityData entityDataspec = dsHandler.executeRead(FormulaOptimiserContants.RECIPE_SPECIFICATION,
					recipeEntitykeys, specEntityproperties);
			if (null != entityDataDrafts
					&& null != entityDataDrafts.getElementValue(FormulaOptimiserContants.RECIPE_ID)) {
				LOGGER.info("Started if executing function addRecipeSpecificationDraftDefaultValues");
				String receipeIDfromDb = String
						.valueOf(entityDataDrafts.getElementValue(FormulaOptimiserContants.RECIPE_ID));
				if (recipeIdFromParameter.equals(receipeIDfromDb)) {
					LOGGER.info("Started if if executing function addRecipeSpecificationDraftDefaultValues");
					CreateResponse.setSuccess().setData(ed).response();
				}
			} else {
				if (null != entityDataspec
						&& null != entityDataspec.getElementValue(FormulaOptimiserContants.RECIPE_ID)) {
					LOGGER.info("Started if else if executing function addRecipeSpecificationDraftDefaultValues");
					CreateResponse.setSuccess().setData(ed).response();
				} else {
					LOGGER.info("Started if else else executing function addRecipeSpecificationDraftDefaultValues");
					entMap.put(FormulaOptimiserContants.ID, UUID.randomUUID());
					entMap.put(FormulaOptimiserContants.RECIPE_ID,
							ed.getElementValue(FormulaOptimiserContants.RECIPE_ID));
					entMap.put(FormulaOptimiserContants.SPECIFICATION_ID,
							ed.getElementValue(FormulaOptimiserContants.RECIPE_ID));
					entMap.put(FormulaOptimiserContants.UOM, FormulaOptimiserContants.KG);
					entMap.put(FormulaOptimiserContants.COMPONENT_TYPE, FormulaOptimiserContants.PRODUCT);
					entMap.put(FormulaOptimiserContants.QUANTITY, 0);
					entMap.put(FormulaOptimiserContants.ITEM_NUMBER, 0);
					entMap.put(FormulaOptimiserContants.IS_ACTIVE_ENTITY, Boolean.FALSE);
					entMap.put(FormulaOptimiserContants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
					entMap.put(FormulaOptimiserContants.HAS_DRAFT_ENTITY, Boolean.FALSE);
					entMap.put("DRAFTADMINISTRATIVEDATA_DRAFTUUID", UUID.randomUUID());
					EntityData entityData = EntityData.createFromMap(entMap, keys,
							FormulaOptimiserContants.RECIPESPECIFICATION_DRAFTS);
					dsHandler.executeInsert(entityData, false);
				}
			}
		} catch (DatasourceException e) {
			LOGGER.error(e.getMessage(), e);
		}

		return CreateResponse.setSuccess().setData(ed).response();
	}

}
