package com.trialformulation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSQuery;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryBuilder;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.cds.ConditionBuilder;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.Function;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.OperationRequest;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.OperationResponse;
import com.trialformulation.constants.FormulaOptimiserContants;
import com.sap.cloud.sdk.service.prov.api.security.AuthorizationService;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/*
*This class is implementing @function which is updating the Recipe status , next status and status Criticality in Recipe entity. 
*/

public class FormulaOptimiserCustomService {

	private static final Logger LOGGER = Logger.getLogger(FormulaOptimiserCustomService.class.getName());

	@Function(Name = FormulaOptimiserContants.ADD_SPECIFICATION, serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse addSpecification(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		try {
			LOGGER.info("Started executing class FormulaOptimiserCustomService invoking function addSpecification");
			Integer newItemNumber;
			Map<String, Object> requestParameters = functionRequest.getParameters();
			Map<String, Object> receipeEntitykeys = new HashMap<>();
			receipeEntitykeys.put(FormulaOptimiserContants.RECIPE_ID,
					requestParameters.get(FormulaOptimiserContants.RECIPE_ID));
			String recipeIdFromParameter = requestParameters.get(FormulaOptimiserContants.RECIPE_ID).toString();
			LOGGER.info("recipeIdFromParameter" + recipeIdFromParameter);
			List<String> recipeEntityproperties = new ArrayList<>();
			DataSourceHandler handler = extensionHelper.getHandler();
			recipeEntityproperties.add(FormulaOptimiserContants.RECIPE_ID);
			recipeEntityproperties.add(FormulaOptimiserContants.ID);
			recipeEntityproperties.add(FormulaOptimiserContants.IS_ACTIVE_ENTITY);
			recipeEntityproperties.add(FormulaOptimiserContants.HAS_ACTIVE_ENTITY);
			recipeEntityproperties.add(FormulaOptimiserContants.HAS_DRAFT_ENTITY);
			LOGGER.info(requestParameters.get(FormulaOptimiserContants.SPECIFICATION_ID).toString());
			String specID = String.valueOf(requestParameters.get(FormulaOptimiserContants.SPECIFICATION_ID));
			String iNumber = String.valueOf(requestParameters.get(FormulaOptimiserContants.ITEM_NUMBER));
			String nItemNumber = String.valueOf(requestParameters.get(FormulaOptimiserContants.NEXT_ITEM_NUMBER));
			LOGGER.info(iNumber + " " + nItemNumber);
			Integer itemNumber;
			Integer nextItemNumber;
			if (iNumber.isEmpty() || iNumber.equals("null") || iNumber.equals("")) {
				itemNumber = null;
			} else {
				itemNumber = Integer.parseInt(iNumber);
			}
			if (nItemNumber.isEmpty() || nItemNumber.equals("null") || nItemNumber.equals("")) {
				nextItemNumber = null;
			} else {
				nextItemNumber = Integer.parseInt(nItemNumber);
			}

			LOGGER.info(requestParameters.get(FormulaOptimiserContants.ITEM_NUMBER));
			LOGGER.info(requestParameters.get(FormulaOptimiserContants.NEXT_ITEM_NUMBER));
			EntityData specificationEntityData = null;

			List<String> keys = new ArrayList<>();
			keys.add("ID");
			Map<String, Object> entMap = new HashMap<>();
			entMap.put("ID", UUID.randomUUID());
			entMap.put(FormulaOptimiserContants.RECIPE_ID, recipeIdFromParameter);
			entMap.put(FormulaOptimiserContants.SPECIFICATION_ID, specID);
			entMap.put(FormulaOptimiserContants.IS_ACTIVE_ENTITY, Boolean.FALSE);
			entMap.put(FormulaOptimiserContants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
			entMap.put(FormulaOptimiserContants.HAS_DRAFT_ENTITY, Boolean.FALSE);
			if (StringUtils.isEmpty(specID) || StringUtils.isBlank(specID) || specificationEntityData == null) {
				entMap.put(FormulaOptimiserContants.SPECIFICATION_DESCRIPTION, "");
				entMap.put(FormulaOptimiserContants.FORMULA_ITEM_DESCRIPTION, "");
				entMap.put(FormulaOptimiserContants.DENSITY, 0.00);
			}
			entMap.put(FormulaOptimiserContants.QUANTITY, 0);
			entMap.put(FormulaOptimiserContants.UOM, FormulaOptimiserContants.KG);
			entMap.put(FormulaOptimiserContants.COMPONENT_TYPE, FormulaOptimiserContants.INGREDIENT);
			newItemNumber = fetchItemNumber(itemNumber, nextItemNumber);
			if (newItemNumber == -100) {
				LOGGER.info(FormulaOptimiserContants.ITEMNUM_GR_999);
				return OperationResponse
						.setError(ErrorResponse.getBuilder().setMessage(FormulaOptimiserContants.ITEMNUM_GR_999)
								.addErrorDetail(FormulaOptimiserContants.ITEMNUM_GR_999,
										FormulaOptimiserContants.ITEM_NUM_VALUE)
								.response());
			}
			if (newItemNumber == -200) {
				LOGGER.info(FormulaOptimiserContants.ITEMNUM_BTW_1AND2);
				return OperationResponse
						.setError(ErrorResponse.getBuilder().setMessage(FormulaOptimiserContants.ITEMNUM_BTW_1AND2)
								.addErrorDetail(FormulaOptimiserContants.ITEMNUM_BTW_1AND2,
										FormulaOptimiserContants.ITEM_NUM_VALUE)
								.response());
			}
			entMap.put(FormulaOptimiserContants.ITEM_NUMBER, newItemNumber);
			entMap.put(FormulaOptimiserContants.DRAFTADMINISTRATIVEDATA_DRAFTUUID, UUID.randomUUID());
			EntityData ed = EntityData.createFromMap(entMap, keys,
					FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY);
			handler.executeInsert(ed, false);
			return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
	}

	/*
	 * This method gets the itemNumber using the present and the next item
	 * number
	 */
	public Integer fetchItemNumber(Integer itemNumber, Integer nextItemNumber) {

		Integer newItemNumber = null;

		try {
			if (itemNumber != null && nextItemNumber == null && itemNumber <= 1000) {
				return getNewItemNumber(itemNumber);
			}
			if (itemNumber != null && nextItemNumber != null && itemNumber <= 1000 && nextItemNumber <= 1000) {
				if (itemNumber + 1 == nextItemNumber) {
					return -200;
				} else {
					newItemNumber = (itemNumber + nextItemNumber) / 2;
					return newItemNumber;
				}
			}
			if (itemNumber > 1000 || nextItemNumber > 1000) {
				return -100;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		return null;
	}

	/**
	 * @param itemNumber
	 * @return
	 */
	/*
	 * This method gets the getNewItemNumber.
	 */
	private Integer getNewItemNumber(Integer itemNumber) {
		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking private method getNewItemNumber");
		Integer newItemNumber;
		Integer numDifference;
		if (itemNumber == 0) {
			newItemNumber = 10;
			return newItemNumber;
		} else {
			if ((itemNumber % 10 == 0)) {
				newItemNumber = itemNumber + 10;
				if (newItemNumber < 1000) {
					return newItemNumber;
				} else {
					return null;
				}
			} else {
				numDifference = (itemNumber % 10);
				newItemNumber = itemNumber + (10 - numDifference);
				if (newItemNumber != 1000) {
					return newItemNumber;
				}
			}
			if ((itemNumber > 990 && itemNumber <= 1000)) {
				newItemNumber = (itemNumber + 1000) / 2;
				return newItemNumber;
			}
		}
		return newItemNumber;
	}

	/*
	 * This method calculates the PO line item's quantity value for all the
	 * specifications added except for the one whose componentType is "PACKAGE"
	 * and converts them to KG
	 */
	@Function(Name = FormulaOptimiserContants.FORMULA_QUANTITY_CALCULATION, serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse formulaQuantityCalculation(OperationRequest functionRequest,
			ExtensionHelper extensionHelper) {
		LOGGER.info(
				"Started executing class FormulaOptimiserCustomService invoking function formulaQuantityCalculation");
		Double sumOfQuantity = 0.0;
		String primaryOutputId = null;
		Map<String, Object> requestParameters = functionRequest.getParameters();
		try {
			if (requestParameters.get(FormulaOptimiserContants.RECIPE_ID) != null) {
				DataSourceHandler dsHandler = extensionHelper.getHandler();
				String recipeIdFromParameter = UUID
						.fromString(requestParameters.get(FormulaOptimiserContants.RECIPE_ID).toString()).toString();
				CDSDataSourceHandler cdsDataSourceHandler = CDSDataSourceHandlerFactory.getHandler();
				CDSQuery cdsQueryForQuantityCal = new CDSSelectQueryBuilder(
						FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY).selectColumns("*")
								.where(new ConditionBuilder().columnName(FormulaOptimiserContants.RECIPE_ID)
										.IN(recipeIdFromParameter))
								.build();
				CDSSelectQueryResult cdsSelectQueryResultForQuantityCal;
				cdsSelectQueryResultForQuantityCal = cdsDataSourceHandler.executeQuery(cdsQueryForQuantityCal);
				List<EntityData> resultList = cdsSelectQueryResultForQuantityCal.getResult();
				for (EntityData en : resultList) {
					String specificationID = en.getElementValue(FormulaOptimiserContants.FORMULA_SPEC_ID).toString();

					/*
					 * when recipe ID from parameter is equal to specification
					 * ID then it is PO row item
					 */

					if (recipeIdFromParameter.equalsIgnoreCase(specificationID)) {
						primaryOutputId = en.getElementValue(FormulaOptimiserContants.ID).toString();
					}
					Double qty = ((BigDecimal) en.getElementValue(FormulaOptimiserContants.SPEC_QUANTITY))
							.doubleValue();
					List<String> uomList = new ArrayList<>();
					uomList.add("C");
					uomList.add("TSP");
					uomList.add("TBS");
					uomList.add("");
					String uom = en.getElementValue(FormulaOptimiserContants.UOM).toString();

					/*
					 * When we have PO row and we have two specification ID and
					 * its UOM is C or TSP or TBS or no UOM then sumOfQuantity.
					 * will be 0.0
					 */

					Boolean uomFlag = resultList.size() == 2 && uomList.contains(uom);
					if ((uomFlag) || (qty.compareTo(0.0D) == 0 && primaryOutputId == null)) {
						if (uomFlag) {
							sumOfQuantity = 0.0;
						}
						continue;
					}
					Double density = (Double) en.getElementValue(FormulaOptimiserContants.FORMULA_DENSITY);
					Double piecetoMass = (Double) en.getElementValue(FormulaOptimiserContants.FORMULA_PIECE_TO_MASS);
					String componentType = en.getElementValue(FormulaOptimiserContants.FORMULA_COMPONENT_TYPE)
							.toString();
					if (!recipeIdFromParameter.equalsIgnoreCase(specificationID)
							&& !componentType.equalsIgnoreCase(FormulaOptimiserContants.PACKAGE) && uom != null) {
						sumOfQuantity = getSumOfQuantity(sumOfQuantity, qty, uom, density, piecetoMass);
					}
				}
				String poQuantity = new BigDecimal(sumOfQuantity.toString()).toPlainString();
				BigDecimal quantityToBigDecimal = new BigDecimal((sumOfQuantity));
				if (quantityToBigDecimal.scale() > 6) {
					BigDecimal scaledPoQuantity = quantityToBigDecimal.setScale(6, BigDecimal.ROUND_HALF_UP);
					poQuantity = scaledPoQuantity.toString();
				}
				List<String> keys = new ArrayList<>();
				keys.add(FormulaOptimiserContants.ID);
				Map<String, Object> entMap = new HashMap<>();

				getEntityMap(recipeIdFromParameter, poQuantity, entMap);

				Map<String, Object> recipeSpecMap = new HashMap<>();
				recipeSpecMap.put(FormulaOptimiserContants.ID, UUID.fromString(primaryOutputId).toString());
				Boolean correctNumOfDigits = true;
				correctNumOfDigits = checkNoOfDigits(poQuantity, correctNumOfDigits);
				EntityData recipeSpecEntityData = EntityData.createFromMap(entMap, keys,
						FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY);
				if (!correctNumOfDigits) {
					return OperationResponse.setError(
							ErrorResponse.getBuilder().setMessage("Overflow during quantity calculation").response());
				} else if (sumOfQuantity < 0) {
					return OperationResponse.setError(
							ErrorResponse.getBuilder().setMessage("Adjust input quantity for calculation").response());
				}
				dsHandler.executeUpdate(recipeSpecEntityData, recipeSpecMap, false);
			}
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
		return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
	}

	/**
	 * @param recipeIdFromParameter
	 * @param poQuantity
	 * @param entMap
	 */
	private void getEntityMap(String recipeIdFromParameter, String poQuantity, Map<String, Object> entMap) {
		entMap.put(FormulaOptimiserContants.RECIPE_I, recipeIdFromParameter);
		entMap.put(FormulaOptimiserContants.QUANTITY, poQuantity);
		entMap.put(FormulaOptimiserContants.UOM, FormulaOptimiserContants.KG);
		entMap.put(FormulaOptimiserContants.COMPONENT_TYPE, FormulaOptimiserContants.PRODUCT);
	}

	/*
	 * 
	 * Below
	 * 
	 * @param poQuantity
	 * 
	 * @param rightDigits
	 * 
	 * @return
	 */
	private Boolean checkNoOfDigits(String poQuantity, Boolean correctNumOfDigits) {
		if (poQuantity.contains(".")) {
			if (poQuantity.indexOf('.', 12) > -1) {
				correctNumOfDigits = false;
			}
		} else {
			if (poQuantity.length() > 12) {
				correctNumOfDigits = false;
			}
		}
		return correctNumOfDigits;
	}

	/*
	 * This method calculates the sum of quantity value for all the
	 * specifications.
	 */

	private Double getSumOfQuantity(Double sumOfQuantity, Double qty, String uom, Double density, Double piecetoMass) {
		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking method getSumOfQuantity");
		try {

			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();
			CDSQuery cdsQueryUOM = new CDSSelectQueryBuilder(FormulaOptimiserContants.STANDARDUOM).selectColumns("*")
					.where(new ConditionBuilder().columnName(FormulaOptimiserContants.ID).IN(uom.toUpperCase()))
					.build();
			CDSSelectQueryResult cdsSelectQueryResultUOM;
			cdsSelectQueryResultUOM = dsHandler.executeQuery(cdsQueryUOM);
			List<EntityData> resultListUOM = cdsSelectQueryResultUOM.getResult();
			if (!resultListUOM.isEmpty()) {
				if (resultListUOM.get(0).getElementValue(FormulaOptimiserContants.KG) != null) {
					sumOfQuantity += qty * Double
							.parseDouble(resultListUOM.get(0).getElementValue(FormulaOptimiserContants.KG).toString());

				} else if (resultListUOM.get(0).getElementValue(FormulaOptimiserContants.CM3) != null) {
					sumOfQuantity += density * qty * Double
							.parseDouble(resultListUOM.get(0).getElementValue(FormulaOptimiserContants.CM3).toString());

				} else if ((resultListUOM.get(0).getElementValue(FormulaOptimiserContants.DEPENDENCY)) != null) {

					sumOfQuantity += qty * piecetoMass;
				} else {
					sumOfQuantity += 0.0;

				}
			}
		} catch (CDSException e) {
			LOGGER.error(e.getMessage(), e);
			return sumOfQuantity;
		}
		return sumOfQuantity;
	}

	/*
	 * The below function is updating the uom, quantity,
	 * specificationDescription and specificationId this function will call
	 * onchange of any of these attribute in recipeSpecificationDraft entity.
	 */
	@Function(Name = FormulaOptimiserContants.UPDATE_DRAFT_SPECIFICATION_VALUES, serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse updateDraftSpecificationValues(OperationRequest functionRequest,
			ExtensionHelper extensionHelper) {

		LOGGER.info(
				"Started executing class FormulaOptimiserCustonService invoking function updateDraftSpecificationValues");
		Map<String, Object> parameters = functionRequest.getParameters();
		Map<String, Object> whereCondition = new HashMap<>();
		DataSourceHandler handler = extensionHelper.getHandler();
		whereCondition.put(FormulaOptimiserContants.ID, parameters.get(FormulaOptimiserContants.ID));
		try {
			List<String> selectColumnsList = new ArrayList<>();
			selectColumnsList.add(FormulaOptimiserContants.ID);
			BigDecimal quantity = new BigDecimal(parameters.get(FormulaOptimiserContants.QUANTITY).toString());
			EntityData entityData = handler.executeRead(FormulaOptimiserContants.RECIPESPECIFICATION_DRAFTS,
					whereCondition, selectColumnsList);

			entityData = EntityData.getBuilder(entityData)
					.addElement(FormulaOptimiserContants.UOM, parameters.get(FormulaOptimiserContants.UOM))
					.addElement(FormulaOptimiserContants.QUANTITY, quantity)
					.addElement(FormulaOptimiserContants.COMPONENT_TYPE,
							parameters.get(FormulaOptimiserContants.COMPONENT_TYPE))
					.addElement(FormulaOptimiserContants.SPECIFICATION_DESCRIPTION,
							parameters.get(FormulaOptimiserContants.SPECIFICATION_DESCRIPTION))
					.addElement(FormulaOptimiserContants.SPECIFICATION_ID,
							parameters.get(FormulaOptimiserContants.SPECIFICATION_ID))
					.addElement(FormulaOptimiserContants.DENSITY, parameters.get(FormulaOptimiserContants.DENSITY))
					.addElement(FormulaOptimiserContants.PIECE_TO_MASS,
							parameters.get(FormulaOptimiserContants.PIECE_TO_MASS))
					.addElement(FormulaOptimiserContants.FORMULA_ITEM_DESCRIPTION,
							parameters.get(FormulaOptimiserContants.FORMULA_ITEM_DESCRIPTION))
					.buildEntityData(FormulaOptimiserContants.RECIPESPECIFICATION_DRAFTS);

			handler.executeUpdate(entityData, whereCondition, false);
			return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
	}

	/*
	 * The below function will check specification Id entered by user is there
	 * in specification table if it is not there then it will throw a message
	 */
	@Function(Name = FormulaOptimiserContants.VALIDATE_SPECIFICATION_ID, serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse validateSpecificationId(OperationRequest functionRequest,
			ExtensionHelper extensionHelper) {

		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking function validateSpecificationId");
		Map<String, Object> parameters = functionRequest.getParameters();
		try {
			if (parameters.get(FormulaOptimiserContants.SPECIFICATION_ID) != null) {
				Map<String, Object> whereCondition = new HashMap<>();
				DataSourceHandler handler = extensionHelper.getHandler();
				whereCondition.put(FormulaOptimiserContants.SPECIFICATION_ID,
						parameters.get(FormulaOptimiserContants.SPECIFICATION_ID));
				List<String> selectColumnsList = new ArrayList<>();
				selectColumnsList.add(FormulaOptimiserContants.SPECIFICATION_ID);
				EntityData entityData = handler.executeRead(FormulaOptimiserContants.SPECIFICATION, whereCondition,
						selectColumnsList);
				if (entityData == null) {
					return OperationResponse.setError(ErrorResponse.getBuilder()
							.setMessage("Specification "
									+ parameters.get(FormulaOptimiserContants.SPECIFICATION_ID).toString()
									+ " does not exist.")
							.response());
				}
			}
			return OperationResponse.setSuccess().response();
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
	}

	/*
	 * The below function will get layouts list from the DB for a specific user
	 */
	@Function(Name = FormulaOptimiserContants.GET_LAYOUT_LIST, serviceName = FormulaOptimiserContants.MANAGE_LAYOUT_SERVICE)
	public OperationResponse getLayoutList(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking function getLayoutList");
		List<EntityData> layoutList = new ArrayList<>();
		List<EntityData> layoutResultList = null;
		layoutResultList = fetchlayoutListFromDB(FormulaOptimiserContants.CREATED_BY,
				AuthorizationService.getUserName());

		if (!layoutResultList.isEmpty()) {
			layoutResultListNotEmpty(layoutList, layoutResultList);
		} else {
			layoutResultListEmpty(layoutList);

		}
		return OperationResponse.setSuccess().setEntityData(layoutList).response();
	}

	/**
	 * @param extensionHelper
	 * @param layoutList
	 */
	private void layoutResultListEmpty(List<EntityData> layoutList) {
		LOGGER.info(
				"Started executing class FormulaOptimiserCustomService invoking private method layoutResultListEmpty");
		List<EntityData> layoutResultList;
		layoutResultList = fetchlayoutListFromDB(FormulaOptimiserContants.LAYOUT_TYPE,
				FormulaOptimiserContants.DEFAULT);
		for (EntityData entityData : layoutResultList) {
			entityData = EntityData.getBuilder(entityData)
					.addElement(FormulaOptimiserContants.LAYOUT_NAME,
							entityData.getElementValue(FormulaOptimiserContants.LAYOUT_NAME))
					.addElement(FormulaOptimiserContants.DESCRIPTION,
							entityData.getElementValue(FormulaOptimiserContants.DESCRIPTION))
					.addElement(FormulaOptimiserContants.LAYOUT_TYPE,
							entityData.getElementValue(FormulaOptimiserContants.LAYOUT_TYPE))
					.addElement(FormulaOptimiserContants.REFERENCE_QUANTITY,
							entityData.getElementValue(FormulaOptimiserContants.REFERENCE_QUANTITY))
					.addElement(FormulaOptimiserContants.CREATED_AT,
							entityData.getElementValue(FormulaOptimiserContants.CREATED_AT))
					.addElement(FormulaOptimiserContants.CREATED_BY,
							entityData.getElementValue(FormulaOptimiserContants.CREATED_BY))
					.addElement(FormulaOptimiserContants.MODIFIED_AT,
							entityData.getElementValue(FormulaOptimiserContants.MODIFIED_AT))
					.addElement(FormulaOptimiserContants.MODIFIED_BY,
							entityData.getElementValue(FormulaOptimiserContants.MODIFIED_BY))
					.addElement(FormulaOptimiserContants.UOM, entityData.getElementValue(FormulaOptimiserContants.UOM))
					.addElement(FormulaOptimiserContants.HAS_ACTIVE_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.IS_ACTIVE_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.HAS_DRAFT_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.HAS_ACTIVE_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.DRAFT_UUID, UUID.randomUUID())
					.addElement(FormulaOptimiserContants.DRAFTADMINISTRATIVEDATA_DRAFTUUID, UUID.randomUUID())
					.buildEntityData(FormulaOptimiserContants.LAYOUT_INFORMATION_ENTITY);
			layoutList.add(entityData);
		}
	}

	/**
	 * @param layoutList
	 * @param layoutResultList
	 */
	private void layoutResultListNotEmpty(List<EntityData> layoutList, List<EntityData> layoutResultList) {
		LOGGER.info(
				"Started executing class FormulaOptimiserCustomService invoking private method layoutResultListNotEmpty");
		for (EntityData entityData : layoutResultList) {
			EntityData entityDataNew = EntityData.getBuilder(entityData)
					.addElement(FormulaOptimiserContants.ID, entityData.getElementValue(FormulaOptimiserContants.ID))
					.addElement(FormulaOptimiserContants.LAYOUT_NAME,
							entityData.getElementValue(FormulaOptimiserContants.LAYOUT_NAME))
					.addElement(FormulaOptimiserContants.DESCRIPTION,
							entityData.getElementValue(FormulaOptimiserContants.DESCRIPTION))
					.addElement(FormulaOptimiserContants.LAYOUT_TYPE,
							entityData.getElementValue(FormulaOptimiserContants.LAYOUT_TYPE))
					.addElement(FormulaOptimiserContants.REFERENCE_QUANTITY,
							entityData.getElementValue(FormulaOptimiserContants.REFERENCE_QUANTITY))
					.addElement(FormulaOptimiserContants.CREATED_AT,
							entityData.getElementValue(FormulaOptimiserContants.CREATED_AT))
					.addElement(FormulaOptimiserContants.CREATED_BY,
							entityData.getElementValue(FormulaOptimiserContants.CREATED_BY))
					.addElement(FormulaOptimiserContants.MODIFIED_AT,
							entityData.getElementValue(FormulaOptimiserContants.MODIFIED_AT))
					.addElement(FormulaOptimiserContants.MODIFIED_BY,
							entityData.getElementValue(FormulaOptimiserContants.MODIFIED_BY))
					.addElement(FormulaOptimiserContants.HAS_ACTIVE_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.IS_ACTIVE_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.HAS_DRAFT_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.HAS_ACTIVE_ENTITY, Boolean.FALSE)
					.addElement(FormulaOptimiserContants.DRAFT_UUID, UUID.randomUUID())
					.addElement(FormulaOptimiserContants.UOM, entityData.getElementValue(FormulaOptimiserContants.UOM))
					.addElement(FormulaOptimiserContants.DRAFTADMINISTRATIVEDATA_DRAFTUUID, UUID.randomUUID())
					.buildEntityData(FormulaOptimiserContants.LAYOUT_INFORMATION_ENTITY);
			layoutList.add(entityDataNew);
		}
	}

	private List<EntityData> fetchlayoutListFromDB(String columnName, String columnValue) {
		LOGGER.info(
				"Started executing class FormulaOptimiserCustomService invoking private method fetchlayoutListFromDB");
		List<EntityData> resultList = null;
		List<EntityData> resultListDrafts = null;
		List<EntityData> modifiedResultList = new ArrayList<>();

		try {
			CDSDataSourceHandler cdsDataSourceHandler = CDSDataSourceHandlerFactory.getHandler();
			CDSQuery cdsQueryForLayoutList = new CDSSelectQueryBuilder(
					FormulaOptimiserContants.LAYOUT_INFORMATION_ENTITY)
							.selectColumns(FormulaOptimiserContants.ID, FormulaOptimiserContants.LAYOUT_NAME,
									FormulaOptimiserContants.DESCRIPTION, FormulaOptimiserContants.LAYOUT_TYPE,
									FormulaOptimiserContants.REFERENCE_QUANTITY, FormulaOptimiserContants.CREATED_AT,
									FormulaOptimiserContants.CREATED_BY, FormulaOptimiserContants.MODIFIED_AT,
									FormulaOptimiserContants.MODIFIED_BY, FormulaOptimiserContants.UOM)
							.where(new ConditionBuilder().columnName(columnName).IN(columnValue)).build();
			CDSSelectQueryResult cdsSelectQueryResultForLayoutList;
			cdsSelectQueryResultForLayoutList = cdsDataSourceHandler.executeQuery(cdsQueryForLayoutList);
			resultList = cdsSelectQueryResultForLayoutList.getResult();

			modifiedResultList = resultList;

			CDSQuery cdsQueryForLayoutListDraft = new CDSSelectQueryBuilder(
					FormulaOptimiserContants.LAYOUT_INFORMATION_ENTITY_DRAFT)
							.selectColumns(FormulaOptimiserContants.ID, FormulaOptimiserContants.LAYOUT_NAME)
							.where(new ConditionBuilder().columnName(columnName).IN(columnValue)).build();
			CDSSelectQueryResult cdsSelectQueryResultForLayoutListDraft;
			cdsSelectQueryResultForLayoutListDraft = cdsDataSourceHandler.executeQuery(cdsQueryForLayoutListDraft);
			resultListDrafts = cdsSelectQueryResultForLayoutListDraft.getResult();
			for (int s = 0; s <= resultList.size() - 1; s++) {
				for (EntityData t : resultListDrafts) {
					if (resultList.get(s).getElementValue(FormulaOptimiserContants.ID)
							.equals(t.getElementValue(FormulaOptimiserContants.ID))) {
						modifiedResultList.remove(s);
					}
				}
			}
		} catch (DatasourceException datasourceException) {
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return modifiedResultList;
		}
		return modifiedResultList;
	}

	/*
	 * The below function will delete the items from recipeSpecificationDraft
	 * table
	 */
	@Function(Name = FormulaOptimiserContants.DELETE_FORMULA_ITEM, serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse deleteFormulaItem(OperationRequest functionRequest, ExtensionHelper extensionHelper) {

		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking function deleteFormulaItem");
		Map<String, Object> parameters = functionRequest.getParameters();
		try {
			if (parameters.get(FormulaOptimiserContants.ITEM_NUMBER) != null) {
				Map<String, Object> whereCondition = new HashMap<>();
				DataSourceHandler handler = extensionHelper.getHandler();
				whereCondition.put(FormulaOptimiserContants.ITEM_NUMBER,
						parameters.get(FormulaOptimiserContants.ITEM_NUMBER));
				handler.executeDelete(FormulaOptimiserContants.RECIPESPECIFICATION_DRAFTS, whereCondition);
			}
			return OperationResponse.setSuccess().response();
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
	}

	/*
	 * Below function is reordering the selected specification when we select
	 * up/down arrow from UI. We are swapping the Item numbers of the
	 * specification ID which is present before/after with the selected
	 * specification ID.
	 */

	@Function(Name = FormulaOptimiserContants.REORDER_SPECIFICATION_ID, serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse reorderSpecificationID(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking function reorderSpecificationID");
		CDSDataSourceHandler cdsDataSourceHandler = CDSDataSourceHandlerFactory.getHandler();
		try {
			Map<String, Object> recipeSpecificationParameters = functionRequest.getParameters();
			if (recipeSpecificationParameters.get(FormulaOptimiserContants.REORDER_ACTION) != null) {
				CDSQuery cdsQuery = new CDSSelectQueryBuilder(
						FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY).top(1)
								.selectColumns(FormulaOptimiserContants.REORDER_SPECIFICATION_ID_SELECT_COLUMNS)
								.where(new ConditionBuilder().columnName(FormulaOptimiserContants.ID)
										.IN(recipeSpecificationParameters.get(FormulaOptimiserContants.ID)))
								.build();
				CDSSelectQueryResult queryResultForRecipeSpecification;
				queryResultForRecipeSpecification = cdsDataSourceHandler.executeQuery(cdsQuery);
				EntityData entityDataForSelectedRow = queryResultForRecipeSpecification.getResult().get(0);
				reorderWhenButtonUpOrDown(
						recipeSpecificationParameters.get(FormulaOptimiserContants.REORDER_ACTION).toString(),
						entityDataForSelectedRow, cdsDataSourceHandler, extensionHelper);
			}

		} catch (NumberFormatException | DatasourceException e) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(e.getMessage()).setCause(e).response();
			return OperationResponse.setError(errorResponse);
		}

		return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
	}

	/*
	 * Below is a private method , which is getting called from
	 * reorderSpecificationID function. This method is use to query the
	 * RecipeSpecification_Drafts table for Item number based on Recipe ID.
	 */

	private void reorderWhenButtonUpOrDown(String reorderAction, EntityData entityDataForSelectedRow,
			CDSDataSourceHandler cDSDataSourceHandler, ExtensionHelper extensionHelper) {
		LOGGER.info(
				"Started executing class FormulaOptimiserCustomService invoking function reorderWhenButtonUpOrDown");
		try {
			CDSQuery cdsQuery = null;
			if (reorderAction.equals(FormulaOptimiserContants.BUTTON_UP)) {
				cdsQuery = new CDSSelectQueryBuilder(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY).top(1)
						.selectColumns(FormulaOptimiserContants.REORDER_SPECIFICATION_ID_SELECT_COLUMNS)
						.where(new ConditionBuilder().columnName(FormulaOptimiserContants.ITEM_NUMBER)
								.LT(entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.ITEM_NUMBER))
								.AND(new ConditionBuilder().columnName(FormulaOptimiserContants.RECIPE_ID).IN(
										entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.RECIPE_ID)))
								.AND(new ConditionBuilder().columnName(FormulaOptimiserContants.SPECIFICATION_ID).NE(
										entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.RECIPE_ID))))
						.orderBy(FormulaOptimiserContants.ITEM_NUMBER, true).build();
			} else if (reorderAction.equals(FormulaOptimiserContants.BUTTON_DOWN)) {
				cdsQuery = new CDSSelectQueryBuilder(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY).top(1)
						.selectColumns(FormulaOptimiserContants.REORDER_SPECIFICATION_ID_SELECT_COLUMNS)
						.where(new ConditionBuilder().columnName(FormulaOptimiserContants.ITEM_NUMBER)
								.GT(entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.ITEM_NUMBER))
								.AND(new ConditionBuilder().columnName(FormulaOptimiserContants.RECIPE_ID).IN(
										entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.RECIPE_ID)))
								.AND(new ConditionBuilder().columnName(FormulaOptimiserContants.SPECIFICATION_ID).NE(
										entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.RECIPE_ID))))
						.orderBy(FormulaOptimiserContants.ITEM_NUMBER, false).build();
			}
			CDSSelectQueryResult queryResultForRecipeSpecification;
			queryResultForRecipeSpecification = cDSDataSourceHandler.executeQuery(cdsQuery);
			if (!queryResultForRecipeSpecification.getResult().isEmpty()) {
				EntityData entityDataForAdjacentRow = queryResultForRecipeSpecification.getResult().get(0);
				swapItemNumber(entityDataForSelectedRow, entityDataForAdjacentRow, extensionHelper);
			}
		} catch (DatasourceException | NumberFormatException | ArrayIndexOutOfBoundsException e) {
			LOGGER.error(e.getMessage(), e);
		}
	}

	/**
	 * Below is a private method , which is getting called from
	 * reorderWhenButtonUpOrDown method. This method is use to swap the Item
	 * numbers of the selected record with the record before and after and
	 * updating the RecipeSpecificat_Drafts entity.
	 */

	private void swapItemNumber(EntityData entityDataForSelectedRow, EntityData entityDataForAdjacentRow,
			ExtensionHelper extensionHelper) throws DatasourceException {
		LOGGER.info("Started executing class FormulaOptimiserCustomService invoking private method swapItemNumber");
		DataSourceHandler dsHandler = extensionHelper.getHandler();
		Integer itemNumber = Integer
				.parseInt(entityDataForAdjacentRow.getElementValue(FormulaOptimiserContants.ITEM_NUMBER).toString());
		entityDataForAdjacentRow = EntityData.getBuilder(entityDataForAdjacentRow)
				.removeElement(FormulaOptimiserContants.ITEM_NUMBER)
				.addElement(FormulaOptimiserContants.ITEM_NUMBER,
						entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.ITEM_NUMBER))
				.buildEntityData(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY);
		Map<String, Object> adjacentRecordKey = new HashMap<>();
		adjacentRecordKey.put(FormulaOptimiserContants.ID,
				entityDataForAdjacentRow.getElementValue(FormulaOptimiserContants.ID));
		entityDataForSelectedRow = EntityData.getBuilder(entityDataForSelectedRow)
				.removeElement(FormulaOptimiserContants.ITEM_NUMBER)
				.addElement(FormulaOptimiserContants.ITEM_NUMBER, itemNumber)
				.buildEntityData(FormulaOptimiserContants.RECIPE_SPECIFICATION_DRAFTS_ENTITY);
		Map<String, Object> selectedRecordKey = new HashMap<>();
		selectedRecordKey.put(FormulaOptimiserContants.ID,
				entityDataForSelectedRow.getElementValue(FormulaOptimiserContants.ID));
		dsHandler.executeUpdate(entityDataForAdjacentRow, adjacentRecordKey, false);
		dsHandler.executeUpdate(entityDataForSelectedRow, selectedRecordKey, false);
	}

	/*
	 * The below function import will validate manually entered UOM and return
	 * the UOM ID
	 */

	@Function(Name = "validateManuallyEnteredUOM", serviceName = FormulaOptimiserContants.SERVICENAME)
	public OperationResponse validateManuallyEnteredUOM(OperationRequest functionRequest,
			ExtensionHelper extensionHelper) {
		LOGGER.info(
				"Started executing class FormulaOptimiserCustomService invoking function validateManuallyEnteredUOM");
		Map<String, Object> parameters = functionRequest.getParameters();
		String uom = null;
		try {
			if (parameters.get(FormulaOptimiserContants.VALIDATE_UOM) != null) {
				uom = parameters.get(FormulaOptimiserContants.VALIDATE_UOM).toString().toUpperCase();
				Map<String, Object> whereCondition = new HashMap<>();
				DataSourceHandler handler = extensionHelper.getHandler();
				whereCondition.put(FormulaOptimiserContants.ID, uom);
				List<String> selectColumnsList = new ArrayList<>();
				selectColumnsList.add(FormulaOptimiserContants.ID);
				EntityData entityData = handler.executeRead(FormulaOptimiserContants.UOM, whereCondition,
						selectColumnsList);
				if (entityData == null) {
					return OperationResponse.setError(ErrorResponse
							.getBuilder().setMessage("The Unit of Measure "
									+ parameters.get(FormulaOptimiserContants.VALIDATE_UOM) + " is invalid")
							.response());
				}
			}
			return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList(uom)).response();
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
	}

}
