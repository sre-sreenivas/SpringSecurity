package com.complianceevaluator.services;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.json.*;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryBuilder;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryResult;
import com.sap.cloud.sdk.cloudplatform.security.AuthTokenAccessor;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSQuery;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryBuilder;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.cds.ConditionBuilder;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterQuery;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterQueryDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterReadDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.BeforeCreateDraft;
import com.sap.cloud.sdk.service.prov.api.exits.BeforeCreateResponse;
import com.sap.cloud.sdk.service.prov.api.request.CreateRequest;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.request.ReadRequest;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponse;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponse;
import com.sap.cloud.sdk.service.prov.api.response.ReadResponseAccessor;
import com.complianceevaluator.constants.EvaluationConstants;

/*
* This class is implementing TransactionHooks for  EvaluationStatus entity
* @AfterReadDraft , @AfterRead, @AfterQuery and @AfterQueryDraft transaction hooks are implemented to modify the response on read and query operations.
* @BeforeCreateDraft needs to be implemented to add validation from backend.
*/
public class EvaluationHooksHandler {

	private static final Logger LOGGER = Logger.getLogger(EvaluationHooksHandler.class.getName());	
	

	/*
	 * Implementation of @AfterReadDraft operation for Evaluation entity. This method is
	 * modifying response to add recipe count , recipe compliant
	 * status and piechart info to Evaluation entity.
	 */
	@AfterReadDraft(entity = EvaluationConstants.ENTITY_EVALUATION, serviceName = EvaluationConstants.SERVICENAME)
	public ReadResponse displayEvaluationSheet(ReadRequest request, ReadResponseAccessor response,
			ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing afterReadEvaluation of EvaluationHooksHandler class");
		EntityData evaluationEntityData = response.getEntityData();
		EntityData modifiedEvaluationEntityData = null;
		String evalStatus = null;
		String nextEvalStatus = null;
		Integer statusCriticality = null;
		String evaluationId = null;
		if (null != evaluationEntityData
				&& null != evaluationEntityData.getElementValue(EvaluationConstants.EVALUATION_ID)) {			
			CDSDataSourceHandler cdsHandler = CDSDataSourceHandlerFactory.getHandler();
			evalStatus = evaluationEntityData.getElementValue(EvaluationConstants.EVAL_STATUS).toString();
			if (null != evaluationEntityData.getElementValue(EvaluationConstants.EVAL_STATUS)) {
				nextEvalStatus = getEvaluationNextStatus(evalStatus, cdsHandler);
				statusCriticality = getStatusCriticality(evalStatus);
			}
			try {
				evaluationId = evaluationEntityData.getElementValue(EvaluationConstants.EVALUATION_ID).toString();
				HashMap<String, Integer> evaluationEntityDataForPieChart = setPieChartValues(evaluationId, cdsHandler);

				modifiedEvaluationEntityData = EntityData.getBuilder(evaluationEntityData)
						.addElement(EvaluationConstants.NEXT_EVAL_STATUS, nextEvalStatus)
						.addElement(EvaluationConstants.STATUS_CRITICALITY, statusCriticality)
						.addElement(EvaluationConstants.RECIPE_COUNT,
								evaluationEntityDataForPieChart.get(EvaluationConstants.RECIPE_COUNT))
						.addElement(EvaluationConstants.COMPLIANT_RECIPE_COUNT,
								evaluationEntityDataForPieChart.get(EvaluationConstants.COMPLIANT_STATUS))
						.addElement(EvaluationConstants.RECIPE_CRITICALITY_INDICATOR,
								evaluationEntityDataForPieChart.get(EvaluationConstants.RECIPE_CRITICALITY_INDICATOR))
						.buildEntityData(EvaluationConstants.ENTITY_EVALUATION);

			} catch (Exception exception) {
				LOGGER.error(exception.getMessage(), exception);
			}

		}

		return ReadResponse.setSuccess().setData(modifiedEvaluationEntityData).response();
	}

	/*
	 * Implementation of AfterQuery operation for Master Recipe Entity. This method
	 * Calling Recipe setting values for Pie chart in list report template , next
	 * evaluation status and selling market info in EvaluationEntity.
	 */

	@AfterQuery(entity = EvaluationConstants.MASTER_RECIPE, serviceName = EvaluationConstants.SERVICENAME)
	public QueryResponse afterQueryMasterRecipe (QueryRequest request, QueryResponseAccessor response,
			ExtensionHelper extensionHelper) {
		
		LOGGER.info("Started executing afterQueryForRecipe of EvaluationHooksHandler class");

		
		List<EntityData> masterRecipeList =  new ArrayList<>();
		for (EntityData entityData : masterRecipeList) {
			masterRecipeList.remove(entityData);
		}
		boolean destinationRelevantHeader = true;
		try {
			ODataQueryResult readResult = ODataQueryBuilder.withEntity("/sap/opu/odata/SAP/API_RECIPE/", "A_Recipe")
					.withHeader(EvaluationConstants.SAP_CLIENT, "001", destinationRelevantHeader)
					.withHeader(EvaluationConstants.SAP_LANGUAGE , "EN", destinationRelevantHeader)
					.withHeader(EvaluationConstants.AUTHORIZATION,
							AuthTokenAccessor.getXsuaaServiceToken().getJwt().getToken())
					.select(EvaluationConstants.RECEIPE_UUID, EvaluationConstants.RECIPE_UUID_TEXT, EvaluationConstants.PLANT, EvaluationConstants.RECIPE_VALIDITY_END_DATE, EvaluationConstants.RECIPE_TYPE,
							EvaluationConstants.RECIPE_STATUS)
					.build().execute(EvaluationConstants.BACKEND_DESTINATION_NAME);

			if (null != readResult) {
				JSONObject jsonObj = new JSONObject(readResult.getStreamData());

				JSONObject jobj2 = (JSONObject) (jsonObj.get("d"));
				JSONArray jsonarr_1 = (JSONArray) jobj2.get("results");

				for (int i = 0; i < jsonarr_1.length(); i++) {
					JSONObject jsonobj_1 = (JSONObject) jsonarr_1.get(i);
					if (null != jsonobj_1) {
						HashMap<String, Object> masterRecipeProperties = new HashMap<>();
						masterRecipeProperties.put(EvaluationConstants.R_UUID, jsonobj_1.get(EvaluationConstants.RECEIPE_UUID));
						masterRecipeProperties.put(EvaluationConstants.RECIPE_DESCRIPTION, jsonobj_1.get(EvaluationConstants.RECIPE_UUID_TEXT));
						masterRecipeProperties.put(EvaluationConstants.VALIDITY_AREA, jsonobj_1.get(EvaluationConstants.PLANT));
						masterRecipeProperties.put(EvaluationConstants.R_TYPE, jsonobj_1.get(EvaluationConstants.RECIPE_TYPE));
						masterRecipeProperties.put(EvaluationConstants.R_STATUS, jsonobj_1.get(EvaluationConstants.RECIPE_STATUS));
						List<String> masterRecipeKeys = new ArrayList<>();
						masterRecipeKeys.add((String) jsonobj_1.get(EvaluationConstants.RECEIPE_UUID));
						masterRecipeKeys.add((String) jsonobj_1.get(EvaluationConstants.RECIPE_UUID_TEXT));
						masterRecipeKeys.add((String) jsonobj_1.get(EvaluationConstants.PLANT));
						masterRecipeKeys.add((String) jsonobj_1.get(EvaluationConstants.RECIPE_TYPE));
						masterRecipeKeys.add((String) jsonobj_1.get(EvaluationConstants.RECIPE_STATUS));

						EntityData entityData = EntityData.createFromMap(masterRecipeProperties, masterRecipeKeys, EvaluationConstants.MASTER_RECIPE);
						masterRecipeList.add(entityData);
					}
				}
			}

		} catch (Exception e) {
			for (int i = 0; i < 10; i++) {
				HashMap<String, Object> masterRecipeProperties = new HashMap<>();
				List<String> masterRecipeKeys = new ArrayList<>();
				masterRecipeProperties.put(EvaluationConstants.R_UUID, "01739547-9578-4e5b-9eac-bfc589ec40f" + i);
				masterRecipeProperties.put(EvaluationConstants.RECIPE_DESCRIPTION, EvaluationConstants.YOGURT_RECIPE);
				masterRecipeProperties.put(EvaluationConstants.VALIDITY_AREA, EvaluationConstants.VALID_AREA);
				masterRecipeProperties.put(EvaluationConstants.R_TYPE, EvaluationConstants.CATEGORY_GENERAL);
				masterRecipeProperties.put(EvaluationConstants.R_STATUS,EvaluationConstants.STATUS_OF_RECIPE);
				masterRecipeKeys.add(EvaluationConstants.R_UUID);
				masterRecipeKeys.add(EvaluationConstants.RECIPE_DESCRIPTION);
				masterRecipeKeys.add(EvaluationConstants.VALIDITY_AREA);
				masterRecipeKeys.add(EvaluationConstants.R_TYPE);
				masterRecipeKeys.add(EvaluationConstants.R_STATUS);

				EntityData entityDataForMasterRecipe = EntityData.createFromMap(masterRecipeProperties, masterRecipeKeys, EvaluationConstants.MASTER_RECIPE);
				masterRecipeList.add(entityDataForMasterRecipe);
			}
			LOGGER.error(e.getMessage(), e);
			return QueryResponse.setSuccess().setData(masterRecipeList).response();
		}
		return QueryResponse.setSuccess().setData(masterRecipeList).response();
	}

	/*
	 * Implementation of @AfterQueryDraft operation for Evaluation entity. This method is
	 * setting values for Pie chart in list report template , next evaluation status
	 * and selling market info in EvaluationEntity.
	 *
	 */

	@AfterQueryDraft(entity = EvaluationConstants.ENTITY_EVALUATION, serviceName = EvaluationConstants.SERVICENAME)
	public QueryResponse getEvaluationList(QueryRequest request, QueryResponseAccessor response,
			ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing getEvaluationList of EvaluationHooksHandler class");
		List<EntityData> evaluationDataList = response.getEntityDataList();
		List<EntityData> modifiedEvaluationList = new ArrayList<>();
		String evaluationId = null;
		String nextEvalStatus = null;
		String evalStatus = null;
		Integer statusCriticality = null;
		
		CDSDataSourceHandler cdsHandler = CDSDataSourceHandlerFactory.getHandler();
		for (EntityData evaluationEntityData : evaluationDataList) {
			EntityData modifiedEvaluationEntityData = null;
			evaluationId = evaluationEntityData.getElementValue(EvaluationConstants.EVALUATION_ID).toString();
			evalStatus = evaluationEntityData.getElementValue(EvaluationConstants.EVAL_STATUS).toString();
			if (null != evaluationEntityData.getElementValue(EvaluationConstants.EVAL_STATUS)) {
				nextEvalStatus = getEvaluationNextStatus(evalStatus, cdsHandler);
				statusCriticality = getStatusCriticality(evalStatus);
			}
			try {

				HashMap<String, Integer> chartData = setPieChartValues(evaluationId, cdsHandler);
				modifiedEvaluationEntityData = EntityData.getBuilder(evaluationEntityData)
						.addElement(EvaluationConstants.NEXT_EVAL_STATUS, nextEvalStatus)
						.addElement(EvaluationConstants.STATUS_CRITICALITY, statusCriticality)
						.addElement(EvaluationConstants.RECIPE_COUNT, chartData.get(EvaluationConstants.RECIPE_COUNT))
						.addElement(EvaluationConstants.COMPLIANT_RECIPE_COUNT,
								chartData.get(EvaluationConstants.COMPLIANT_STATUS))
						.addElement(EvaluationConstants.RECIPE_CRITICALITY_INDICATOR,
								chartData.get(EvaluationConstants.RECIPE_CRITICALITY_INDICATOR))
						.buildEntityData(EvaluationConstants.ENTITY_EVALUATION);

				modifiedEvaluationList.add(modifiedEvaluationEntityData);

			} catch (Exception exception) {
				LOGGER.error(exception.getMessage(), exception);
			}
		}
		return QueryResponse.setSuccess().setEntityData(modifiedEvaluationList).response();

	} 
	/*
	 *Implementation of @AfterQuery operation for CountryForValueHelp Entity.
	 *This method is getting the data from SAP common countries and store in CountryForValueHelp table
	 *when we click on Go button from UI.
	 */
	@AfterQuery(entity = EvaluationConstants.COUNTRY_FOR_VALUE_HELP, serviceName = EvaluationConstants.SERVICENAME)
        public QueryResponse getCountryForValueHelp(QueryRequest request, QueryResponseAccessor response,
            ExtensionHelper extensionHelper) {
			LOGGER.info("Started executing getCountryForValueHelp of EvaluationHooksHandler class");
	     if(!response.getEntityDataList().isEmpty()){
        	return response.getOriginalResponse();
        }
        List<EntityData> modifiedList = new ArrayList<>();
        int countryID=0;
        CDSSelectQueryResult countryResult;
        	CDSDataSourceHandler cdsHandler = CDSDataSourceHandlerFactory.getHandler();
        CDSQuery queryForCountries = new CDSSelectQueryBuilder(EvaluationConstants.COUNTRIES).selectColumns(EvaluationConstants.NAME).build();
        try {
			countryResult = cdsHandler.executeQuery(queryForCountries);
        for (EntityData entityData : countryResult.getResult()) {
            List<String> keys = new ArrayList<>();
            keys.add(EvaluationConstants.ID);
            keys.add(EvaluationConstants.COUNTRY_NAME);
            Map<String, Object> entityMap = new HashMap<>();
            entityMap.put(EvaluationConstants.ID, ++countryID);
            entityMap.put(EvaluationConstants.COUNTRY_NAME, entityData.getElementValue(EvaluationConstants.NAME).toString());
            EntityData edForCountry = EntityData.createFromMap(entityMap, keys, EvaluationConstants.COUNTRY_FOR_VALUE_HELP_ENTITY);
            modifiedList.add(edForCountry);
            cdsHandler.executeInsert(edForCountry,false);
        }
        } catch (CDSException cdsException) {
        	LOGGER.error(cdsException.getMessage(), cdsException);
		}
        return QueryResponse.setSuccess().setData(modifiedList).response();
    }
	/*
	 * This method is called from @afterQuery on Evaluation entity to set the pie
	 * chart info in Evaluation Entity.
	 */
	private HashMap<String, Integer> setPieChartValues(String evaluationId, CDSDataSourceHandler cdsHandler){
		LOGGER.info("Inside method setPieChartValues");
		Integer recipeCount = 0;
		Integer recipeStatus = 0;
		float pieChartInfo = 0;
		Integer recipeCriticalityIndicator = 0;		
		HashMap<String, Integer> map = new HashMap<>();
		CDSQuery cdsQuery = new CDSSelectQueryBuilder(EvaluationConstants.RECIPE)
				.selectColumns(EvaluationConstants.COMPLIANT_STATUS)
				.where(new ConditionBuilder().columnName(EvaluationConstants.EVALUATION_ID).IN(evaluationId)).build();
		try {
			CDSSelectQueryResult cdsSelectQueryResult = cdsHandler.executeQuery(cdsQuery);
			List<EntityData> resultList = cdsSelectQueryResult.getResult();

			if (resultList.isEmpty()) {
				CDSQuery cdsQueryForDraft = new CDSSelectQueryBuilder(EvaluationConstants.RECIPE_DRAFTS)
						.selectColumns(EvaluationConstants.COMPLIANT_STATUS)
						.where(new ConditionBuilder().columnName(EvaluationConstants.EVALUATION_ID).IN(evaluationId))
						.build();
				CDSSelectQueryResult cdsSelectQueryResultForDraft = cdsHandler.executeQuery(cdsQueryForDraft);
				resultList = cdsSelectQueryResultForDraft.getResult();
			}
			for (EntityData entityData : resultList) {
				recipeStatus = entityData.getElementValue(EvaluationConstants.COMPLIANT_STATUS).toString()
						.equals(EvaluationConstants.COMPLIANT) ? recipeStatus + 1 : recipeStatus;
			}
			recipeCount = resultList.size();

			if (recipeStatus != 0) {
				pieChartInfo = (float) recipeStatus / (float) recipeCount;

				if (pieChartInfo < EvaluationConstants.RECIPE_COMPLIANCE_CHECK) {
					recipeCriticalityIndicator = EvaluationConstants.RECIPE_CRITICALITY_RED;
				} else if (pieChartInfo > EvaluationConstants.RECIPE_COMPLIANCE_CHECK) {
					recipeCriticalityIndicator = EvaluationConstants.RECIPE_CRITICALITY_GREEN;

				} else {
					recipeCriticalityIndicator = EvaluationConstants.RECIPE_CRITICALITY_AMBER;
				}
			}
			map.put(EvaluationConstants.RECIPE_COUNT , recipeCount);
			map.put(EvaluationConstants.COMPLIANT_STATUS, recipeStatus);
			map.put(EvaluationConstants.RECIPE_CRITICALITY_INDICATOR, recipeCriticalityIndicator);

		} catch (CDSException e) {
			LOGGER.info("CDS Exception:- " + e.getMessage());
		}
		return map;

	}

	/*
	 * This method is called from @afterQuery on Evaluation entity to get the next
	 * status of the evaluation Id from EvaluationStatus entity.
	 */

	private String getEvaluationNextStatus(String status, CDSDataSourceHandler dsHandler) {
		LOGGER.info("Inside method getEvaluationNextStatus");
		String nextStatus = null;
		CDSQuery cdsEvaluationNextStatusQuery = new CDSSelectQueryBuilder(EvaluationConstants.ENTITY_EVALUATION_STATUS)
				.selectColumns(EvaluationConstants.NEXT_STATUS)
				.where(new ConditionBuilder().columnName(EvaluationConstants.STATUS).IN(status)).build();
		CDSSelectQueryResult cdsEvaluationNextStatusResult;
		try {
			cdsEvaluationNextStatusResult = dsHandler.executeQuery(cdsEvaluationNextStatusQuery);
			for (EntityData nextStatusResultList : cdsEvaluationNextStatusResult.getResult()) {
				if (null != nextStatusResultList.getElementValue(EvaluationConstants.NEXT_STATUS)) {
					nextStatus = nextStatusResultList.getElementValue(EvaluationConstants.NEXT_STATUS).toString();
				}
			}

		} catch (CDSException cdsException) {
			LOGGER.error(cdsException.getMessage(), cdsException);
		}
		return nextStatus;
	}

	/*
	 * This method will return criticality value on the basis of evalStatus.
	 */
	public Integer getStatusCriticality(String status) {
		LOGGER.info("Executing getStatusCriticality  of EvaluationHooksHandler class ");
		switch (status) {
		case EvaluationConstants.STATUS_NEW:
			return 1;
		case EvaluationConstants.STATUS_IN_PROGRESS:
			return 2;
		case EvaluationConstants.CLOSED :
			return 3;
		default:
			return null;
		}

	}

	/*
	 * Implementation of @BeforeCreateDraft operation for Evaluation entity. This method
	 * is setting evaluation name before the creation of evaluation sheet.
	 */
	@BeforeCreateDraft(entity = EvaluationConstants.ENTITY_EVALUATION, serviceName = EvaluationConstants.SERVICENAME)
	public BeforeCreateResponse beforeCreateEvaluation(CreateRequest createRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing beforeCreateEvaluation  of EvaluationHooksHandler class ");
		
		EntityData entityData = createRequest.getData();
		EntityData modifiedEntityData = null;
		modifiedEntityData = EntityData.getBuilder(entityData).addElement(EvaluationConstants.EVAL_STATUS, EvaluationConstants.STATUS_NEW)
				.addElement(EvaluationConstants.NEXT_EVAL_STATUS, EvaluationConstants.STATUS_IN_PROGRESS).addElement(EvaluationConstants.STATUS_CRITICALITY, 1)
				.buildEntityData(EvaluationConstants.EVALUATION);
		return BeforeCreateResponse.setSuccess().setEntityData(modifiedEntityData).response();

	}
}
