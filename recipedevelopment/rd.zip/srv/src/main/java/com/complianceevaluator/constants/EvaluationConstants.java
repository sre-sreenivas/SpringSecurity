package com.complianceevaluator.constants;

public final class EvaluationConstants {
	
	private EvaluationConstants(){
	//Private constructor to avoid implicit Object creation	
	}

	public static final String ENTITY_EVALUATION = "Evaluation";
	public static final String ENTITY_EVALUATION_DRAFTS = "EVALUATION_Drafts";
	public static final String EVALUATION_DRAFTS = "ComplianceEvaluatorService.EVALUATION_Drafts";
	public static final String SELLING_MARKET = "sellingMarket";
	public static final String NEXT_EVAL_STATUS = "nextEvalStatus";
	public static final String RECIPE_COUNT = "recipeCount";
	public static final String COMPLIANT_RECIPE_COUNT = "compliantRecipeCount";
	public static final String PIE_CHART_INFO = "pieChartInfo";
	public static final String EVALUATION_NAME = "evaluationName";
	public static final String EVALUATION_SELLING_MARKET = "ComplianceEvaluatorService.EvaluationSellingMarket";
	public static final String EVALUATION_SELLING_MARKET_DRAFT = "ComplianceEvaluatorService.EVALUATIONSELLINGMARKET_DRAFTS";
	public static final String NEXT_STATUS = "nextStatus";
	public static final String RECIPE = "ComplianceEvaluatorService.Recipe";
	public static final String RECIPE_CRITICALITY_INDICATOR = "recipeCriticalityIndicator";
	public static final String COMPLIANT_STATUS = "compliantStatus";
	public static final String COMPLIANT = "COMPLIANT";
	public static final String RECIPE_DRAFTS = "ComplianceEvaluatorService.Recipe_Drafts";
	public static final String ENTITY_EVALUATION_STATUS = "ComplianceEvaluatorService.EvaluationStatus";
	public static final String STATUS = "status";
	public static final String EVAL_STATUS = "evalStatus";
	public static final String EVALUATION = "Evaluation";
	public static final String SERVICENAME = "ComplianceEvaluatorService";
	public static final String EVALUATION_STATUS_SAVE = "evaluationStatusSave";
	public static final String EVALUATION_ID = "evaluationID";
	public static final String EVAL_ID = "EVALUATION_ID";
	public static final String NEW_EVALUATION_SHEET = "New evaluation sheet";
	public static final String STATUS_CRITICALITY = "criticality";
	public static final String UPDATE_SELLING_MARKET = "updateSellignMarket";
	public static final String REMOVE_DUPLICATE_RECIPE = "removeDuplicateRecipe";
	public static final String RECIPE_ID = "recipeId";
	public static final String YOGURT_RECIPE = "Yogurt recipe";
	public static final String VALID_AREA = "India";
	public static final String CATEGORY_GENERAL = "GENERAL";
	public static final String STATUS_OF_RECIPE = "100";
	public static final String ID = "ID";
	public static final String IS_ACTIVE_ENTITY = "IsActiveEntity";
	public static final String HAS_ACTIVE_ENTITY = "HasActiveEntity";
	public static final String HAS_DRAFT_ENTITY = "HasDraftEntity";
	// For Test Class
	public static final String STATUS_NEW = "New";
	public static final String DATA_MODEL = "complianceevaluator.datamodel";
	public static final String SELLING_MARKET_VALUE = "India";
	public static final String GET_EVALUATION_SELLINGMARKET = "getEvaluationSellingMarket";
	public static final String MASTER_RECIPE = "MasterRecipe";
	public static final String RECIPE_DRAFTS_ENTITY = "ComplianceEvaluatorService.RECIPE_DRAFTS";
	public static final String RECIPE_ENTITY = "ComplianceEvaluatorService.RECIPE";
	public static final String RECEIPE_UUID = "RecipeUUID";
	public static final String MASTER_PURPOSE = "MasterPurpose";
	public static final String PURPOSE_ID = "purposeId";
	public static final String PURPOSE_DRAFTS_ENTITY = "ComplianceEvaluatorService.PURPOSE_DRAFTS";
	public static final String PURPOSE_UUID = "purposeUUID";
	
	public static final Double RECIPE_COMPLIANCE_CHECK = 0.5;
	public static final Integer RECIPE_CRITICALITY_GREEN = 3;
	public static final Integer RECIPE_CRITICALITY_RED = 1;
	public static final Integer RECIPE_CRITICALITY_AMBER = 2;
	
	public static final String COUNTRY_FOR_VALUE_HELP  = "CountryForValueHelp";
	public static final String COUNTRY_FOR_VALUE_HELP_ENTITY  = "ComplianceEvaluatorService.CountryForValueHelp";
	public static final String COUNTRIES = "sap.common.Countries";
	public static final String NAME = "NAME";
	public static final String COUNTRY_NAME= "countryName" ;
	public static final String STATUS_IN_PROGRESS = "In Progress";	
	public static final String CLOSED = "Closed";	
	public static final String BACKEND_DESTINATION_NAME = "ER1CLNT";
	
	public static final String RECIPE_DESCRIPTION = "recipeDescription";
	public static final String SAP_CLIENT = "sap-client" ;
	public static final String SAP_LANGUAGE = "sap-language";
	public static final String AUTHORIZATION = "Authorization" ;
	public static final String RECIPE_UUID_TEXT ="RecipeUUID_Text";
	public static final String RECIPE_STATUS = "RecipeStatus";
	public static final String RECIPE_VALIDITY_END_DATE = "RecipeValidityEndDate" ;
	public static final String R_UUID = "recipeUUID";
	public static final String PLANT = "Plant";	
	public static final String RECIPE_TYPE = "RecipeType";
	public static final String R_TYPE = "recipeType";
	public static final String R_STATUS = "recipeStatus";
	
	public static final String VALIDITY_AREA = "validityArea";
	public static final String EVALUATION_STATUS ="EvaluationStatus";
	public static final String NOT_ASSESSED = "Not Assessed";
	public static final String COPY_RECIPE = "copyRecipe";
	public static final String DRAFTADMINISTRATIVEDATA_DRAFTUUID = "DRAFTADMINISTRATIVEDATA_DRAFTUUID";
	public static final String ADDED_BY = "addedBy";
	public static final String ADDED_ON = "addedOn";
	public static final String SAVE_RECIPE = "saveRecipe";
	public static final String PURPOSE = "purpose";	
	public static final String PURPOSE_TYPE = "purposeType";
	
	public static final String REQUIREMENT =  "requirement";
	public static final String REQUIREMENT_ID = "requirementID";
	
	public static final String ONE = "1";
	public static final String TWO = "2";
	public static final String THREE = "3";
	public static final String CREATED_BY = "createdBy";
	public static final String CREATED_ON = "createdOn";
	public static final String VALUE = "value";
	public static final String NO_OF_REQUIREMENTS = "noOfRequirements";
	public static final String ACTIVATION_STATUS = "activationStatus";
	public static final String N = "N";
	public static final String CMPLNC_PRPS_NAME = "CmplncPrpsName";
	public static final String CMPLNC_PRPS_UUID = "CmplncPrpsUUID" ;
	public static final String CREATED_BY_USER= "CreatedByUser";
	public static final String CREATION_DATE_TIME = "CreationDateTime";
	public static final String ACTIVE = "Active"; 
	public static final String IN_ACTIVE = "Inactive";	
	public static final String ADD_RECIPE = "addRecipe";
	public static final String ADD_PURPOSE = "addPurpose";	
	
	
	
} 
