package com.complianceevaluator.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.log4j.Logger;
import com.complianceevaluator.constants.EvaluationConstants;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSQuery;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryBuilder;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.cds.ConditionBuilder;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.Function;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.OperationRequest;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.OperationResponse;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
*This class is implementing @function which is updating the Evaluation status , selling market , adding Recipe , 
*adding purpose and copy recipe for an evaluation ID in Evaluation entity. 
*/

public class EvaluationCustomService {

	private static final Logger LOGGER = Logger.getLogger(EvaluationCustomService.class.getName());

	/*
	 * Below method is implementing @Function which is updating the Evaluation
	 * status for the given evaluation ID in Evaluation entity, that is, if the
	 * current status is “New” it gets changed to “In-Progress” and if its
	 * “In-Progress” then to “Closed”.
	 */

	@Function(Name = EvaluationConstants.EVALUATION_STATUS_SAVE, serviceName = EvaluationConstants.SERVICENAME)
	public OperationResponse evaluationStatusSave(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function evaluationStatusSave");
		Map<String, Object> parameters = functionRequest.getParameters();
		DataSourceHandler handler = extensionHelper.getHandler();
		Map<String, Object> evaluationKeys = new HashMap<>();	
		try {
			evaluationKeys.put(EvaluationConstants.EVALUATION_ID, parameters.get(EvaluationConstants.EVAL_ID));
			List<String> properties = new ArrayList<>();
			properties.add(EvaluationConstants.EVAL_STATUS);
			EntityData entityData = handler.executeRead(EvaluationConstants.EVALUATION, evaluationKeys, properties);
			Map<String, Object> keysStatus = new HashMap<>();
			if (EvaluationConstants.STATUS_NEW.equals((EvaluationConstants.EVAL_STATUS))) {
				keysStatus.put(EvaluationConstants.ID, EvaluationConstants.ONE);
			} else if (EvaluationConstants.STATUS_IN_PROGRESS.equals((EvaluationConstants.EVAL_STATUS))) {
				keysStatus.put(EvaluationConstants.ID, EvaluationConstants.TWO);
			} else {
				keysStatus.put(EvaluationConstants.ID, EvaluationConstants.THREE);
			}

			List<String> propertiesStatus = new ArrayList<>();
			propertiesStatus.add(EvaluationConstants.NEXT_STATUS);
			String nextEvalStatus = handler
					.executeRead(EvaluationConstants.EVALUATION_STATUS, keysStatus, propertiesStatus)
					.getElementValue(EvaluationConstants.NEXT_STATUS).toString();

			entityData = EntityData.getBuilder(entityData).removeElement(EvaluationConstants.EVAL_STATUS)
					.addElement(EvaluationConstants.EVAL_STATUS, parameters.get(EvaluationConstants.EVAL_STATUS))
					.addElement(EvaluationConstants.NEXT_EVAL_STATUS, nextEvalStatus)
					.addElement(EvaluationConstants.STATUS_CRITICALITY,
							getStatusCriticality(parameters.get(EvaluationConstants.EVAL_STATUS).toString()))
					.buildEntityData(EvaluationConstants.EVALUATION);
			handler.executeUpdate(entityData, evaluationKeys, false);
			OperationResponse response = OperationResponse.setSuccess().setEntityData(Arrays.asList(entityData))
					.response();
			return response;
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}

	}

	/*
	 * Implementing @Function which is updating the selling market values for
	 * given evaluation ID in Evaluation entity. The selling market values are
	 * updated and saved in the Evaluation entity in comma separated
	 * fashion(concatenated values)
	 */

	@Function(Name = EvaluationConstants.UPDATE_SELLING_MARKET, serviceName = EvaluationConstants.SERVICENAME)
	public OperationResponse updateSellignMarket(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function updateSellignMarket");
		try {
			Map<String, Object> requesParameters = functionRequest.getParameters();
			Map<String, Object> evaluationEntitykeys = new HashMap<>();
			evaluationEntitykeys.put(EvaluationConstants.EVALUATION_ID,
					requesParameters.get(EvaluationConstants.EVAL_ID));
			List<String> properties = new ArrayList<>();
			DataSourceHandler handler = extensionHelper.getHandler();
			properties.add(EvaluationConstants.SELLING_MARKET);
			EntityData entityData = handler.executeRead(EvaluationConstants.ENTITY_EVALUATION_DRAFTS,
					evaluationEntitykeys, properties);
			entityData = EntityData.getBuilder(entityData).removeElement(EvaluationConstants.SELLING_MARKET)
					.addElement(EvaluationConstants.SELLING_MARKET,
							requesParameters.get(EvaluationConstants.SELLING_MARKET))
					.buildEntityData(EvaluationConstants.ENTITY_EVALUATION_DRAFTS);
			handler.executeUpdate(entityData, evaluationEntitykeys, false);
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
		return OperationResponse.setSuccess().response();
	}

	/*
	 * Implementing @Function which is adding recipes for an evaluation sheet in
	 * Recipe Draft Entity. This function will get called when we click
	 * addRecipe button from the UI in edit page.
	 *
	 */
	@Function(Name = EvaluationConstants.ADD_RECIPE, serviceName = EvaluationConstants.SERVICENAME)
	public OperationResponse addRecipe(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function addRecipe");
		try {
			String draftUUID = null;
			Map<String, Object> requestParameters = functionRequest.getParameters();
			Map<String, Object> receipeEntitykeys = new HashMap<>();
			receipeEntitykeys.put(EvaluationConstants.EVALUATION_ID,
					requestParameters.get(EvaluationConstants.EVALUATION_ID));
			receipeEntitykeys.put(EvaluationConstants.RECIPE_ID, requestParameters.get(EvaluationConstants.RECIPE_ID));
			String recipeIdFromParameter = requestParameters.get(EvaluationConstants.RECIPE_ID).toString();
			List<String> recipeEntityproperties = new ArrayList<>();
			DataSourceHandler handler = extensionHelper.getHandler();
			CDSDataSourceHandler cdsHandler = CDSDataSourceHandlerFactory.getHandler();
			recipeEntityproperties.add(EvaluationConstants.RECIPE_ID);
			recipeEntityproperties.add(EvaluationConstants.ID);
			recipeEntityproperties.add(EvaluationConstants.IS_ACTIVE_ENTITY);
			recipeEntityproperties.add(EvaluationConstants.HAS_ACTIVE_ENTITY);
			recipeEntityproperties.add(EvaluationConstants.HAS_DRAFT_ENTITY);
			recipeEntityproperties.add(EvaluationConstants.EVALUATION_ID);
			EntityData entityDataDrafts = handler.executeRead(EvaluationConstants.RECIPE_DRAFTS_ENTITY,
					receipeEntitykeys, recipeEntityproperties);
			if (null != entityDataDrafts && null != entityDataDrafts.getElementValue(EvaluationConstants.RECIPE_ID)) {
				String receipeIDfromDb = entityDataDrafts.getElementValue(EvaluationConstants.RECIPE_ID).toString();
				if (recipeIdFromParameter.equals(receipeIDfromDb)) {
					return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList(recipeIdFromParameter))
							.response();
				}
			} else {
				CDSQuery cdsQueryDrafts = new CDSSelectQueryBuilder(EvaluationConstants.EVALUATION_DRAFTS)
						.selectColumns(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID)
						.where(new ConditionBuilder().columnName(EvaluationConstants.EVALUATION_ID)
								.IN(UUID.fromString(requestParameters.get(EvaluationConstants.EVALUATION_ID).toString())))
						.build();
				CDSSelectQueryResult queryResultForDraftUuid = null;
				queryResultForDraftUuid = cdsHandler.executeQuery(cdsQueryDrafts);
				if (queryResultForDraftUuid != null) {
					draftUUID = queryResultForDraftUuid.getResult().get(0)
							.getElementValue(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID).toString();
					LOGGER.info("draftUUID :-" + draftUUID);
				} else {
					LOGGER.error("queryResultForDraftUuid is null");
				}
				List<String> receipeEntityList = new ArrayList<>();
				receipeEntityList.add(EvaluationConstants.ID);
				Map<String, Object> recipeEntitiyMap = new HashMap<>();
				recipeEntitiyMap.put(EvaluationConstants.ID, UUID.randomUUID());
				recipeEntitiyMap.put(EvaluationConstants.RECIPE_ID, recipeIdFromParameter);
				recipeEntitiyMap.put(EvaluationConstants.IS_ACTIVE_ENTITY, Boolean.FALSE);
				recipeEntitiyMap.put(EvaluationConstants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
				recipeEntitiyMap.put(EvaluationConstants.HAS_DRAFT_ENTITY, Boolean.FALSE);
				recipeEntitiyMap.put(EvaluationConstants.EVALUATION_ID,
						requestParameters.get(EvaluationConstants.EVALUATION_ID));
				recipeEntitiyMap.put(EvaluationConstants.RECIPE_DESCRIPTION,
						requestParameters.get(EvaluationConstants.RECIPE_DESCRIPTION));
				recipeEntitiyMap.put(EvaluationConstants.R_TYPE, requestParameters.get(EvaluationConstants.R_TYPE));
				recipeEntitiyMap.put(EvaluationConstants.R_STATUS, requestParameters.get(EvaluationConstants.R_STATUS));
				recipeEntitiyMap.put(EvaluationConstants.COMPLIANT_STATUS, EvaluationConstants.NOT_ASSESSED);
				recipeEntitiyMap.put(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID, UUID.fromString(draftUUID));
				EntityData recipeEntityDraftData = EntityData.createFromMap(recipeEntitiyMap, receipeEntityList,
						EvaluationConstants.RECIPE_DRAFTS_ENTITY);
				handler.executeInsert(recipeEntityDraftData, false);
				return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
			}

		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
		return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
	}

	/*
	 * Implementing @Function which is adding purpose for an evaluation sheet in
	 * Purpose Drafts Entity. This function will get called when we click
	 * addPurpose button from the UI in edit page.
	 */

	@Function(Name = EvaluationConstants.ADD_PURPOSE, serviceName = EvaluationConstants.SERVICENAME)
	public OperationResponse addPurpose(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function addPurpose");
		try {
			Map<String, Object> requestParameters = functionRequest.getParameters();
			Map<String, Object> purposeEntitykeys = new HashMap<>();
			purposeEntitykeys.put(EvaluationConstants.EVALUATION_ID,
					requestParameters.get(EvaluationConstants.EVALUATION_ID));
			purposeEntitykeys.put(EvaluationConstants.PURPOSE_ID,
					requestParameters.get(EvaluationConstants.PURPOSE_ID));
			String purposeIdFromParameter = requestParameters.get(EvaluationConstants.PURPOSE_ID).toString();
			List<String> purposeEntityproperties = new ArrayList<>();
			DataSourceHandler handler = extensionHelper.getHandler();
			purposeEntityproperties.add(EvaluationConstants.PURPOSE_ID);
			purposeEntityproperties.add(EvaluationConstants.ID);
			purposeEntityproperties.add(EvaluationConstants.IS_ACTIVE_ENTITY);
			purposeEntityproperties.add(EvaluationConstants.HAS_ACTIVE_ENTITY);
			purposeEntityproperties.add(EvaluationConstants.HAS_DRAFT_ENTITY);
			purposeEntityproperties.add(EvaluationConstants.EVALUATION_ID);
			EntityData entityDataDrafts = handler.executeRead(EvaluationConstants.PURPOSE_DRAFTS_ENTITY,
					purposeEntitykeys, purposeEntityproperties);
			if (null != entityDataDrafts && null != entityDataDrafts.getElementValue(EvaluationConstants.PURPOSE_ID)) {
				String purposeIDfromDb = entityDataDrafts.getElementValue(EvaluationConstants.PURPOSE_ID).toString();
				if (purposeIdFromParameter.equals(purposeIDfromDb)) {
					return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList(purposeIdFromParameter))
							.response();
				}
			} else {
				List<String> purposeEntityList = new ArrayList<>();
				purposeEntityList.add(EvaluationConstants.ID);
				Map<String, Object> purposeEntityMap = new HashMap<>();
				purposeEntityMap.put(EvaluationConstants.ID, UUID.randomUUID());
				purposeEntityMap.put(EvaluationConstants.PURPOSE_ID, purposeIdFromParameter);
				purposeEntityMap.put(EvaluationConstants.IS_ACTIVE_ENTITY, Boolean.FALSE);
				purposeEntityMap.put(EvaluationConstants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
				purposeEntityMap.put(EvaluationConstants.HAS_DRAFT_ENTITY, Boolean.FALSE);
				purposeEntityMap.put(EvaluationConstants.EVALUATION_ID,
						requestParameters.get(EvaluationConstants.EVALUATION_ID));
				purposeEntityMap.put(EvaluationConstants.PURPOSE, requestParameters.get(EvaluationConstants.PURPOSE));
				purposeEntityMap.put(EvaluationConstants.PURPOSE_TYPE,
						requestParameters.get(EvaluationConstants.PURPOSE_TYPE));
				SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				purposeEntityMap.put(EvaluationConstants.ADDED_ON, df.format(date));
				purposeEntityMap.put(EvaluationConstants.ADDED_BY, requestParameters.get(EvaluationConstants.ADDED_BY));
				purposeEntityMap.put(EvaluationConstants.REQUIREMENT,
						requestParameters.get(EvaluationConstants.REQUIREMENT));
				purposeEntityMap.put(EvaluationConstants.REQUIREMENT_ID,
						requestParameters.get(EvaluationConstants.REQUIREMENT_ID));
				purposeEntityMap.put(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID, UUID.randomUUID());
				EntityData ed = EntityData.createFromMap(purposeEntityMap, purposeEntityList,
						EvaluationConstants.PURPOSE_DRAFTS_ENTITY);
				handler.executeInsert(ed, false);
				return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
			}
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}
		return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
	}

	/*
	 * Implementing @Function which is coping recipe for an evaluation sheet in
	 * Recipe draft entity table. This function will get called when we click on
	 * copy Recipe button from the UI in edit page.
	 */

	@Function(Name = EvaluationConstants.COPY_RECIPE, serviceName = EvaluationConstants.SERVICENAME)
	public OperationResponse copyRecipe(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function copyRecipe ");
		String draftUUID = null;
		try {
			Map<String, Object> requestParameters = functionRequest.getParameters();
			Map<String, Object> recipeEntitiyMap = new HashMap<>();
			recipeEntitiyMap.put(EvaluationConstants.COPY_RECIPE, requestParameters.get(EvaluationConstants.RECIPE_ID).toString());
			Map<String, Object> receipeEntitykeys = new HashMap<>();
			receipeEntitykeys.put(EvaluationConstants.EVALUATION_ID,
					requestParameters.get(EvaluationConstants.EVALUATION_ID));
			receipeEntitykeys.put(EvaluationConstants.RECIPE_ID, requestParameters.get(EvaluationConstants.RECIPE_ID));
			String recipeIdFromParameter = requestParameters.get(EvaluationConstants.RECIPE_ID).toString();
			LOGGER.info("evaluationID method " + requestParameters.get(EvaluationConstants.EVALUATION_ID));
			LOGGER.info("recipeId in method " + requestParameters.get(EvaluationConstants.RECIPE_ID));
			List<String> recipeEntityproperties = new ArrayList<>();
			DataSourceHandler handler = extensionHelper.getHandler();
			recipeEntityproperties.add(EvaluationConstants.RECIPE_ID);
			recipeEntityproperties.add(EvaluationConstants.ID);
			recipeEntityproperties.add(EvaluationConstants.IS_ACTIVE_ENTITY);
			recipeEntityproperties.add(EvaluationConstants.HAS_ACTIVE_ENTITY);
			recipeEntityproperties.add(EvaluationConstants.HAS_DRAFT_ENTITY);
			recipeEntityproperties.add(EvaluationConstants.EVALUATION_ID);
			List<String> keys = new ArrayList<>();
			keys.add(EvaluationConstants.ID);
			CDSDataSourceHandler cdsHandler = CDSDataSourceHandlerFactory.getHandler();
			CDSQuery cdsQueryDrafts = new CDSSelectQueryBuilder(EvaluationConstants.EVALUATION_DRAFTS)
					.selectColumns(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID)
					.where(new ConditionBuilder().columnName(EvaluationConstants.EVALUATION_ID)
							.IN(UUID.fromString(requestParameters.get(EvaluationConstants.EVALUATION_ID).toString())))
					.build();
			CDSSelectQueryResult queryResultForDraftUuid = null;
			queryResultForDraftUuid = cdsHandler.executeQuery(cdsQueryDrafts);
			if (queryResultForDraftUuid != null) {
				draftUUID = queryResultForDraftUuid.getResult().get(0)
						.getElementValue(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID).toString();
				LOGGER.info("draftUUID :-" + draftUUID);
			} else {
				LOGGER.error("queryResultForDraftUuid is null");
			}		
			Map<String, Object> entMap = new HashMap<>();
			entMap.put(EvaluationConstants.ID, UUID.randomUUID());
			entMap.put(EvaluationConstants.RECIPE_ID, UUID.randomUUID());
			entMap.put(EvaluationConstants.IS_ACTIVE_ENTITY, Boolean.FALSE);
			entMap.put(EvaluationConstants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
			entMap.put(EvaluationConstants.HAS_DRAFT_ENTITY, Boolean.FALSE);
			entMap.put(EvaluationConstants.EVALUATION_ID, requestParameters.get(EvaluationConstants.EVALUATION_ID));
			entMap.put(EvaluationConstants.RECIPE_DESCRIPTION,
					requestParameters.get(EvaluationConstants.RECIPE_DESCRIPTION) + "(copy)");
			entMap.put(EvaluationConstants.R_TYPE, requestParameters.get(EvaluationConstants.R_TYPE));
			entMap.put(EvaluationConstants.R_STATUS, requestParameters.get(EvaluationConstants.R_STATUS));
			entMap.put(EvaluationConstants.COMPLIANT_STATUS, EvaluationConstants.NOT_ASSESSED);
			entMap.put(EvaluationConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID,  UUID.fromString(draftUUID));
			entMap.put(EvaluationConstants.COPY_RECIPE, recipeIdFromParameter);
			EntityData ed = EntityData.createFromMap(entMap, keys, EvaluationConstants.RECIPE_DRAFTS_ENTITY);
			handler.executeInsert(ed, false);
			return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}

	}

	/*
	 * Implementing @Function is adding the recipe in Recipe entity. This method
	 * is called when we create the recipe from Formula optimizer application
	 * for an evaluation sheet and hit the save evaluation sheet button from UI
	 */

	@Function(Name = EvaluationConstants.SAVE_RECIPE, serviceName = EvaluationConstants.SERVICENAME)
	public OperationResponse saveRecipe(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function save Recipe ");

		try {
			Map<String, Object> requestParameters = functionRequest.getParameters();
			String recipeIdFromParameter = requestParameters.get(EvaluationConstants.RECIPE_ID).toString();
			List<String> recipeEntityKeys = new ArrayList<>();
			DataSourceHandler dsHandler = extensionHelper.getHandler();
			recipeEntityKeys.add(EvaluationConstants.ID);
			Map<String, Object> recipeEntityMap = new HashMap<>();
			recipeEntityMap.put(EvaluationConstants.ID, UUID.randomUUID());
			recipeEntityMap.put(EvaluationConstants.RECIPE_ID, recipeIdFromParameter);
			recipeEntityMap.put(EvaluationConstants.EVALUATION_ID,
					requestParameters.get(EvaluationConstants.EVALUATION_ID));
			recipeEntityMap.put(EvaluationConstants.RECIPE_DESCRIPTION,
					requestParameters.get(EvaluationConstants.RECIPE_DESCRIPTION));
			recipeEntityMap.put(EvaluationConstants.R_TYPE, requestParameters.get(EvaluationConstants.R_TYPE));
			recipeEntityMap.put(EvaluationConstants.R_STATUS, requestParameters.get(EvaluationConstants.R_STATUS));
			recipeEntityMap.put(EvaluationConstants.COMPLIANT_STATUS, EvaluationConstants.NOT_ASSESSED);
			EntityData recipeEntitydata = EntityData.createFromMap(recipeEntityMap, recipeEntityKeys,
					EvaluationConstants.RECIPE_ENTITY);
			dsHandler.executeInsert(recipeEntitydata, false);
			return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();

		} catch (DatasourceException datasourceException) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(datasourceException.getMessage())
					.setCause(datasourceException).response();
			LOGGER.error(datasourceException.getMessage(), datasourceException);
			return OperationResponse.setError(errorResponse);
		}

	}
	
		/*
	 * This method will return criticality value on the basis of evalStatus.
	 */
	public Integer getStatusCriticality(String status) {
		LOGGER.info("Executing getStatusCriticality  of EvaluationHooksHandler class ");
		switch (status) {
		case EvaluationConstants.STATUS_NEW:
			return 1;
		case EvaluationConstants.STATUS_IN_PROGRESS:
			return 2;
		case EvaluationConstants.CLOSED :
			return 3;
		default:
			return null;
		}

	}

}
