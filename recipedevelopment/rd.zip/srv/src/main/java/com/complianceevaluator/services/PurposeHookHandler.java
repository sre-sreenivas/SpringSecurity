package com.complianceevaluator.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.complianceevaluator.constants.EvaluationConstants;
import com.sap.cloud.sdk.cloudplatform.security.AuthTokenAccessor;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryBuilder;
import com.sap.cloud.sdk.odatav2.connectivity.ODataQueryResult;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterQuery;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponse;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/*
* This class is implementing TransactionHooks for  EvaluationStatus entity
*  @AfterQuery transaction hooks are implemented to modify the response on query operations.
* 
*/

public class PurposeHookHandler {

	private static final Logger LOGGER = Logger.getLogger(PurposeHookHandler.class.getName());

	/*
	 * Implementation of AfterQuery operation for Master Purpose Entity. This
	 * method is Calling Purpose API when we click on value help for adding
	 * purpose. If we didn't get the response from purpose API due to some
	 * exception then we are getting dummy data from Master Purpose DB.
	 */
	@AfterQuery(entity = EvaluationConstants.MASTER_PURPOSE, serviceName = EvaluationConstants.SERVICENAME)
	public QueryResponse getPurpose(QueryRequest request, QueryResponseAccessor response,
			ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing getPurpose from PurposeHookHandler class");

		boolean destinationRelevantHeader = true;
		List<EntityData> purposeData = new ArrayList<>();
		for (EntityData entityData : purposeData) {
			purposeData.remove(entityData);
		}
		try {
			ODataQueryResult readResult = ODataQueryBuilder
					.withEntity("/sap/opu/odata4/sap/api_compliancepurpose/srvd_a2x/sap/api_compliancepurpose/0001/",
							"A_CmplncPrps")
					.withHeader(EvaluationConstants.SAP_CLIENT, "001", destinationRelevantHeader)
					.withHeader(EvaluationConstants.SAP_LANGUAGE, "en", destinationRelevantHeader)
					.withHeader(EvaluationConstants.AUTHORIZATION,
							AuthTokenAccessor.getXsuaaServiceToken().getJwt().getToken())
					.select(EvaluationConstants.CMPLNC_PRPS_NAME, EvaluationConstants.CMPLNC_PRPS_UUID,
							EvaluationConstants.CREATED_BY_USER, EvaluationConstants.CREATION_DATE_TIME,
							"CmplncPrpsActivationStatus")
					.withoutMetadata().build().execute(EvaluationConstants.BACKEND_DESTINATION_NAME);
			JSONObject jsonObj = new JSONObject(readResult.getStreamData());
			JSONArray jsonArray = (JSONArray) (jsonObj.get("value"));

			for (int i = 0; i < jsonArray.length(); i++) {
				HashMap<String, Object> propertiesMap = new HashMap<>();
				JSONObject jsonObject = (JSONObject) jsonArray.get(i);
				String activationStatus = getActivationStatus((String) jsonObject.get("CmplncPrpsActivationStatus"));

				String input = (String) jsonObject.get(EvaluationConstants.CMPLNC_PRPS_UUID);

				// get the number of requirement
				ODataQueryResult readCountResult = ODataQueryBuilder
						.withEntity(
								"/sap/opu/odata4/sap/api_compliancepurpose/srvd_a2x/sap/api_compliancepurpose/0001/",
								"A_CmplncPrps(" + input + ")/_CmplPrpsRqmtAssgmt")
						.withHeader(EvaluationConstants.SAP_CLIENT, "001", destinationRelevantHeader)
						.withHeader(EvaluationConstants.SAP_LANGUAGE, "en", destinationRelevantHeader)
						.withHeader(EvaluationConstants.AUTHORIZATION,
								AuthTokenAccessor.getXsuaaServiceToken().getJwt().getToken())
						.select("*").withoutMetadata().build().execute(EvaluationConstants.BACKEND_DESTINATION_NAME);

				JSONObject jsonCountObj = new JSONObject(readCountResult.getStreamData());
				JSONArray jsonCountArray = (JSONArray) (jsonCountObj.get(EvaluationConstants.VALUE));

				propertiesMap.put(EvaluationConstants.ID, input);
				propertiesMap.put(EvaluationConstants.PURPOSE,
						(String) jsonObject.get(EvaluationConstants.CMPLNC_PRPS_NAME));
				propertiesMap.put(EvaluationConstants.CREATED_BY,
						(String) jsonObject.get(EvaluationConstants.CREATED_BY));
				propertiesMap.put(EvaluationConstants.NO_OF_REQUIREMENTS, jsonCountArray.length());
				propertiesMap.put(EvaluationConstants.CREATED_ON,
						(String) jsonObject.get(EvaluationConstants.CREATION_DATE_TIME));
				propertiesMap.put(EvaluationConstants.ACTIVATION_STATUS, activationStatus);

				List<String> keys = new ArrayList<>();
				keys.add((String) jsonObject.get(EvaluationConstants.CMPLNC_PRPS_UUID));
				keys.add((String) jsonObject.get(EvaluationConstants.CMPLNC_PRPS_NAME));
				keys.add((String) jsonObject.get(EvaluationConstants.CREATED_BY_USER));
				keys.add(Integer.toString(jsonCountArray.length()));
				keys.add((String) jsonObject.get(EvaluationConstants.CREATION_DATE_TIME));
				keys.add(activationStatus);

				EntityData entityData = EntityData.createFromMap(propertiesMap, keys,
						EvaluationConstants.MASTER_PURPOSE);
				purposeData.add(entityData);

			}

		} catch (Exception e) {
			for (int i = 0; i < 10; i++) {
				HashMap<String, Object> propertiesMapEx = new HashMap<>();
				List<String> keysEx = new ArrayList<>();
				propertiesMapEx.put(EvaluationConstants.ID, "01739547-9578-4e5b-9eac-bfc589ec40f" + i);
				propertiesMapEx.put(EvaluationConstants.PURPOSE, "P001" + i * 4 + i);
				propertiesMapEx.put(EvaluationConstants.CREATED_BY, "KOKASG");
				propertiesMapEx.put(EvaluationConstants.NO_OF_REQUIREMENTS, 0);
				propertiesMapEx.put(EvaluationConstants.CREATED_ON, "2019-05-08");
				propertiesMapEx.put(EvaluationConstants.ACTIVATION_STATUS, EvaluationConstants.N);
				keysEx.add(EvaluationConstants.ID);
				keysEx.add(EvaluationConstants.PURPOSE);
				keysEx.add(EvaluationConstants.CREATED_BY);
				keysEx.add(EvaluationConstants.NO_OF_REQUIREMENTS);
				keysEx.add(EvaluationConstants.CREATED_ON);
				keysEx.add(EvaluationConstants.ACTIVATION_STATUS);

				EntityData ed = EntityData.createFromMap(propertiesMapEx, keysEx, EvaluationConstants.MASTER_PURPOSE);
				purposeData.add(ed);
			}
			LOGGER.error(e.getMessage(), e);
			return QueryResponse.setSuccess().setData(purposeData).response();
		}
		return QueryResponse.setSuccess().setData(purposeData).response();
	}
        /*
	 * This method will return activationStatus value which is called from @AfterQuery 
	 * operation for Master Purpose Entity.
	 */
	private String getActivationStatus(String status) {
		switch (status) {
		case EvaluationConstants.N:
			return "New";
		case "A":
			return EvaluationConstants.ACTIVE;
		case "I":
			return EvaluationConstants.IN_ACTIVE;
		default:
			return null;
		}

	}

}
