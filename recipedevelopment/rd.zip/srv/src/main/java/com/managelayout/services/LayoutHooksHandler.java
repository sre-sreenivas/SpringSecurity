package com.managelayout.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.apache.log4j.Logger;
import com.managelayout.constants.LayoutConstants;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSException;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSQuery;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryBuilder;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.cds.ConditionBuilder;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterCreateDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.AfterQueryDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.BeforeCreate;
import com.sap.cloud.sdk.service.prov.api.annotations.BeforeCreateDraft;
import com.sap.cloud.sdk.service.prov.api.annotations.BeforeDelete;
import com.sap.cloud.sdk.service.prov.api.annotations.BeforeUpdate;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.exits.BeforeCreateResponse;
import com.sap.cloud.sdk.service.prov.api.exits.BeforeDeleteResponse;
import com.sap.cloud.sdk.service.prov.api.exits.BeforeUpdateResponse;
import com.sap.cloud.sdk.service.prov.api.request.CreateRequest;
import com.sap.cloud.sdk.service.prov.api.request.DeleteRequest;
import com.sap.cloud.sdk.service.prov.api.request.QueryRequest;
import com.sap.cloud.sdk.service.prov.api.request.UpdateRequest;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponse;
import com.sap.cloud.sdk.service.prov.api.response.CreateResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponse;
import com.sap.cloud.sdk.service.prov.api.response.QueryResponseAccessor;
import com.sap.cloud.sdk.service.prov.api.security.AuthorizationService;

/* 
 * This class is implements TransactionHooks for  LayoutInformation 
 * entity to modify the response,request on on or before operations
 * 
 */
public class LayoutHooksHandler {

	private static final Logger LOGGER = Logger.getLogger(LayoutHooksHandler.class.getName());

	@AfterQueryDraft(entity = LayoutConstants.LAYOUTINFORMATION, serviceName = LayoutConstants.SERVICENAME)
	public QueryResponse getLayoutInformationList(QueryRequest request, QueryResponseAccessor response,
			ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing LayoutHooksHandler class invoking method updateLayoutInformationList");
		List<EntityData> layoutDataList = response.getEntityDataList();
		List<EntityData> modifiedLayoutList = new ArrayList<>(layoutDataList.size());

		CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();

		try {
			modifiedLayoutList = getUserSpecificLayoutList(layoutDataList, dsHandler,
					AuthorizationService.getUserName());
			LOGGER.info("AuthorizationService.getUserName()--"+AuthorizationService.getUserName());
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return QueryResponse.setSuccess().setData(modifiedLayoutList).response();
	}

	/*
	 * Implementation of @AfterQueryDraft operation for ColumnsSelectedInLayout
	 * entity. This method is implemented for removing formula item from read on
	 * ColumnsSelectedInLayout entity.
	 */
	@AfterQueryDraft(entity = LayoutConstants.COLUMNSSELECTEDINLAYOUT, serviceName = LayoutConstants.SERVICENAME)
	public QueryResponse removeFormulaItem(QueryRequest request, QueryResponseAccessor response,
			ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing LayoutHooksHandler class invoking method removeFormulaItem");

		List<EntityData> entityDataList = response.getEntityDataList();
		try {
			for (EntityData ed : entityDataList) {
				if ((LayoutConstants.FORMULA_ITEM).equals(ed.getElementValue(LayoutConstants.SUB_CATEGORY_NAME))) {
					entityDataList.remove(ed);
					break;
				}
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return QueryResponse.setSuccess().setData(entityDataList).response();
	}

	/*
	 * This method is setting created by before the creation of
	 * layoutInformation.
	 */
	@BeforeCreateDraft(entity = LayoutConstants.LAYOUTINFORMATION, serviceName = LayoutConstants.SERVICENAME)
	public BeforeCreateResponse beforeCreateLayout(CreateRequest createRequest, ExtensionHelper extensionHelper) {

		LOGGER.info("Started executing LayoutHooksHandler class invoking method addCreatedBybeforeCreateLayout");
		EntityData entityData = createRequest.getData();
		EntityData modifiedEntityData = entityData;

		if (entityData.getElementValue(LayoutConstants.LAYOUT_NAME) == null) {
			modifiedEntityData = EntityData.getBuilder(entityData).addElement(LayoutConstants.DEFAULT_FLAG, false)
					.buildEntityData(LayoutConstants.ENTITY_LAYOUTINFORMATION);
		}
		return BeforeCreateResponse.setSuccess().setEntityData(modifiedEntityData).response();
	}

	/*
	 * This method is used to add validation for allowing only user-specific
	 * layouts to be deleted. Global layouts cannot be deleted
	 */
	@BeforeDelete(entity = LayoutConstants.LAYOUTINFORMATION, serviceName = LayoutConstants.SERVICENAME)
	public BeforeDeleteResponse beforeDeleteLayout(DeleteRequest deleteRequest, ExtensionHelper extensionHelper) {

		LOGGER.info("Started executing LayoutHooksHandler class invoking method beforeDeleteLayout");
		try {
			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();
			String layout = null;
			CDSQuery cdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_LAYOUTINFORMATION)
					.selectColumns(LayoutConstants.LAYOUT_TYPE).where(new ConditionBuilder()
							.columnName(LayoutConstants.LAYOUT_ID).IN(deleteRequest.getKeys().get("ID")))
					.build();
			CDSSelectQueryResult queryResultForLayoutInformation = null;
			queryResultForLayoutInformation = dsHandler.executeQuery(cdsQuery);
			for (EntityData getLayoutTypeList : queryResultForLayoutInformation.getResult()) {
				if (null != getLayoutTypeList.getElementValue(LayoutConstants.LAYOUT_TYPE)) {
					layout = getLayoutTypeList.getElementValue(LayoutConstants.LAYOUT_TYPE).toString();
				}
			}
			if (layout == null || layout.equals("") || layout.isEmpty()
					|| layout.equals(LayoutConstants.USER_SPECIFIC_LAYOUT)) {
				return BeforeDeleteResponse.setSuccess().response();
			} else {
				return BeforeDeleteResponse.setError(ErrorResponse.getBuilder()
						.setMessage("You are not authorized to delete this product.").setStatusCode(403).response());
			}
		} catch (CDSException exception) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(exception.getMessage())
					.setCause(exception).response();
			LOGGER.error(exception.getMessage(), exception);

			return BeforeDeleteResponse.setError(errorResponse);
		}

	}

	/*
	 * The below method is to add Formula Item column to the layout defaulting
	 * the column order value of Formula Item column to "0" and defaulting fixed
	 * column value Formula Item column to "true" in ColumnsSelectedInLayout
	 * entity.
	 */
	@AfterCreateDraft(entity = LayoutConstants.LAYOUTINFORMATION, serviceName = LayoutConstants.SERVICENAME)
	public CreateResponse afterCreateLayout(CreateRequest cr, CreateResponseAccessor layoutResponse,
			ExtensionHelper helper) {

		LOGGER.info("Started executing class LayoutHooksHandler invoking @AfterCreateDraft");

		List<String> keys = new ArrayList<>();
		keys.add(LayoutConstants.LAYOUT_ID);
		Map<String, Object> entMap = new HashMap<>();
		entMap.put(LayoutConstants.LAYOUT_ID, UUID.randomUUID());
		entMap.put(LayoutConstants.LAYOUT_ITEM_ID,
				layoutResponse.getEntityData().getElementValue(LayoutConstants.LAYOUT_ID));
		entMap.put(LayoutConstants.IS_ACTIVE_ENTITY, Boolean.FALSE);
		entMap.put(LayoutConstants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
		entMap.put(LayoutConstants.HAS_DRAFT_ENTITY, Boolean.FALSE);
		entMap.put(LayoutConstants.CATEGORY_NAME, LayoutConstants.BASIC_COLUMN);
		entMap.put(LayoutConstants.SUB_CATEGORY_NAME, LayoutConstants.FORMULA_ITEM);
		entMap.put(LayoutConstants.UOM, "");
		entMap.put(LayoutConstants.FIXEDCOLUMN, Boolean.TRUE);
		entMap.put(LayoutConstants.COLUMN_ORDER, LayoutConstants.COLUMNORDER_FALSE);
		entMap.put(LayoutConstants.DRAFT_ADMINISTRATIVEDATA_DRAFTUUID,
				layoutResponse.getEntityData().getElementValue(LayoutConstants.DRAFTADMINISTRATIVEDATA_DRAFTUUID));

		DataSourceHandler handler = helper.getHandler();
		EntityData entityData = EntityData.createFromMap(entMap, keys,
				LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS);
		try {
			handler.executeInsert(entityData, false);
		} catch (DatasourceException cdsException) {
			LOGGER.error(cdsException.getMessage(), cdsException);
		}
		return CreateResponse.setSuccess().response();
	}

	@BeforeCreate(entity = LayoutConstants.LAYOUTINFORMATION, serviceName = LayoutConstants.SERVICENAME)
	public BeforeCreateResponse beforecreateLayoutInformation(CreateRequest cr, ExtensionHelper eh) {

		LOGGER.info("Started executing class LayoutHooksHandler invoking beforecreateLayoutInformation");
		EntityData ed = cr.getData();
		String defaultFlag = ed.getElementValue(LayoutConstants.DEFAULT_FLAG).toString();
		try {
			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();
			if (defaultFlag.equals("true")) {
				CDSQuery cdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_LAYOUTINFORMATION)
						.selectColumns(LayoutConstants.LAYOUTINFORMATION_COLUMNS)
						.where(new ConditionBuilder().columnName(LayoutConstants.CREATED_BY)
								.IN(AuthorizationService.getUserName())
								.AND(new ConditionBuilder().columnName(LayoutConstants.DEFAULT_FLAG).EQ("true")))
						.build();

				CDSSelectQueryResult queryResultForColumnOrderDrafts = null;
				queryResultForColumnOrderDrafts = dsHandler.executeQuery(cdsQuery);

				List<EntityData> listUserLayout = queryResultForColumnOrderDrafts.getResult();
				DataSourceHandler handler = eh.getHandler();
				if (!listUserLayout.isEmpty()) {

					Map<String, Object> keysUpdate = new HashMap<>();
					Map<String, Object> entMap = new HashMap<>();
					List<String> keys = new ArrayList<>();

					String layoutID = listUserLayout.get(0).getElementValue(LayoutConstants.LAYOUT_ID).toString();
					entMap.put(LayoutConstants.DEFAULT_FLAG, false);
					keysUpdate.put(LayoutConstants.LAYOUT_ID, layoutID);
					ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_LAYOUTINFORMATION);
					handler.executeUpdate(ed, keysUpdate, false);
					EntityData newEd = handler.executeUpdate(ed, keysUpdate, false);
					return BeforeCreateResponse.setSuccess().setEntityData(newEd).response();
				}
			}

		} catch (Exception exception) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(exception.getMessage())
					.setCause(exception).response();
			LOGGER.error(exception.getMessage(), exception);
			return BeforeCreateResponse.setError(errorResponse);
		}
		return BeforeCreateResponse.setSuccess().setEntityData(ed).response();
	}

	@BeforeUpdate(entity = LayoutConstants.LAYOUTINFORMATION, serviceName = LayoutConstants.SERVICENAME)
	public BeforeUpdateResponse beforeUpdateLayoutInformation(UpdateRequest ur, ExtensionHelper eh) {
		LOGGER.info("Started executing class LayoutHooksHandler invoking beforeUpdateLayoutInformation");
		EntityData ed = ur.getData();
		String defaultFlag = ed.getElementValue(LayoutConstants.DEFAULT_FLAG).toString();
		
		try {
			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();
			if (defaultFlag.equals("true")) {
				CDSQuery cdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_LAYOUTINFORMATION)
						.selectColumns(LayoutConstants.LAYOUTINFORMATION_COLUMNS)
						.where(new ConditionBuilder().columnName(LayoutConstants.CREATED_BY)
								.IN(AuthorizationService.getUserName())
								.AND(new ConditionBuilder().columnName(LayoutConstants.DEFAULT_FLAG).EQ("true")))
						.build();

				CDSSelectQueryResult queryResultForColumnOrderDrafts = null;
				queryResultForColumnOrderDrafts = dsHandler.executeQuery(cdsQuery);

				List<EntityData> listUserLayout = queryResultForColumnOrderDrafts.getResult();
				DataSourceHandler handler = eh.getHandler();

				if (!listUserLayout.isEmpty()) {

					Map<String, Object> keysUpdate = new HashMap<>();
					Map<String, Object> entMap = new HashMap<>();
					List<String> keys = new ArrayList<>();

					String layoutID = listUserLayout.get(0).getElementValue(LayoutConstants.LAYOUT_ID).toString();
					entMap.put(LayoutConstants.DEFAULT_FLAG, false);
					keysUpdate.put(LayoutConstants.LAYOUT_ID, layoutID);
					ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_LAYOUTINFORMATION);
					EntityData newEd = handler.executeUpdate(ed, keysUpdate, false);
					return BeforeUpdateResponse.setSuccess().setEntityData(newEd).response();
				}
			}
		} catch (DatasourceException exception) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(exception.getMessage())
					.setCause(exception).response();
			LOGGER.error(exception.getMessage(), exception);
			return BeforeUpdateResponse.setError(errorResponse);
		}
		return BeforeUpdateResponse.setSuccess().setEntityData(ed).response();
	}

	private void draftLayoutList(CDSDataSourceHandler dsHandler, Set<String> layoutDraftsIdList,
			String[] draftUuidList) {
		CDSQuery draftLayoutCdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_LAYOUTINFORMATION_DRAFTS)
				.selectColumns(LayoutConstants.LAYOUT_ID).where(new ConditionBuilder()
						.columnName(LayoutConstants.DRAFT_ADMINISTRATIVEDATA_DRAFTUUID).IN(draftUuidList))
				.build();

		CDSSelectQueryResult draftLayoutCdsSelectQueryResult = null;
		try {
			draftLayoutCdsSelectQueryResult = dsHandler.executeQuery(draftLayoutCdsQuery);
			List<EntityData> layoutDraftsList = draftLayoutCdsSelectQueryResult.getResult();

			for (EntityData ed2 : layoutDraftsList) {
				layoutDraftsIdList.add((ed2.getElementValue(LayoutConstants.LAYOUT_ID).toString()));

			}
		} catch (CDSException e) {
			LOGGER.error(e.getMessage(), e);
		}
	}

	private void getLayoutList(String currentUserId, List<EntityData> layoutDataList, Set<String> layoutDraftsIdList,
			EntityData ed) {
		String createdBy=null;
		String lID;
		if (ed.getElementValue(LayoutConstants.CREATED_BY) == null) {
			if (!layoutDraftsIdList.isEmpty()) {
				lID = ed.getElementValue(LayoutConstants.LAYOUT_ID).toString();
				if (layoutDraftsIdList.contains(lID)) {
					layoutDataList.add(ed);
				}
			}
		} else {
			createdBy = ed.getElementValue(LayoutConstants.CREATED_BY).toString();
			if (createdBy.equals(currentUserId)) {
				layoutDataList.add(ed);
			}
		}
		
		LOGGER.info("createdBy--"+createdBy);
			
	}

	// This method will get user specific layout with draft records created by
	// same user
	private List<EntityData> getUserSpecificLayoutList(List<EntityData> responseDataList,
			CDSDataSourceHandler dsHandler, String currentUserId) {

		LOGGER.info("Started executing LayoutHooksHandler class invoking method getUserSpecificLayoutList");

		List<EntityData> layoutDataList = new ArrayList<>();
		Set<String> layoutDraftsIdList = new HashSet<>();
		try {
			CDSQuery draftCdsQuery = new CDSSelectQueryBuilder(LayoutConstants.DRAFTADMINISTRATIVEDATA)
					.selectColumns(LayoutConstants.DRAFTUUID)
					.where(new ConditionBuilder().columnName(LayoutConstants.CREATEDBYUSER).IN(currentUserId)).build();

			CDSSelectQueryResult draftCdsSelectQueryResult = dsHandler.executeQuery(draftCdsQuery);
			List<EntityData> draftList = draftCdsSelectQueryResult.getResult();
			
			
			
			String[] draftUuidList = new String[draftList.size()];
			int key = 0;
			if (!draftList.isEmpty()) {
				for (EntityData draftData : draftList) {
					draftUuidList[key++] = (draftData.getElementValue(LayoutConstants.DRAFTUUID).toString());
				}
			}
			
			
			LOGGER.info("responseDataList--"+responseDataList.size());
			
			if (draftUuidList.length != 0) {
				draftLayoutList(dsHandler, layoutDraftsIdList, draftUuidList);
			}
			for (EntityData ed : responseDataList) {
				getLayoutList(currentUserId, layoutDataList, layoutDraftsIdList, ed);
			}
			
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		
		LOGGER.info("layoutDataList--"+layoutDataList.size());
		return layoutDataList;
	}
}
