package com.managelayout.constants;

public class LayoutConstants {
    private LayoutConstants() {
        // Private constructor to avoid implicit Object creation
    }
	
	public static final String ENTITY_LAYOUTINFORMATION = "ManageLayoutService.LayoutInformation";
    public static final String LAYOUTINFORMATION = "LayoutInformation";
    public static final String SERVICENAME = "ManageLayoutService";
    public static final String ENTITY_COLUMNSSELECTEDINLAYOUT = "ManageLayoutService.ColumnsSelectedInLayout";
    public static final String COLUMNSSELECTEDINLAYOUT = "ColumnsSelectedInLayout";
    public static final String ENTITY_LAYOUTINFORMATION_LIST = "LayoutList";
    public static final String CREATED_BY = "createdBy";
    public static final String LAYOUT_ID = "ID";
    public static final String DEFAULT_FLAG = "defaultFlag";
    public static final String MODIFIED_BY = "modifiedBy";
    public static final String DESCRIPTION = "description";
    public static final String LAYOUTINFORMATION_COLUMNS = "ID, description, layoutName, defaultFlag, layoutType, referenceQuantity, UOM, createdAt, createdBy, modifiedBy, modifiedAt";
    public static final String DATA_MODEL = "managelayout.datamodel";
    public static final String LAYOUT_NAME = "layoutName";
    public static final String USER_SPECIFIC_LAYOUT = "User Specific Layout";
    public static final String LAYOUT_TYPE = "layoutType";
    public static final String DRAFTADMINISTRATIVEDATA = "ManageLayoutService.DRAFTADMINISTRATIVEDATA";
    public static final String DRAFTUUID = "DRAFTUUID";
    public static final String CREATEDBYUSER = "CREATEDBYUSER";
    public static final String REORDER_SELECTED_COLUMN = "reorderSelectedColumn";
    public static final String LAYOUT_ITEM_ID = "layoutItemId";
    public static final String COLUMN_ORDER = "columnOrder";
    public static final String FIXED_COLUMN = "fixedColumn";
    public static final String REORDER_ACTION = "reorderAction";
    public static final String BUTTON_UP = "up";
    public static final String BUTTON_DOWN = "down";
    public static final String BUTTON_DIRECT_UP = "directUp";
    public static final String BUTTON_DIRECT_DOWN = "directDown";
    public static final String ADD_BASIC_COLUMN = "addBasicColumn";
    public static final Integer COLUMNORDER_FALSE = 0;
    public static final Integer COLUMNORDER_TRUE = 1;
    public static final String SUBCATEGORY = "subCategory";
    public static final String SUB_CATEGORY_NAME = "subCategoryName";
    public static final String ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS = "ManageLayoutService.ColumnsSelectedInLayout_Drafts";
    public static final String ENTITY_LAYOUTINFORMATION_DRAFTS = "ManageLayoutService.LayoutInformation_Drafts";
    public static final String DRAFT_ADMINISTRATIVEDATA_DRAFTUUID = "DRAFTADMINISTRATIVEDATA_DRAFTUUID";
    public static final String IS_ACTIVE_ENTITY = "IsActiveEntity";
    public static final String HAS_ACTIVE_ENTITY = "HasActiveEntity";
    public static final String HAS_DRAFT_ENTITY = "HasDraftEntity";
    public static final String UOM = "UOM";
    public static final String BASIC_COLUMN = "Basic Column";
    public static final String FIXEDCOLUMN = "fixedColumn";
    public static final String CATEGORY_NAME = "categoryName";
    public static final String FORMULA_ITEM = "Formula Item";
    public static final String SELECT_COLUMNS = "columnOrder,ID,layoutItemId,categoryName,subCategoryName ,UOM,fixedColumn";
    public static final String SELECT_COLUMNS_FORMULA_ITEM = "columnOrder,ID,layoutItemId,fixedColumn";
    public static final String MODE_OFF = "off";
    public static final String DISPLAY_MODE = "displayMode";
    public static final String SAVE_USER_DEFAULT_LAYOUT = "saveUserDefaultLayout";
	public static final String DRAFTADMINISTRATIVEDATA_DRAFTUUID = "DraftAdministrativeData_DraftUUID";
}
