package com.managelayout.services;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.log4j.Logger;
import com.managelayout.constants.LayoutConstants;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSQuery;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryBuilder;
import com.sap.cloud.sdk.hana.connectivity.cds.CDSSelectQueryResult;
import com.sap.cloud.sdk.hana.connectivity.cds.ConditionBuilder;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandler;
import com.sap.cloud.sdk.hana.connectivity.handler.CDSDataSourceHandlerFactory;
import com.sap.cloud.sdk.service.prov.api.DataSourceHandler;
import com.sap.cloud.sdk.service.prov.api.EntityData;
import com.sap.cloud.sdk.service.prov.api.ExtensionHelper;
import com.sap.cloud.sdk.service.prov.api.annotations.Function;
import com.sap.cloud.sdk.service.prov.api.exception.DatasourceException;
import com.sap.cloud.sdk.service.prov.api.request.OperationRequest;
import com.sap.cloud.sdk.service.prov.api.response.ErrorResponse;
import com.sap.cloud.sdk.service.prov.api.response.OperationResponse;
import com.sap.cloud.sdk.service.prov.api.security.AuthorizationService;

/*
*This class is implementing @function which is updating the LayoutInformation status, defaultFlag  in LayoutInformation entity. 
*/

public class LayoutCustomService {

	private static final Logger LOGGER = Logger.getLogger(LayoutCustomService.class.getName());

	/*
	 * The below function is to add basic columns to the layout , updating the
	 * column order value and defaulting the column order value of fixed column
	 * value to "0" in LayoutInformation entity.
	 */

	@Function(Name = LayoutConstants.ADD_BASIC_COLUMN, serviceName = LayoutConstants.SERVICENAME)
	public OperationResponse addBasicColumn(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing class LayoutCustonService invoking function addBasicColumn");

		try {
			Map<String, Object> columnParameters = functionRequest.getParameters();
			Map<String, Object> columnEntitykeys = new HashMap<>();
			columnEntitykeys.put(LayoutConstants.LAYOUT_ITEM_ID,
					UUID.fromString(columnParameters.get(LayoutConstants.LAYOUT_ID).toString()));
			columnEntitykeys.put(LayoutConstants.SUB_CATEGORY_NAME, columnParameters.get(LayoutConstants.SUBCATEGORY));
			String subCategoryName = columnParameters.get(LayoutConstants.SUBCATEGORY).toString();
			List<String> columnEntityproperties = new ArrayList<>();
			Integer colOrder = null;
			String draftUUID = null;
			DataSourceHandler handler = extensionHelper.getHandler();
			columnEntityproperties.add(LayoutConstants.LAYOUT_ITEM_ID);
			columnEntityproperties.add(LayoutConstants.LAYOUT_ID);
			columnEntityproperties.add(LayoutConstants.SUB_CATEGORY_NAME);
			EntityData entityData = handler.executeRead(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS,
					columnEntitykeys, columnEntityproperties);
			if (null != entityData && null != entityData.getElementValue(LayoutConstants.SUB_CATEGORY_NAME)) {
				return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList(subCategoryName)).response();
			} else {

				CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();
				CDSQuery cdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS)
						.selectColumns((LayoutConstants.COLUMN_ORDER))
						.where(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID)
								.IN(UUID.fromString(columnParameters.get(LayoutConstants.LAYOUT_ID).toString())))
						.orderBy(LayoutConstants.COLUMN_ORDER, true).build();
				CDSSelectQueryResult queryResultForColumnOrderDrafts = null;
				queryResultForColumnOrderDrafts = dsHandler.executeQuery(cdsQuery);
				List<EntityData> colOrderDraftsList = new ArrayList<>();

				if (queryResultForColumnOrderDrafts != null) {
					colOrderDraftsList = queryResultForColumnOrderDrafts.getResult();
				} else {
					LOGGER.error("queryResultForColumnOrderDrafts is null");
				}
				CDSQuery cdsQueryDrafts = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_LAYOUTINFORMATION_DRAFTS)
						.selectColumns(LayoutConstants.DRAFT_ADMINISTRATIVEDATA_DRAFTUUID)
						.where(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ID)
								.IN(UUID.fromString(columnParameters.get(LayoutConstants.LAYOUT_ID).toString())))
						.build();
				CDSSelectQueryResult queryResultForDraftUuid = null;
				queryResultForDraftUuid = dsHandler.executeQuery(cdsQueryDrafts);
				if (queryResultForDraftUuid != null) {
					draftUUID = queryResultForDraftUuid.getResult().get(0)
							.getElementValue(LayoutConstants.DRAFT_ADMINISTRATIVEDATA_DRAFTUUID).toString();
				} else {
					LOGGER.error("queryResultForDraftUuid is null");
				}
				if (colOrderDraftsList.isEmpty()) {
					colOrder = LayoutConstants.COLUMNORDER_TRUE;
				} else if (queryResultForColumnOrderDrafts != null) {
					colOrder = Integer.parseInt(queryResultForColumnOrderDrafts.getResult().get(0)
							.getElementValue(LayoutConstants.COLUMN_ORDER).toString());
					colOrder = colOrder + LayoutConstants.COLUMNORDER_TRUE;
				}
				List<String> keys = new ArrayList<>();
				keys.add(LayoutConstants.LAYOUT_ID);
				Map<String, Object> entMap = new HashMap<>();
				entMap.put(LayoutConstants.LAYOUT_ID, UUID.randomUUID());
				entMap.put(LayoutConstants.LAYOUT_ITEM_ID, columnParameters.get(LayoutConstants.LAYOUT_ID));
				entMap.put(LayoutConstants.IS_ACTIVE_ENTITY, Boolean.FALSE);
				entMap.put(LayoutConstants.HAS_ACTIVE_ENTITY, Boolean.FALSE);
				entMap.put(LayoutConstants.HAS_DRAFT_ENTITY, Boolean.FALSE);
				entMap.put(LayoutConstants.CATEGORY_NAME, LayoutConstants.BASIC_COLUMN);
				entMap.put(LayoutConstants.SUB_CATEGORY_NAME, subCategoryName);
				entMap.put(LayoutConstants.UOM, "");
				entMap.put(LayoutConstants.FIXEDCOLUMN, Boolean.FALSE);
				entMap.put(LayoutConstants.COLUMN_ORDER, colOrder);
				entMap.put(LayoutConstants.DRAFT_ADMINISTRATIVEDATA_DRAFTUUID, UUID.fromString(draftUUID));
				EntityData ed = EntityData.createFromMap(entMap, keys,
						LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS);
				handler.executeInsert(ed, false);
				return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();

			}
		} catch (DatasourceException cdsException) {
			LOGGER.error(cdsException.getMessage(), cdsException);
		} catch (NumberFormatException numberFormatException) {
			LOGGER.error(numberFormatException.getMessage(), numberFormatException);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return OperationResponse.setSuccess().setPrimitiveData(Arrays.asList("")).response();
	}

	/*
	 * The below function import with name reorderSelectedColumn is implemented for
	 * reordering selected columns whether freezed or unfreezed.
	 */

	@Function(Name = LayoutConstants.REORDER_SELECTED_COLUMN, serviceName = LayoutConstants.SERVICENAME)
	public OperationResponse reorderSelectedColumn(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing function reorderSelectedColumn");
		try {
			String tableName = null;
			Map<String, Object> columnParameters = functionRequest.getParameters();
			Map<String, Object> columnEntitykeys = new HashMap<>();
			columnEntitykeys.put(LayoutConstants.LAYOUT_ID, columnParameters.get(LayoutConstants.LAYOUT_ID));

			DataSourceHandler handler = extensionHelper.getHandler();
			List<String> columnEntityproperties = new ArrayList<>();
			// Read all mandatory fields.
			columnEntityproperties.add(LayoutConstants.LAYOUT_ID);
			columnEntityproperties.add(LayoutConstants.LAYOUT_ITEM_ID);
			columnEntityproperties.add(LayoutConstants.COLUMN_ORDER);
			columnEntityproperties.add(LayoutConstants.FIXED_COLUMN);
			columnEntityproperties.add(LayoutConstants.SUB_CATEGORY_NAME);

			// if the displayMode is off, the columnsSelectedInDrafts table gets
			// updated, else the actual table gets updated.
			if ((LayoutConstants.MODE_OFF).equals(columnParameters.get(LayoutConstants.DISPLAY_MODE))) {
				tableName = LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS;
			} else {
				tableName = LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT;
			}
			EntityData entityData = handler.executeRead(tableName, columnEntitykeys, columnEntityproperties);

			Integer currentColumnOrder = null;
			currentColumnOrder = Integer.parseInt(entityData.getElementValue(LayoutConstants.COLUMN_ORDER).toString());

			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();

			if (columnParameters.get(LayoutConstants.REORDER_ACTION).equals(LayoutConstants.BUTTON_UP)
					|| columnParameters.get(LayoutConstants.REORDER_ACTION).equals(LayoutConstants.BUTTON_DOWN)) {
				reorderWhenButtonUpOrDown(columnParameters, handler, entityData, currentColumnOrder, dsHandler,
						tableName);
			} else if (columnParameters.get(LayoutConstants.REORDER_ACTION).equals(LayoutConstants.BUTTON_DIRECT_UP)) {
				reorderWhenButtonDirectUP(handler, entityData, dsHandler, tableName);
			} else if (columnParameters.get(LayoutConstants.REORDER_ACTION)
					.equals(LayoutConstants.BUTTON_DIRECT_DOWN)) {
				reorderWhenButtonDirectDown(handler, entityData, dsHandler, tableName);
			}
		} catch (DatasourceException | NumberFormatException e) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(e.getMessage()).setCause(e).response();
			return OperationResponse.setError(errorResponse);
		}
		return OperationResponse.setSuccess().response();
	}

	private void reorderWhenButtonDirectDown(DataSourceHandler handler, EntityData entityData,
			CDSDataSourceHandler dsHandler, String tableName) {
		try {
			CDSQuery cdsQuery = new CDSSelectQueryBuilder(tableName).selectColumns(LayoutConstants.SELECT_COLUMNS)
					.where(new ConditionBuilder().columnName(LayoutConstants.COLUMN_ORDER)
							.GT(entityData.getElementValue(LayoutConstants.COLUMN_ORDER))
							.AND(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID)
									.IN(entityData.getElementValue(LayoutConstants.LAYOUT_ITEM_ID)))
							.AND(new ConditionBuilder().columnName(LayoutConstants.SUB_CATEGORY_NAME)
									.NE(LayoutConstants.FORMULA_ITEM)))
					.build();
			CDSSelectQueryResult queryResultForColumnsSelected = dsHandler.executeQuery(cdsQuery);
			List<EntityData> queryResultList = queryResultForColumnsSelected.getResult();
			Map<Integer, Boolean> orderNumberMap = new HashMap<>();
			for (EntityData edfromList : queryResultList) {
				Map<String, Object> keysForAllRowsAbove = new HashMap<>();
				keysForAllRowsAbove.put(LayoutConstants.LAYOUT_ID,
						edfromList.getElementValue(LayoutConstants.LAYOUT_ID));
				orderNumberMap.put(
						Integer.parseInt(edfromList.getElementValue(LayoutConstants.COLUMN_ORDER).toString()) - 1,
						Boolean.valueOf(edfromList.getElementValue(LayoutConstants.FIXED_COLUMN).toString()));
				edfromList = EntityData.getBuilder(edfromList).removeElement(LayoutConstants.COLUMN_ORDER).addElement(
						LayoutConstants.COLUMN_ORDER,
						Integer.parseInt(edfromList.getElementValue(LayoutConstants.COLUMN_ORDER).toString()) - 1)
						.buildEntityData(tableName);
				handler.executeUpdate(edfromList, keysForAllRowsAbove, false);
			}
			Map<String, Object> keysForCurrentColumn = new HashMap<>();
			keysForCurrentColumn.put(LayoutConstants.LAYOUT_ID, entityData.getElementValue(LayoutConstants.LAYOUT_ID));
			Integer maxOrder = Collections.max(orderNumberMap.keySet());
			Boolean fixedFlag = orderNumberMap.get(maxOrder);
			entityData = EntityData.getBuilder(entityData).removeElement(LayoutConstants.COLUMN_ORDER)
					.addElement(LayoutConstants.COLUMN_ORDER, maxOrder + 1)
					.addElement(LayoutConstants.FIXED_COLUMN, !fixedFlag ? Boolean.FALSE : Boolean.TRUE)
					.buildEntityData(tableName);
			handler.executeUpdate(entityData, keysForCurrentColumn, false);
		} catch (DatasourceException cdsException) {
			LOGGER.error(cdsException.getMessage(), cdsException);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
	}

	private void reorderWhenButtonDirectUP(DataSourceHandler handler, EntityData entityData,
			CDSDataSourceHandler dsHandler, String tableName) {
		try {
			CDSQuery cdsQuery;
			cdsQuery = new CDSSelectQueryBuilder(tableName).selectColumns(LayoutConstants.SELECT_COLUMNS)
					.where(new ConditionBuilder().columnName(LayoutConstants.COLUMN_ORDER)
							.LT(entityData.getElementValue(LayoutConstants.COLUMN_ORDER))
							.AND(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID)
									.IN(entityData.getElementValue(LayoutConstants.LAYOUT_ITEM_ID)))
							.AND(new ConditionBuilder().columnName(LayoutConstants.SUB_CATEGORY_NAME)
									.NE(LayoutConstants.FORMULA_ITEM)))
					.build();

			CDSSelectQueryResult queryResultForColumnsSelected = dsHandler.executeQuery(cdsQuery);
			List<EntityData> queryResultList = queryResultForColumnsSelected.getResult();
			Map<Integer, Boolean> orderNumberMap = new HashMap<>();
			for (EntityData edfromList : queryResultList) {
				Map<String, Object> keysForAllRowsAbove = new HashMap<>();
				keysForAllRowsAbove.put(LayoutConstants.LAYOUT_ID,
						edfromList.getElementValue(LayoutConstants.LAYOUT_ID));
				orderNumberMap.put(
						Integer.parseInt(edfromList.getElementValue(LayoutConstants.COLUMN_ORDER).toString()) + 1,
						Boolean.valueOf(edfromList.getElementValue(LayoutConstants.FIXED_COLUMN).toString()));
				edfromList = EntityData.getBuilder(edfromList).removeElement(LayoutConstants.COLUMN_ORDER).addElement(
						LayoutConstants.COLUMN_ORDER,
						Integer.parseInt(edfromList.getElementValue(LayoutConstants.COLUMN_ORDER).toString()) + 1)
						.buildEntityData(tableName);
				handler.executeUpdate(edfromList, keysForAllRowsAbove, false);
			}
			Map<String, Object> keysForCurrentColumn = new HashMap<>();
			keysForCurrentColumn.put(LayoutConstants.LAYOUT_ID, entityData.getElementValue(LayoutConstants.LAYOUT_ID));
			Integer minOrder = Collections.min(orderNumberMap.keySet());
			entityData = EntityData.getBuilder(entityData).removeElement(LayoutConstants.COLUMN_ORDER)
					.addElement(LayoutConstants.COLUMN_ORDER, minOrder - 1)
					.addElement(LayoutConstants.FIXED_COLUMN, orderNumberMap.get(minOrder)).buildEntityData(tableName);
			handler.executeUpdate(entityData, keysForCurrentColumn, false);
		} catch (DatasourceException cdsException) {
			LOGGER.error(cdsException.getMessage(), cdsException);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
	}

	private void reorderWhenButtonUpOrDown(Map<String, Object> columnParameters, DataSourceHandler handler,
			EntityData entityData, Integer currentColumnOrder, CDSDataSourceHandler dsHandler, String tableName) {

		try {
			CDSQuery cdsQuery;
			if (columnParameters.get(LayoutConstants.REORDER_ACTION).equals(LayoutConstants.BUTTON_UP)) {
				cdsQuery = new CDSSelectQueryBuilder(tableName).top(1).selectColumns(LayoutConstants.SELECT_COLUMNS)
						.where(new ConditionBuilder().columnName(LayoutConstants.COLUMN_ORDER)
								.LT(entityData.getElementValue(LayoutConstants.COLUMN_ORDER))
								.AND(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID)
										.IN(entityData.getElementValue(LayoutConstants.LAYOUT_ITEM_ID)))
								.AND(new ConditionBuilder().columnName(LayoutConstants.SUB_CATEGORY_NAME)
										.NE(LayoutConstants.FORMULA_ITEM)))
						.orderBy(LayoutConstants.COLUMN_ORDER, true).build();
			} else {
				cdsQuery = new CDSSelectQueryBuilder(tableName).top(1).selectColumns(LayoutConstants.SELECT_COLUMNS)
						.where(new ConditionBuilder().columnName(LayoutConstants.COLUMN_ORDER)
								.GT(entityData.getElementValue(LayoutConstants.COLUMN_ORDER))
								.AND(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID)
										.IN(entityData.getElementValue(LayoutConstants.LAYOUT_ITEM_ID))))
						.orderBy(LayoutConstants.COLUMN_ORDER, false).build();
			}
			CDSSelectQueryResult queryResultForColumnsSelected;
			queryResultForColumnsSelected = dsHandler.executeQuery(cdsQuery);
			EntityData swapEntityData = queryResultForColumnsSelected.getResult().get(0);
			Integer swapColumnOrder = Integer.parseInt(queryResultForColumnsSelected.getResult().get(0)
					.getElementValue(LayoutConstants.COLUMN_ORDER).toString());
			if (columnParameters.get(LayoutConstants.REORDER_ACTION).equals(LayoutConstants.BUTTON_UP)
					&& swapEntityData.getElementValue(LayoutConstants.FIXED_COLUMN) != entityData
							.getElementValue(LayoutConstants.FIXED_COLUMN)) {
				swapEntityData = EntityData.getBuilder(swapEntityData).removeElement(LayoutConstants.COLUMN_ORDER)
						.addElement(LayoutConstants.COLUMN_ORDER, currentColumnOrder)
						.removeElement(LayoutConstants.FIXED_COLUMN).addElement(LayoutConstants.FIXED_COLUMN, false)
						.buildEntityData(tableName);
			} else {
				swapEntityData = EntityData.getBuilder(swapEntityData).removeElement(LayoutConstants.COLUMN_ORDER)
						.addElement(LayoutConstants.COLUMN_ORDER, currentColumnOrder).buildEntityData(tableName);
			}
			Map<String, Object> keys = new HashMap<>();
			keys.put(LayoutConstants.LAYOUT_ID, swapEntityData.getElementValue(LayoutConstants.LAYOUT_ID));
			handler.executeUpdate(swapEntityData, keys, false);
			if (columnParameters.get(LayoutConstants.REORDER_ACTION).equals(LayoutConstants.BUTTON_DOWN)
					&& swapEntityData.getElementValue(LayoutConstants.FIXED_COLUMN) != entityData
							.getElementValue(LayoutConstants.FIXED_COLUMN)) {
				entityData = EntityData.getBuilder(entityData).removeElement(LayoutConstants.COLUMN_ORDER)
						.addElement(LayoutConstants.COLUMN_ORDER, swapColumnOrder)
						.addElement(LayoutConstants.FIXED_COLUMN, false).buildEntityData(tableName);
			} else {
				entityData = EntityData.getBuilder(entityData).removeElement(LayoutConstants.COLUMN_ORDER)
						.addElement(LayoutConstants.COLUMN_ORDER, swapColumnOrder).buildEntityData(tableName);
			}
			Map<String, Object> swapKeys = new HashMap<>();
			swapKeys.put(LayoutConstants.LAYOUT_ID, entityData.getElementValue(LayoutConstants.LAYOUT_ID));
			handler.executeUpdate(entityData, swapKeys, false);
		} catch (DatasourceException cdsException) {
			LOGGER.error(cdsException.getMessage(), cdsException);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
	}

	/*
	 * Below function import will be used in these scenarios
		1. If any fixed column is checked then it will update all the previous row's fixed column values to true
		2. If any fixed column is unchecked then it will update all the next row's fixed column values to false
	*/
	@Function(Name = "layoutFixedColumnSave", serviceName = LayoutConstants.SERVICENAME)
	public OperationResponse layoutFixedColumnSave(OperationRequest functionRequest, ExtensionHelper extensionHelper) {

		LOGGER.info("Started executing class LayoutCustonService invoking function layoutDefaultFlagSave");
		Map<String, Object> columnParameters = functionRequest.getParameters();

		String id = columnParameters.get(LayoutConstants.LAYOUT_ID).toString();
		try {
			EntityData ed;
			DataSourceHandler handler = extensionHelper.getHandler();
			Boolean fixedCol = columnParameters.get("fixed").equals("true");

			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();

			CDSQuery cdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS)
					.selectColumns("layoutItemId,columnOrder")
					.where(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ID).IN(UUID.fromString(id)))
					.build();
			CDSSelectQueryResult queryResultForColumnOrderDrafts = null;
			queryResultForColumnOrderDrafts = dsHandler.executeQuery(cdsQuery);

			String layoutItemId = queryResultForColumnOrderDrafts.getResult().get(0)
					.getElementValue(LayoutConstants.LAYOUT_ITEM_ID).toString();
			String columnOrder = queryResultForColumnOrderDrafts.getResult().get(0)
					.getElementValue(LayoutConstants.COLUMN_ORDER).toString();

			CDSQuery cdsQueryNextCol = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS)
					.selectColumns(LayoutConstants.SELECT_COLUMNS_FORMULA_ITEM)
					.where(new ConditionBuilder().columnName(LayoutConstants.COLUMN_ORDER).GT(columnOrder)
							.AND(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID).IN(layoutItemId))
							.AND(new ConditionBuilder().columnName(LayoutConstants.SUB_CATEGORY_NAME)
									.NE(LayoutConstants.FORMULA_ITEM)))
					.build();

			CDSSelectQueryResult queryResultForNextColOrder = null;
			queryResultForNextColOrder = dsHandler.executeQuery(cdsQueryNextCol);

			CDSQuery cdsQueryPrevCol = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS)
					.selectColumns(LayoutConstants.SELECT_COLUMNS_FORMULA_ITEM)
					.where(new ConditionBuilder().columnName(LayoutConstants.COLUMN_ORDER).LT(columnOrder)
							.AND(new ConditionBuilder().columnName(LayoutConstants.LAYOUT_ITEM_ID).IN(layoutItemId))
							.AND(new ConditionBuilder().columnName(LayoutConstants.SUB_CATEGORY_NAME)
									.NE(LayoutConstants.FORMULA_ITEM)))
					.build();

			CDSSelectQueryResult queryResultForPrevColOrder = null;
			queryResultForPrevColOrder = dsHandler.executeQuery(cdsQueryPrevCol);

			List<EntityData> prevColOrderList = queryResultForPrevColOrder.getResult();
			List<EntityData> nextColOrderList = queryResultForNextColOrder.getResult();

			if (!fixedCol) {
				for (EntityData en : nextColOrderList) {
					String specificationID = en.getElementValue("ID").toString();
					List<String> keys = new ArrayList<>();
					keys.add("ID");

					Map<String, Object> entMap = new HashMap<>();
					entMap.put(LayoutConstants.FIXEDCOLUMN, false);

					Map<String, Object> keysUpdate = new HashMap<>();
					keysUpdate.put(LayoutConstants.LAYOUT_ID, specificationID);
					ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS);
					handler.executeUpdate(ed, keysUpdate, false);

				}
				return OperationResponse.setSuccess().response();
			} else {
				for (EntityData en : prevColOrderList) {
					String specificationID = en.getElementValue(LayoutConstants.LAYOUT_ID).toString();
					List<String> keys = new ArrayList<>();
					keys.add(LayoutConstants.LAYOUT_ID);

					Map<String, Object> entMap = new HashMap<>();
					entMap.put(LayoutConstants.FIXEDCOLUMN, true);

					Map<String, Object> keysUpdate = new HashMap<>();
					keysUpdate.put(LayoutConstants.LAYOUT_ID, specificationID);

					ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_COLUMNSSELECTEDINLAYOUT_DRAFTS);
					handler.executeUpdate(ed, keysUpdate, true);

				}
				return OperationResponse.setSuccess().response();
			}

		} catch (Exception exception) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(exception.getMessage())
					.setCause(exception).response();
			LOGGER.error(exception.getMessage(), exception);

			return OperationResponse.setError(errorResponse);
		}
	}

	/*
	 * Below function will update the defaultFlag value in the below scenarios 
		1. If there are no user-specific default layouts then selected layout's defaultFlag will be set to true.
		2. If the selected layout is not a default layout then selected layout's defaultFlag will be set to true 
			and the existing default layout's defaultFlag will be set to false
	*/
	@Function(Name = LayoutConstants.SAVE_USER_DEFAULT_LAYOUT, serviceName = LayoutConstants.SERVICENAME)
	public OperationResponse saveUserDefaultLayout(OperationRequest functionRequest, ExtensionHelper extensionHelper) {
		LOGGER.info("Started executing class FormulaOptimiserCustonService invoking function saveUserDefaultLayout");

		try {
			CDSDataSourceHandler dsHandler = CDSDataSourceHandlerFactory.getHandler();
			DataSourceHandler handler = extensionHelper.getHandler();
			Map<String, Object> columnParameters = functionRequest.getParameters();
			String layoutIdSelected = columnParameters.get(LayoutConstants.LAYOUT_ID).toString();
			CDSQuery cdsQuery = new CDSSelectQueryBuilder(LayoutConstants.ENTITY_LAYOUTINFORMATION)
					.selectColumns(LayoutConstants.LAYOUT_ID, LayoutConstants.DEFAULT_FLAG)
					.where(new ConditionBuilder().columnName(LayoutConstants.CREATED_BY)
							.IN(AuthorizationService.getUserName())
							.AND(new ConditionBuilder().columnName(LayoutConstants.DEFAULT_FLAG).IN(true)))
					.build();
			CDSSelectQueryResult defaultLayout = null;
			defaultLayout = dsHandler.executeQuery(cdsQuery);
			List<EntityData> listUserLayout = defaultLayout.getResult();

			String layoutID = null;
			EntityData ed;
			Map<String, Object> keysUpdate = new HashMap<>();
			Map<String, Object> entMap = new HashMap<>();
			List<String> keys = new ArrayList<>();
			keys.add("ID");

			if (listUserLayout.isEmpty()) {
				entMap.put(LayoutConstants.DEFAULT_FLAG, true);
				keysUpdate.put(LayoutConstants.LAYOUT_ID, layoutIdSelected);
				ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_LAYOUTINFORMATION);
				handler.executeUpdate(ed, keysUpdate, false);
				return OperationResponse.setSuccess().response();
			} else if (layoutID != layoutIdSelected) {
				layoutID = listUserLayout.get(0).getElementValue(LayoutConstants.LAYOUT_ID).toString();
				entMap.put(LayoutConstants.DEFAULT_FLAG, false);
				keysUpdate.put(LayoutConstants.LAYOUT_ID, layoutID);
				ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_LAYOUTINFORMATION);
				handler.executeUpdate(ed, keysUpdate, false);

				entMap.put(LayoutConstants.DEFAULT_FLAG, true);
				keysUpdate.put(LayoutConstants.LAYOUT_ID, layoutIdSelected);
				ed = EntityData.createFromMap(entMap, keys, LayoutConstants.ENTITY_LAYOUTINFORMATION);
				handler.executeUpdate(ed, keysUpdate, false);
				return OperationResponse.setSuccess().response();
			}
		} catch (Exception exception) {
			ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage(exception.getMessage())
					.setCause(exception).response();
			LOGGER.error(exception.getMessage(), exception);
			return OperationResponse.setError(errorResponse);
		}
		ErrorResponse errorResponse = ErrorResponse.getBuilder().setMessage("No Default Layouts Found").response();
		return OperationResponse.setError(errorResponse);
	}
}
