sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("manage.manage_layout.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});